import 'package:flutter_credit_card/flutter_credit_card.dart';

class CreditCardBrand {
  CreditCardBrand(this.brandName);

  CardType? brandName;
}
