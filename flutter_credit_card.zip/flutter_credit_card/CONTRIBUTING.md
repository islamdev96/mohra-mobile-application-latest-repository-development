# Way to contribute

1.  Fork the repo and create your branch from `master`.
2.  Clone the project to your own machine.
3.  Commit changes to your own branch
4.  Make sure your code lints.
5.  Push your work back up to your fork.
6.  Issue that pull request!
