package com.example.intl_phone_field_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
