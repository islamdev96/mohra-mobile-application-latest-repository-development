import 'package:starter_application/core/entities/base_entity.dart';
import 'package:spotify/spotify.dart';

class ArtistsListEntity extends BaseEntity{
  final List<Artist> artists;

  ArtistsListEntity(this.artists);


  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();}