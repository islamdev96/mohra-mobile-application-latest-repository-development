import 'package:starter_application/core/entities/base_entity.dart';

class SavedAlbumsListEntity extends BaseEntity {
    SavedAlbumsListEntity({
        required this.href,
        required this.items,
        required this.previous,
        required this.total,
    });

    final String? href;
    final List<SavedAlbumsItemEntity> items;
    final dynamic previous;
    final int? total;

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}

class SavedAlbumsItemEntity extends BaseEntity{
    SavedAlbumsItemEntity({
        required this.album,
    });

    final AlbumEntity? album;

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}

class AlbumEntity extends BaseEntity{
    AlbumEntity({
        required this.albumType,
        required this.artists,
        required this.externalIds,
        required this.externalUrls,
        required this.genres,
        required this.href,
        required this.id,
        required this.images,
        required this.label,
        required this.name,
        required this.popularity,
        required this.releaseDate,
        required this.releaseDatePrecision,
        required this.totalTracks,
        required this.tracks,
        required this.type,
        required this.uri,
    });

    final String? albumType;
    final List<ArtistEntity> artists;
    final ExternalIdsEntity? externalIds;
    final ExternalUrlsEntity? externalUrls;
    final List<dynamic> genres;
    final String? href;
    final String? id;
    final List<ImageEntity> images;
    final String? label;
    final String? name;
    final int? popularity;
    final DateTime? releaseDate;
    final String? releaseDatePrecision;
    final int? totalTracks;
    final TracksEntity? tracks;
    final String? type;
    final String? uri;

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}

class ArtistEntity extends BaseEntity{
    ArtistEntity({
        required this.externalUrls,
        required this.href,
        required this.id,
        required this.name,
        required this.type,
        required this.uri,
    });

    final ExternalUrlsEntity? externalUrls;
    final String? href;
    final String? id;
    final String? name;
    final String? type;
    final String? uri;

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}

class ExternalUrlsEntity extends BaseEntity {
    ExternalUrlsEntity({
        required this.spotify,
    });

    final String? spotify;

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}

class ExternalIdsEntity extends BaseEntity {
    ExternalIdsEntity({
        required this.upc,
    });

    final String? upc;

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}

class ImageEntity extends BaseEntity{
    ImageEntity({
        required this.height,
        required this.url,
        required this.width,
    });

    final int? height;
    final String? url;
    final int? width;

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}

class TracksEntity extends BaseEntity{
    TracksEntity({
        required this.href,
        required this.items,
        required this.limit,
        required this.next,
        required this.offset,
        required this.previous,
        required this.total,
    });

    final String? href;
    final List<TracksItemEntity> items;
    final int? limit;
    final dynamic next;
    final int? offset;
    final dynamic previous;
    final int? total;

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}

class TracksItemEntity extends BaseEntity{
    TracksItemEntity({
        required this.artists,
        required this.discNumber,
        required this.durationMs,
        required this.explicit,
        required this.externalUrls,
        required this.href,
        required this.id,
        required this.isLocal,
        required this.name,
        required this.previewUrl,
        required this.trackNumber,
        required this.type,
        required this.uri,
    });

    final List<ArtistEntity> artists;
    final int? discNumber;
    final int? durationMs;
    final bool? explicit;
    final ExternalUrlsEntity? externalUrls;
    final String? href;
    final String? id;
    final bool? isLocal;
    final String? name;
    final dynamic previewUrl;
    final int? trackNumber;
    final String? type;
    final String? uri;

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}
