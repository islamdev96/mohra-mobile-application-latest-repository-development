import 'package:starter_application/core/entities/base_entity.dart';
import 'package:spotify/spotify.dart';

class PlaylistTracksListEntity extends BaseEntity{
  final List<Track> tracks;

  PlaylistTracksListEntity(this.tracks);


  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();}