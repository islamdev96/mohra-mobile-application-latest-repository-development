import 'package:spotify/spotify.dart';
import 'package:starter_application/core/entities/base_entity.dart';

class SavedTracksEntity extends BaseEntity {
  final List<TrackSaved> tracks;

  SavedTracksEntity(this.tracks);

  @override
  List<Object?> get props => [];
}
