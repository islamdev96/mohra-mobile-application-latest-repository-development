import 'package:starter_application/core/entities/base_entity.dart';
import 'package:spotify/spotify.dart';

class UserPlaylistsEntity extends BaseEntity{
  final List<PlaylistSimple> playlists;

  UserPlaylistsEntity(this.playlists);


  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();}