import 'package:spotify/spotify.dart';
import 'package:starter_application/core/entities/base_entity.dart';
import 'package:starter_application/features/music/domain/entity/recently_played_tracks_entity.dart';
import 'package:starter_application/features/music/domain/entity/saved_tracks_entity.dart';

class MusicHomeEntity extends BaseEntity {
  final List<PlaylistSimple> playlists;
  final RecentlyPlayedTracksListEntity recentlyPlayedTracksListEntity;
  final List<Artist> mostPopularArtists;
  final List<PlaylistSimple> userPlaylists;
  final List<TrackSaved> savedTracks;

  MusicHomeEntity({
    required this.playlists,
    required this.recentlyPlayedTracksListEntity,
    required this.mostPopularArtists,
    required this.userPlaylists,
    required this.savedTracks,
  });

  @override
  List<Object?> get props => throw UnimplementedError();
}
