import 'package:starter_application/core/entities/base_entity.dart';
import 'package:starter_application/features/music/domain/entity/saved_albums_list_entity.dart';

class RecentlyPlayedTracksListEntity extends BaseEntity{
    RecentlyPlayedTracksListEntity({
        required this.items,
    });

    final List<RecentlyPlayedItemEntity> items;

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
  
}

class RecentlyPlayedItemEntity extends BaseEntity{
    RecentlyPlayedItemEntity({
        required this.track,
        required this.playedAt,
        required this.context,
    });

    final RecentlyPlayedTrackEntity? track;
    final DateTime? playedAt;
    final RecentlyPlayedContextEntity? context;

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}

class RecentlyPlayedContextEntity extends BaseEntity{
    RecentlyPlayedContextEntity({
        required this.href,
        required this.type,
        required this.uri,
    });

    final String? href;
    final String? type;
    final String? uri;

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}


class RecentlyPlayedTrackEntity extends BaseEntity{
    RecentlyPlayedTrackEntity({
        required this.album,
        required this.artists,
        required this.availableMarkets,
        required this.discNumber,
        required this.durationMs,
        required this.explicit,
        required this.href,
        required this.id,
        required this.isLocal,
        required this.name,
        required this.popularity,
        required this.previewUrl,
        required this.trackNumber,
        required this.type,
        required this.uri,
    });

    final RecentlyPlayedAlbumEntity? album;
    final List<ArtistEntity> artists;
    final List<String> availableMarkets;
    final int? discNumber;
    final int? durationMs;
    final bool? explicit;
    final String? href;
    final String? id;
    final bool? isLocal;
    final String? name;
    final int? popularity;
    final String? previewUrl;
    final int? trackNumber;
    final String? type;
    final String? uri;

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}

class RecentlyPlayedAlbumEntity extends BaseEntity{
    RecentlyPlayedAlbumEntity({
        required this.albumType,
        required this.artists,
        required this.availableMarkets,
        required this.href,
        required this.id,
        required this.images,
        required this.name,
        required this.releaseDate,
        required this.releaseDatePrecision,
        required this.totalTracks,
        required this.type,
        required this.uri,
    });

    final String? albumType;
    final List<ArtistEntity> artists;
    final List<String> availableMarkets;
    final String? href;
    final String? id;
    final List<ImageEntity> images;
    final String? name;
    final DateTime? releaseDate;
    final String? releaseDatePrecision;
    final int? totalTracks;
    final String? type;
    final String? uri;

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}





