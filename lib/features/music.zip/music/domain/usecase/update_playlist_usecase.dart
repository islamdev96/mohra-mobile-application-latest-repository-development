import 'package:injectable/injectable.dart';
import 'package:starter_application/core/errors/app_errors.dart';
import 'package:starter_application/core/models/empty_response.dart';
import 'package:starter_application/core/results/result.dart';
import 'package:starter_application/core/usecases/usecase.dart';
import 'package:starter_application/features/music/data/model/request/update_playlist_param.dart';
import 'package:starter_application/features/music/domain/repository/imusic_repository.dart';

@injectable
class UpdatePlaylistUsecase
    extends UseCase<EmptyResponse, UpdatePlaylistParam> {
  final IMusicRepository repository;

  UpdatePlaylistUsecase(this.repository);
  @override
  Future<Result<AppErrors, EmptyResponse>> call(UpdatePlaylistParam param) {
    return repository.updatePlaylist(param);
  }
}
