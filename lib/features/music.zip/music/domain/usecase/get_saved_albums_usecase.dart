import 'package:injectable/injectable.dart';
import 'package:starter_application/core/results/result.dart';
import 'package:starter_application/core/errors/app_errors.dart';
import 'package:starter_application/core/usecases/usecase.dart';
import 'package:starter_application/features/music/data/model/request/music_pagination_param.dart';
import 'package:starter_application/features/music/domain/entity/saved_albums_list_entity.dart';
import 'package:starter_application/features/music/domain/repository/imusic_repository.dart';
@injectable
class GetSavedAlbumsUsecase
    extends UseCase<SavedAlbumsListEntity, MusicPaginationParam> {
  final IMusicRepository repository;

  GetSavedAlbumsUsecase(this.repository);
  @override
  Future<Result<AppErrors, SavedAlbumsListEntity>> call(
      MusicPaginationParam param) {
    return repository.getSavedAlbums(param);
  }
}
