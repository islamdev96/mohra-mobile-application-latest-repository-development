import 'package:injectable/injectable.dart';
import 'package:starter_application/core/errors/app_errors.dart';
import 'package:starter_application/core/params/no_params.dart';
import 'package:starter_application/core/results/result.dart';
import 'package:starter_application/core/usecases/usecase.dart';
import 'package:starter_application/features/music/data/datasource/imusic_remote.dart';
import 'package:starter_application/features/music/domain/entity/recently_played_tracks_entity.dart';
import 'package:starter_application/features/music/domain/repository/imusic_repository.dart';

@injectable
class RecentlyPlayedTracksUsecase
    extends UseCase<RecentlyPlayedTracksListEntity, NoParams> {
  final IMusicRepository repository;

  RecentlyPlayedTracksUsecase(this.repository);
  @override
  Future<Result<AppErrors, RecentlyPlayedTracksListEntity>> call(
      NoParams param) {
    return repository.getRecentlyPlayedTracks();
  }
}
