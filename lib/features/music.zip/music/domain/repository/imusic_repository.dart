import 'package:starter_application/core/models/empty_response.dart';
import 'package:starter_application/features/music/data/model/request/music_pagination_param.dart';
import 'package:starter_application/features/music/data/model/request/update_playlist_image_param.dart';
import 'package:starter_application/features/music/data/model/request/update_playlist_param.dart';
import 'package:starter_application/features/music/domain/entity/recently_played_tracks_entity.dart';

import 'package:starter_application/core/results/result.dart';

import 'package:starter_application/core/errors/app_errors.dart';
import 'package:starter_application/features/music/domain/entity/saved_albums_list_entity.dart';

import '../../../../core/repositories/repository.dart';

abstract class IMusicRepository extends Repository {
  Future<Result<AppErrors, RecentlyPlayedTracksListEntity>>
      getRecentlyPlayedTracks();

  Future<Result<AppErrors, EmptyResponse>> updatePlaylistImage(
      UpdatePlaylistImageParam param);

  Future<Result<AppErrors, EmptyResponse>> updatePlaylist(
      UpdatePlaylistParam param);

  Future<Result<AppErrors, SavedAlbumsListEntity>> getSavedAlbums(
      MusicPaginationParam param);
}
