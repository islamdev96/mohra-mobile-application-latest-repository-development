import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/core/ui/appbar/appbar.dart';
import 'package:starter_application/core/ui/error_ui/error_viewer/error_viewer.dart';
import 'package:starter_application/core/ui/error_ui/errors_screens/error_widget.dart';
import 'package:starter_application/core/ui/snackbars/show_snackbar.dart';
import 'package:starter_application/core/ui/widgets/waiting_widget.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/screen/create_playlist_screen.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/playlist_details_screen_notifier.dart';
import 'package:starter_application/generated/l10n.dart';

import 'playlist_details_screen_content.dart';

class PlaylistDetailsScreenParam {
  final String id;
  final String name;
  final bool isUserPlaylist;
  final String image;
  final bool autoPlay;

  PlaylistDetailsScreenParam({
    required this.id,
    required this.name,
    required this.image,
    required this.autoPlay,
    this.isUserPlaylist = false,
  });
}

class PlayListDetailsScreen extends StatefulWidget {
  final PlaylistDetailsScreenParam param;
  static const String routeName = "/PlayListDetailsScreen";

  const PlayListDetailsScreen({
    Key? key,
    required this.param,
  }) : super(key: key);

  @override
  _PlayListDetailsScreenState createState() => _PlayListDetailsScreenState();
}

class _PlayListDetailsScreenState extends State<PlayListDetailsScreen> {
  late final PlayListDetailsScreenNotifier sn;

  @override
  void initState() {
    super.initState();
    sn = PlayListDetailsScreenNotifier(widget.param);
    sn.sendPlaylistsTracksRequest();
  }

  @override
  void dispose() {
    sn.closeNotifier();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<PlayListDetailsScreenNotifier>.value(
      value: sn,
      child: Scaffold(
        appBar: buildCustomAppbar(
          titleText: Translation.current.playlist_details,
          centerTitle: true,
          onBackTap: () {
            Nav.persistentPop(
              context,
              bottomNavController:
                  context.read<MusicMainScreenNotifier>().musicTabController,
            );
          },
          actions: [
            widget.param.isUserPlaylist
                ? InkWell(
                    onTap: () {
                      showMenu(
                          context: context,
                          position: RelativeRect.fromLTRB(
                            1.sw,
                            40.h,
                            0,
                            0,
                          ),
                          items: [
                            PopupMenuItem(
                              child: InkWell(
                                onTap: () {
                                  Nav.to(CreatePlaylistScreen.routeName,
                                      arguments: CreatePlaylistScreenParam(
                                        playlist: sn.param,

                                        /// Update Playlist details on edit success
                                        onPlaylistUpdated: (playlist) =>
                                            sn.param = playlist,
                                      ));
                                },
                                child: Text(
                                  Translation.current.edit_playlist,
                                  style: TextStyle(
                                    fontSize: 55.sp,
                                  ),
                                ),
                              ),
                            )
                          ]);
                    },
                    child: Padding(
                      padding: EdgeInsetsDirectional.only(
                        end: 30.w,
                      ),
                      child: SizedBox(
                        height: 75.sp,
                        width: 75.sp,
                        child: SvgPicture.asset(
                          AppConstants.SVG_MORE_HORIZONTAL,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  )
                : const SizedBox.shrink(),
          ],
        ),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: MultiBlocListener(
          listeners: [
            BlocListener<MusicCubit, MusicState>(
              bloc: sn.libraryCubit,
              listener: (context, state) {
                state.mapOrNull(
                  musicLoadingState: (s) {
                    sn.isLoading = true;
                  },
                  addTrackToPlaylistLoaded: (s) {
                    sn.isLoading = false;
                    showSnackbar(Translation.current.add_song_success);
                    sn.playlistTracksCubit.getPlaylistTracks(
                        AppConfig()
                            .appContext
                            .read<MusicMainScreenNotifier>()
                            .authToken,
                        widget.param.id);
                  },
                  musicErrorState: (s) {
                    sn.isLoading = false;
                    ErrorViewer.showError(
                      context: context,
                      error: s.error,
                      callback: s.callback,
                    );
                  },
                );
              },
            ),
          ],
          child: BlocConsumer<MusicCubit, MusicState>(
            bloc: sn.playlistTracksCubit,
            listener: (context, state) async {
              if (state is PlaylistTracksLoaded) {
                sn.tracks = state.tracksListEntity.tracks;
                if (widget.param.autoPlay) {
                  await sn.spotifySdkWrapper.play(
                    widget.param.id,
                    null,
                    SpotifyType.PLAYLIST,
                  );
                }
              }
            },
            builder: (context, state) {
              return state.maybeMap(
                musicInitState: (s) => WaitingWidget(),
                musicLoadingState: (s) => WaitingWidget(),
                musicErrorState: (s) => ErrorScreenWidget(
                  error: s.error,
                  callback: s.callback,
                ),
                playlistTracksLoaded: (s) => PlayListDetailsScreenContent(),
                orElse: () => const ScreenNotImplementedError(),
              );
            },
          ),
        ),
      ),
    );
  }
}
