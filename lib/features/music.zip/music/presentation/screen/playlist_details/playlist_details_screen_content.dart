import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:spotify_sdk/models/player_state.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/common/style/gaps.dart';
import 'package:starter_application/core/common/utils.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/ui/mansour/button/custom_mansour_button.dart';
import 'package:starter_application/core/ui/widgets/waiting_widget.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/playlist_details_screen_notifier.dart';
import 'package:starter_application/features/music/presentation/widget/music_list2.dart';
import 'package:starter_application/generated/l10n.dart';

class PlayListDetailsScreenContent extends StatefulWidget {
  @override
  State<PlayListDetailsScreenContent> createState() =>
      _PlayListDetailsScreenContentState();
}

class _PlayListDetailsScreenContentState
    extends State<PlayListDetailsScreenContent>
    with SingleTickerProviderStateMixin {
  late PlayListDetailsScreenNotifier sn;
  late final TabController tabController;
  final MusicMainScreenNotifier musicMainScreenNotifier =
      AppConfig().appContext.read<MusicMainScreenNotifier>();

  @override
  void initState() {
    super.initState();
    tabController = TabController(
      length: 4,
      vsync: this,
    );
    tabController.addListener(() {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    sn = Provider.of<PlayListDetailsScreenNotifier>(context);
    sn.context = context;
    return StreamBuilder<PlayerState>(
        stream: musicMainScreenNotifier.playerStateStream,
        initialData: musicMainScreenNotifier.latestPlayerState,
        builder: (context, snapshot) {
          final playerState = snapshot.data;
          return SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Gaps.vGap50,
                _buildPlaylistImage(),
                Gaps.vGap96,
                _buildPlaylistName(),
                Gaps.vGap32,
                _buildArtistsNames(),
                if (sn.tracks.length > 1) Gaps.vGap64,
                if (sn.tracks.length > 1)
                  _buildShuffleAndDownloadButtons(
                    playerState?.playbackOptions.isShuffling ?? false,
                    playerState?.playbackRestrictions.canToggleShuffle ?? false,
                  ),
                Gaps.vGap64,
                _buildSongsList(),
                if (sn.param.isUserPlaylist) Gaps.vGap64,
                if (sn.param.isUserPlaylist) _buildAddSongButton(),
                Gaps.vGap32,
                if (context.watch<MusicMainScreenNotifier>().showSongControl)
                  SizedBox(
                    height: AppConstants.songControlHeight,
                  ),
              ],
            ),
          );
        });
  }

  Widget _buildPlaylistName() {
    return Center(
      child: Text(
        sn.param.name,
        style: TextStyle(
          fontSize: 55.sp,
          fontWeight: FontWeight.bold,
          color: Colors.black,
        ),
      ),
    );
  }

  Widget _buildArtistsNames() {
    return Padding(
      padding: AppConstants.screenPadding,
      child: Center(
        child: Text(
          sn.artistsToString(),
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 50.sp,
            color: AppColors.accentColorLight,
          ),
        ),
      ),
    );
  }

  Widget _buildPlaylistImage() {
    return Center(
      child: Container(
        height: 400.h,
        width: 400.h,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(
              40.r,
            ),
            color: AppColors.accentColorLight,
            image: sn.param.image.contains("http")
                ? DecorationImage(
                    image: NetworkImage(
                      sn.param.image,
                    ),
                    fit: BoxFit.cover,
                  )
                : DecorationImage(
                    image: FileImage(
                      File(
                        sn.param.image,
                      ),
                    ),
                  ),
            boxShadow: [
              BoxShadow(
                color: AppColors.primaryColorLight.withOpacity(0.3),
                spreadRadius: 0.r,
                blurRadius: 70.r,
                offset: Offset(
                  0.r,
                  70.r,
                ),
              ),
            ]),
      ),
    );
  }

  Widget _buildShuffleAndDownloadButtons(bool isShuffleOn, bool canShuffle) {
    return Padding(
      padding: AppConstants.screenPadding,
      child: Row(
        children: [
          Expanded(
            child: CustomMansourButton(
              titleText: isShuffleOn ? Translation.current.shuffle_play : Translation.current.shuffle_off,
              onPressed:
                  canShuffle ? () => sn.onShuffleTap(!isShuffleOn) : null,
              backgroundColor: canShuffle
                  ? AppColors.primaryColorLight
                  : AppColors.accentColorLight,
            ),
          ),
          // Gaps.hGap32,
          // SizedBox(
          //   height: 120.h,
          //   width: 120.h,
          //   child: CustomMansourButton(
          //     backgroundColor: AppColors.primaryColorLight.withOpacity(0.1),
          //     title: Center(
          //       child: SizedBox(
          //         height: 75.h,
          //         width: 75.h,
          //         child: SvgPicture.asset(
          //           AppConstants.SVG_DOWNLOAD2,
          //           color: AppColors.primaryColorLight,
          //         ),
          //       ),
          //     ),
          //   ),
          // ),
        ],
      ),
    );
  }

  Widget _buildSongsList() {
    return MusicList2(
      items: sn.tracks
          .map(
            (e) => MusicItem(
              id: e.id ?? "",
              title: e.name ?? "",
              subtitle: getArtists(
                  e.artists?.map((e) => e.name ?? "").toList() ?? []),
              image: (e.album?.images?.length ?? 0) > 0
                  ? e.album!.images![0].url
                  : null,
              type: SpotifyType.TRACK,
            ),
          )
          .toList(),
      showFavoriteIcon: true,
      onFavoriteIconTap: (songIndex) =>
          context.read<MusicMainScreenNotifier>().saveUnSaveSpotifyItem(
                sn.tracks[songIndex].id ?? "",
                type: SpotifyType.TRACK,
              ),
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      padding: AppConstants.screenPadding,
      onItemTap: (songIndex) => sn.onSongTap(
        songIndex: songIndex,
        playlistId: sn.param.id,
        playlistName: sn.param.name,
        playlistImage: sn.param.image,
      ),
    );
  }

  Widget _buildAddSongButton() {
    if (sn.isLoading) return WaitingWidget();
    return Center(
      child: CustomMansourButton(
        width: 0.8.sw,
        titleText: Translation.current.add_song,
        onPressed: sn.onAddSongTap,
      ),
    );
  }
}
