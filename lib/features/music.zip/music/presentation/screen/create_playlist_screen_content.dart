import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/common/style/gaps.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/ui/appbar/appbar.dart';
import 'package:starter_application/core/ui/mansour/button/custom_mansour_button.dart';
import 'package:starter_application/core/ui/widgets/custom_text_field.dart';
import 'package:starter_application/core/ui/widgets/waiting_widget.dart';
import 'package:starter_application/features/moment/presentation/widget/pick_images_grid.dart';
import 'package:starter_application/generated/l10n.dart';

import '../screen/../state_m/provider/create_playlist_screen_notifier.dart';

class CreatePlaylistScreenContent extends StatefulWidget {
  @override
  State<CreatePlaylistScreenContent> createState() =>
      _CreatePlaylistScreenContentState();
}

class _CreatePlaylistScreenContentState
    extends State<CreatePlaylistScreenContent> {
  late CreatePlaylistScreenNotifier sn;

  @override
  Widget build(BuildContext context) {
    sn = Provider.of<CreatePlaylistScreenNotifier>(context);
    sn.context = context;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildAppbarTitle(sn.isCreate ? Translation.current.create_playlist : Translation.current.edit_playlist),
        Gaps.vGap64,
        buildPickPlaylistImage(),
        Gaps.vGap64,
        _buildPlayListNameTextField(),
        const Spacer(),
        _buildCreateButton(),
      ],
    );
  }

  Widget buildPickPlaylistImage() {
    return PickImagesGrid(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: AppConstants.screenPadding,
      onImagesPicked: sn.onImagesPicked,
      imagesPaths: sn.playlistImage != null ? [sn.playlistImage!] : [],
      maxImagesCount: 1,
      imageQuality: 5,
      disableDeleteImage: true,
      onImageDeleted: null,
      disableMessage: Translation.current.create_playlist_before_adding_photo_error,

      /// The user couldn't update the image before creating the playlist
      disable: sn.isCreate,
    );
  }

  Widget _buildPlayListNameTextField() {
    return Padding(
      padding: AppConstants.screenPadding,
      child: CustomTextField(
        textKey: sn.playlistNameKey,
        controller: sn.playlistNameController,
        focusNode: sn.playlistFocusNode,
        textInputAction: TextInputAction.done,
        autofocus: true,
        keyboardType: TextInputType.text,
        maxLines: 1,
        minLines: 1,
        border: InputBorder.none,
        showCursor: true,
        cursorHeight: 80.h,
        hintText: Translation.current.playlist_name_hint,
        hintStyle: TextStyle(
          fontSize: 60.sp,
          color: AppColors.accentColorLight,
        ),
        cursorColor: AppColors.primaryColorLight,
        fontSize: 60.sp,
        onChanged: sn.onPlayListNameChanged,
      ),
    );
  }

  Widget _buildCreateButton() {
    if (sn.isLoading)
      return Padding(
        padding: EdgeInsets.only(
          bottom: 32.h,
        ),
        child: WaitingWidget(),
      );
    return CustomMansourButton(
      backgroundColor: sn.isPlaylistNameEmpty
          ? AppColors.mansourLightGreyColor_3
          : AppColors.primaryColorLight,
      borderRadius: Radius.zero,
      titleText: sn.isCreate ? Translation.current.create : Translation.current.update,
      onPressed: sn.playlistNameController.text.isEmpty
          ? null
          : sn.onCreatePlaylistTap,
    );
  }
}
