import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_progress_hud/flutter_progress_hud.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_search_screen_notifier.dart';

import 'music_search_screen_content.dart';

class MusicSearchScreen extends StatefulWidget {
  static const String routeName = "/MusicSearchScreen";

  const MusicSearchScreen({
    Key? key,
  }) : super(key: key);

  @override
  _MusicSearchScreenState createState() => _MusicSearchScreenState();
}

class _MusicSearchScreenState extends State<MusicSearchScreen> {
  late final MusicSearchScreenNotifier sn = MusicSearchScreenNotifier();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    sn.closeNotifier();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ProgressHUD(
      child: ChangeNotifierProvider<MusicSearchScreenNotifier>.value(
        value: sn,
        child: MultiBlocListener(
          listeners: [
            BlocListener<MusicCubit, MusicState>(
              bloc: sn.searchTracksCubit,
              listener: (context, state) {
                if (state is SearchTracksLoaded) {
                  sn.tracks = state.tracks;
                }
              },
            ),
            BlocListener<MusicCubit, MusicState>(
              bloc: sn.searchAlbumsCubit,
              listener: (context, state) {
                if (state is SearchAlbumsLoaded) {
                  sn.albums = state.albums;
                }
              },
            ),
          ],
          child: Scaffold(
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            body: MusicSearchScreenContent(),
          ),
        ),
      ),
    );
  }
}
