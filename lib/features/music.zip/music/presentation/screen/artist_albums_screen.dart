import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/core/ui/appbar/appbar.dart';
import 'package:starter_application/core/ui/error_ui/errors_screens/error_widget.dart';
import 'package:starter_application/core/ui/widgets/waiting_widget.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/generated/l10n.dart';

import '../screen/../state_m/provider/artist_albums_screen_notifier.dart';
import 'artist_albums_screen_content.dart';

class ArtistAlbumsScreenParam {
  final String id;
  final String name;
  final String image;
  ArtistAlbumsScreenParam({
    required this.id,
    required this.name,
    required this.image,
  });
}

class ArtistAlbumsScreen extends StatefulWidget {
  static const String routeName = "/ArtistAlbumsScreen";
  final ArtistAlbumsScreenParam param;
  const ArtistAlbumsScreen({
    Key? key,
    required this.param,
  }) : super(key: key);

  @override
  _ArtistAlbumsScreenState createState() => _ArtistAlbumsScreenState();
}

class _ArtistAlbumsScreenState extends State<ArtistAlbumsScreen> {
  late final ArtistAlbumsScreenNotifier sn;

  @override
  void initState() {
    super.initState();
    sn = ArtistAlbumsScreenNotifier(
      param: widget.param,
    );
    sn.getArtistAlbums();
  }

  @override
  void dispose() {
    sn.closeNotifier();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<ArtistAlbumsScreenNotifier>.value(
      value: sn,
      child: Scaffold(
        appBar: buildCustomAppbar(
            titleText: Translation.current.artist_albums_title(widget.param.name),
            onBackTap: () => Nav.pop(context)),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: BlocConsumer<MusicCubit, MusicState>(
          bloc: sn.artistAlbumsCubit,
          listener: (context, state) {
            state.mapOrNull(getArtistAlbumsLoaded: (s) {
              sn.albums = s.albums;
            });
          },
          builder: (context, state) {
            return state.maybeMap(
                musicInitState: (s) => WaitingWidget(),
                musicLoadingState: (s) => WaitingWidget(),
                getArtistAlbumsLoaded: (s) => ArtistAlbumsScreenContent(),
                musicErrorState: (s) => ErrorScreenWidget(
                      error: s.error,
                      callback: s.callback,
                    ),
                orElse: () => const ScreenNotImplementedError());
          },
        ),
      ),
    );
  }
}
