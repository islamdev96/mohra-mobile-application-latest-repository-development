import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_progress_hud/flutter_progress_hud.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/ui/appbar/appbar.dart';
import 'package:starter_application/core/ui/error_ui/error_viewer/error_viewer.dart';
import 'package:starter_application/core/ui/snackbars/show_snackbar.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/generated/l10n.dart';

import '../screen/../state_m/provider/add_tracks_to_playlist_screen_notifier.dart';
import 'add_tracks_to_playlist_screen_content.dart';

class AddTracksToPlaylistScreenParam {
  String playlistId;
  VoidCallback onTrackAdded;
  AddTracksToPlaylistScreenParam({
    required this.playlistId,
    required this.onTrackAdded,
  });
}

class AddTracksToPlaylistScreen extends StatefulWidget {
  static const String routeName = "/AddTracksToPlaylistScreen";
  final AddTracksToPlaylistScreenParam param;

  const AddTracksToPlaylistScreen({
    Key? key,
    required this.param,
  }) : super(key: key);

  @override
  _AddTracksToPlaylistScreenState createState() =>
      _AddTracksToPlaylistScreenState();
}

class _AddTracksToPlaylistScreenState extends State<AddTracksToPlaylistScreen> {
  late final AddTracksToPlaylistScreenNotifier sn;

  @override
  void initState() {
    super.initState();
    sn = AddTracksToPlaylistScreenNotifier(widget.param);
  }

  @override
  void dispose() {
    sn.closeNotifier();

    /// Refresh userPlaylists
    AppConfig()
        .appContext
        .read<MusicMainScreenNotifier>()
        .refreshUserPlaylists();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ProgressHUD(
      child: ChangeNotifierProvider<AddTracksToPlaylistScreenNotifier>.value(
        value: sn,
        child: MultiBlocListener(
          listeners: [
            BlocListener<MusicCubit, MusicState>(
              bloc: sn.searchCubit,
              listener: (context, state) {
                if (state is SearchTracksLoaded) {
                  sn.tracks = state.tracks;
                }
              },
            ),
            BlocListener<MusicCubit, MusicState>(
              bloc: sn.addTrackCubit,
              listener: (context, state) {
                state.mapOrNull(musicLoadingState: (_) {
                  sn.isLoading = true;
                  ProgressHUD.of(context)!.show();
                }, addTrackToPlaylistLoaded: (s) {
                  sn.isLoading = false;
                  ProgressHUD.of(context)!.dismiss();
                  sn.tracks.removeWhere(
                      (element) => element.id == sn.currentTrackId);
                  sn.currentTrackId = null;
                  showSnackbar(Translation.current.add_song_success);

                  widget.param.onTrackAdded();
                }, musicErrorState: (s) {
                  ProgressHUD.of(context)!.dismiss();

                  sn.isLoading = false;
                  ErrorViewer.showError(
                    context: context,
                    error: s.error,
                    callback: s.callback,
                  );
                });
              },
            ),
          ],
          child: Scaffold(
            appBar: buildCustomAppbar(),
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            body: AddTracksToPlaylistScreenContent(),
          ),
        ),
      ),
    );
  }
}
