import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:spotify/spotify.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/common/style/gaps.dart';
import 'package:starter_application/core/common/utils.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/errors/app_errors.dart' as error;
import 'package:starter_application/core/results/result.dart';
import 'package:starter_application/core/ui/error_ui/errors_screens/error_widget.dart';
import 'package:starter_application/core/ui/mansour/search_textfield.dart';
import 'package:starter_application/core/ui/screens/empty_screen_wiget.dart';
import 'package:starter_application/core/ui/widgets/pagination_widget.dart';
import 'package:starter_application/core/ui/widgets/waiting_widget.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_api_wrapper.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_search_screen_notifier.dart';
import 'package:starter_application/features/music/presentation/widget/music_card2.dart';
import 'package:starter_application/generated/l10n.dart';

class MusicSearchScreenContent extends StatefulWidget {
  @override
  State<MusicSearchScreenContent> createState() =>
      _MusicSearchScreenContentState();
}

class _MusicSearchScreenContentState extends State<MusicSearchScreenContent>
    with SingleTickerProviderStateMixin {
  late MusicSearchScreenNotifier sn;

  final _tracksController = RefreshController();
  final _albumsController = RefreshController();
  late final TabController tabController;
  @override
  void initState() {
    super.initState();
    tabController = TabController(
      length: 2,
      vsync: this,
    );
    tabController.addListener(() {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    sn = Provider.of<MusicSearchScreenNotifier>(context);
    sn.context = context;
    return Padding(
      padding: AppConstants.screenPadding,
      child: Column(
        children: [
          SizedBox(
            height: ScreenUtil().statusBarHeight,
          ),
          Gaps.vGap32,
          _buildSearchTextField(),
          Gaps.vGap32,
          _buildTabBar(),
          Gaps.vGap32,
          Expanded(
            child: TabBarView(
              controller: tabController,
              children: [
                __buildTracksListBlocBuilder(),
                __buildAlbumsListBlocBuilder(),
              ],
            ),
          ),
          if (context.watch<MusicMainScreenNotifier>().showSongControl)
            SizedBox(
              height: AppConstants.songControlHeight,
            ),
        ],
      ),
    );
  }

  Widget _buildSearchTextField() {
    final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(100),
      borderSide: const BorderSide(
        color: Colors.transparent,
      ),
    );
    return SearchTextField(
      textKey: sn.searchKey,
      controller: sn.searchController,
      focusNode: sn.searchFocusNode,
      backgroundColor: AppColors.mansourLightGreyColor_18,
      onFieldSubmitted: (v) => sn.onSearchSubmitted(),
      iconColor: AppColors.mansourLightGreyColor_8,
      trailing: InkWell(
        onTap: sn.onClearTextTap,
        child: SizedBox(
          height: 70.h,
          width: 70,
          child: const Icon(
            Icons.close,
            color: AppColors.mansourBackArrowColor,
          ),
        ),
      ),
    );
  }

  Widget _buildTabBar() {
    return TabBar(
      controller: tabController,
      labelStyle: TextStyle(
        color: AppColors.primaryColorLight,
        fontSize: 45.sp,
        fontWeight: FontWeight.w600,
      ),
      labelColor: AppColors.primaryColorLight,
      unselectedLabelStyle: TextStyle(
        color: AppColors.accentColorLight,
        fontSize: 45.sp,
        fontWeight: FontWeight.w600,
      ),
      unselectedLabelColor: AppColors.accentColorLight,
      indicatorColor: AppColors.primaryColorLight,
      indicatorWeight: 3,
      labelPadding: EdgeInsetsDirectional.only(
        bottom: 40.h,
        end: AppConstants.hPadding,
        start: AppConstants.hPadding,
      ),
      indicatorSize: TabBarIndicatorSize.label,
      tabs: [
        const Text(
          "Songs",
        ),
        const Text(
          "Albums",
        ),
      ],
      isScrollable: true,
      onTap: sn.onTabBarItemTap,
    );
  }

  Widget _buildEmptyScreen() {
    return EmptyScreenWidget(
      title: "No results found",
      onButtonPressed: () => sn.onSearchSubmitted(),
    );
  }

  Widget __buildTracksListBlocBuilder() {
    return BlocBuilder<MusicCubit, MusicState>(
      bloc: sn.searchTracksCubit,
      builder: (context, state) {
        return state.maybeMap(
          musicInitState: (s) =>  EmptyScreenWidget(
            title: Translation.current.search_for_songs,
          ),
          musicLoadingState: (s) => WaitingWidget(),
          searchTracksLoaded: (s) => _buildTracksPaginationWidget(),
          recentlyPlayedTracksLoaded: (_) => const ScreenNotImplementedError(),
          musicErrorState: (s) => ErrorScreenWidget(
            error: s.error,
            callback: s.callback,
          ),
          orElse: () => const ScreenNotImplementedError(),
        );
      },
    );
  }

  Widget _buildTracksPaginationWidget() {
    if ((sn.tracks.length == 0)) return _buildEmptyScreen();
    return PaginationWidget<Track>(
      refreshController: _tracksController,
      items: sn.tracks,
      getItems: (page) async {
        final spotifyApiWrapper = SpotifyApiWrapper(
          AppConfig().appContext.read<MusicMainScreenNotifier>().authToken,
        );

        final tracks = await spotifyApiWrapper.searchTracks(
          search: sn.searchController.text,
          page: page,
        );
        return Result(
          data: tracks,
          error: tracks == null
              ? error.CustomError(
                  message: Translation.current.errorOccurred,
                )
              : null,
        );
      },
      enablePullUp: sn.tracks.length > 9,
      onDataFetched: (newList, _) {
        sn.tracks = newList;
      },
      child: _buildTracksList(),
    );
  }

  Widget _buildTracksList() {
    return ListView.separated(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.only(
          bottom: 64.h,
        ),
        itemBuilder: (context, index) {
          final track = sn.tracks[index];
          return MusicCard2(
            title: track.name ?? "",
            leadingImage: (track.album?.images?.length ?? 0) > 0
                ? track.album!.images![0].url
                : null,
            subtitle: getArtists(
                track.album?.artists?.map((e) => e.name ?? "").toList() ?? []),
            onItemTap: () => sn.onSongTap(track.id ?? ""),
            trailingWidget: InkWell(
              focusColor: AppColors.primaryColorLight.withOpacity(0.4),
              hoverColor: AppColors.primaryColorLight.withOpacity(0.4),
              splashColor: AppColors.primaryColorLight.withOpacity(0.4),
              highlightColor: AppColors.primaryColorLight.withOpacity(0.4),
              borderRadius: BorderRadius.circular(
                55.r,
              ),
              onTap: () =>
                  context.read<MusicMainScreenNotifier>().saveUnSaveSpotifyItem(
                        track.id ?? "",
                        type: SpotifyType.TRACK,
                      ),
              child: SizedBox(
                height: 55.h,
                width: 55.h,
                child: SvgPicture.asset(
                  AppConstants.SVG_LOVE,
                  color: context.watch<MusicMainScreenNotifier>().isItemSaved(
                            track.id ?? "",
                            type: SpotifyType.TRACK,
                          )
                      ? AppColors.primaryColorLight
                      : AppColors.mansourGrey,
                ),
              ),
            ),
          );
        },
        separatorBuilder: (context, index) {
          return Gaps.vGap32;
        },
        itemCount: sn.tracks.length);
  }

  //Todo
  Widget __buildAlbumsListBlocBuilder() {
    return BlocBuilder<MusicCubit, MusicState>(
      bloc: sn.searchAlbumsCubit,
      builder: (context, state) {
        return state.maybeMap(
          musicInitState: (s) =>  EmptyScreenWidget(
            title: Translation.current.search_for_albums,
          ),
          musicLoadingState: (s) => WaitingWidget(),
          searchAlbumsLoaded: (s) => _buildAlbumsPaginationWidget(),
          musicErrorState: (s) => ErrorScreenWidget(
            error: s.error,
            callback: s.callback,
          ),
          orElse: () => const ScreenNotImplementedError(),
        );
      },
    );
  }

  Widget _buildAlbumsPaginationWidget() {
    if ((sn.albums.length == 0)) return _buildEmptyScreen();
    return PaginationWidget<AlbumSimple>(
      refreshController: _albumsController,
      items: sn.albums,
      getItems: (page) async {
        final spotifyApiWrapper = SpotifyApiWrapper(
          AppConfig().appContext.read<MusicMainScreenNotifier>().authToken,
        );

        final albums = await spotifyApiWrapper.searchAlbums(
          search: sn.searchController.text,
          page: page,
        );
        return Result(
          data: albums,
          error: albums == null
              ? error.CustomError(
                  message: Translation.current.errorOccurred,
                )
              : null,
        );
      },
      enablePullUp: sn.albums.length > 9,
      onDataFetched: (newList, _) {
        sn.albums = newList;
      },
      child: _buildAlbumsList(),
    );
  }

  Widget _buildAlbumsList() {
    return ListView.separated(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.only(
          bottom: 64.h,
        ),
        itemBuilder: (context, index) {
          final album = sn.albums[index];
          return MusicCard2(
            title: album.name ?? "",
            leadingImage:
                (album.images?.length ?? 0) > 0 ? album.images![0].url : null,
            subtitle: getArtists(
                album.artists?.map((e) => e.name ?? "").toList() ?? []),
            onItemTap: () => sn.onAlbumTap(album),
            trailingWidget: InkWell(
              focusColor: AppColors.primaryColorLight.withOpacity(0.4),
              hoverColor: AppColors.primaryColorLight.withOpacity(0.4),
              splashColor: AppColors.primaryColorLight.withOpacity(0.4),
              highlightColor: AppColors.primaryColorLight.withOpacity(0.4),
              borderRadius: BorderRadius.circular(
                55.r,
              ),
              onTap: () =>
                  context.read<MusicMainScreenNotifier>().saveUnSaveSpotifyItem(
                        album.id ?? "",
                        type: SpotifyType.ALBUM,
                      ),
              child: SizedBox(
                height: 55.h,
                width: 55.h,
                child: SvgPicture.asset(
                  AppConstants.SVG_LOVE,
                  color: context.watch<MusicMainScreenNotifier>().isItemSaved(
                            album.id ?? "",
                            type: SpotifyType.ALBUM,
                          )
                      ? AppColors.primaryColorLight
                      : AppColors.mansourGrey,
                ),
              ),
            ),
          );
        },
        separatorBuilder: (context, index) {
          return Gaps.vGap32;
        },
        itemCount: sn.albums.length);
  }
}
