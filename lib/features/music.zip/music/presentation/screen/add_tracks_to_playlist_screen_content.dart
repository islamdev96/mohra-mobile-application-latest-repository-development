import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:spotify/spotify.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/common/style/gaps.dart';
import 'package:starter_application/core/common/utils.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/errors/app_errors.dart' as error;
import 'package:starter_application/core/results/result.dart';
import 'package:starter_application/core/ui/error_ui/errors_screens/error_widget.dart';
import 'package:starter_application/core/ui/mansour/search_textfield.dart';
import 'package:starter_application/core/ui/screens/empty_screen_wiget.dart';
import 'package:starter_application/core/ui/widgets/pagination_widget.dart';
import 'package:starter_application/core/ui/widgets/waiting_widget.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_api_wrapper.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/features/music/presentation/widget/music_card2.dart';
import 'package:starter_application/generated/l10n.dart';

import '../screen/../state_m/provider/add_tracks_to_playlist_screen_notifier.dart';

class AddTracksToPlaylistScreenContent extends StatefulWidget {
  @override
  State<AddTracksToPlaylistScreenContent> createState() =>
      _AddTracksToPlaylistScreenContentState();
}

class _AddTracksToPlaylistScreenContentState
    extends State<AddTracksToPlaylistScreenContent> {
  late AddTracksToPlaylistScreenNotifier sn;

  final _refreshContorller = RefreshController();

  @override
  Widget build(BuildContext context) {
    sn = Provider.of<AddTracksToPlaylistScreenNotifier>(context);
    sn.context = context;
    return Padding(
      padding: AppConstants.screenPadding,
      child: Column(
        children: [
          Gaps.vGap32,
          _buildSearchTextField(),
          Gaps.vGap32,
          __buildTracksListBlocuilder(),
        ],
      ),
    );
  }

  // Widget _buildAppbar() {
  Widget _buildSearchTextField() {
    final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(100),
      borderSide: const BorderSide(
        color: Colors.transparent,
      ),
    );
    return SearchTextField(
      textKey: sn.searchKey,
      controller: sn.searchController,
      focusNode: sn.searchFocusNode,
      backgroundColor: AppColors.mansourLightGreyColor_18,
      onFieldSubmitted: (v) => sn.onSearchSubmitted(),
    );
  }

  Widget _buildEmpyScreen() {
    return EmptyScreenWidget(
      title: Translation.current.no_results_found,
      onButtonPressed: () => sn.onSearchSubmitted(),
    );
  }

  Widget __buildTracksListBlocuilder() {
    return Expanded(
      child: BlocBuilder<MusicCubit, MusicState>(
        bloc: sn.searchCubit,
        builder: (context, state) {
          return state.maybeMap(
            musicInitState: (s) =>  EmptyScreenWidget(
              title: Translation.current.search_for_songs,
            ),
            musicLoadingState: (s) => WaitingWidget(),
            searchTracksLoaded: (s) => _buildTracksPaginationWidget(),
            musicErrorState: (s) => ErrorScreenWidget(
              error: s.error,
              callback: s.callback,
            ),
            orElse: ()=> const ScreenNotImplementedError(),
          );
        },
      ),
    );
  }

  Widget _buildTracksPaginationWidget() {
    if ((sn.tracks.length == 0)) return _buildEmpyScreen();
    return PaginationWidget<Track>(
      refreshController: _refreshContorller,
      items: sn.tracks,
      getItems: (page) async {
        final spotifyApiWrapper = SpotifyApiWrapper(
          AppConfig().appContext.read<MusicMainScreenNotifier>().authToken,
        );

        final tracks = await spotifyApiWrapper.searchTracks(
          search: sn.searchController.text,
          page: page,
        );
        return Result(
          data: tracks,
          error: tracks == null
              ? error.CustomError(
                  message: Translation.current.errorOccurred,
                )
              : null,
        );
      },
      enablePullUp: sn.tracks.length > 9,
      onDataFetched: (newList, _) {
        sn.tracks = newList;
      },
      child: _buildTracksList(),
    );
  }

  Widget _buildTracksList() {
    return ListView.separated(
        itemBuilder: (context, index) {
          final track = sn.tracks[index];
          return MusicCard2(
            title: track.name ?? "",
            leadingImage: (track.album?.images?.length ?? 0) > 0
                ? track.album!.images![0].url
                : null,
            subtitle: getArtists(
                track.album?.artists?.map((e) => e.name ?? "").toList() ?? []),
            trailingWidget: SizedBox(
              height: 60.h,
              width: 60.sh,
              child: InkWell(
                onTap: () => sn.onAddTrackTap(track.id ?? ""),
                child: const Icon(
                  Icons.add_circle_outline,
                  color: AppColors.primaryColorLight,
                ),
              ),
            ),
          );
        },
        separatorBuilder: (context, index) {
          return Gaps.vGap32;
        },
        itemCount: sn.tracks.length);
  }
}
