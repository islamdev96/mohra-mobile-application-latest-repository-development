import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/core/ui/appbar/appbar.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';

import '../../state_m/provider/my_library_screen_notifier.dart';
import 'my_library_screen_content.dart';

class MyLibraryScreen extends StatefulWidget {
  static const String routeName = "/MyLibraryScreen";

  const MyLibraryScreen({Key? key}) : super(key: key);

  @override
  _MyLibraryScreenState createState() => _MyLibraryScreenState();
}

class _MyLibraryScreenState extends State<MyLibraryScreen> {
  final sn = MyLibraryScreenNotifier();

  @override
  void initState() {
    super.initState();
    //Todo refactoring (create widgets and refresher for each tab)
    sn.getUserPlaylists();
    sn.getUserSavedAlbums();
    // sn.getUserSavedTracks();
    sn.getUserTopArtists();
  }

  @override
  void dispose() {
    sn.closeNotifier();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<MyLibraryScreenNotifier>.value(
      value: sn,
      child: Scaffold(
        appBar: buildCustomAppbar(
          onBackTap: () {
            Nav.persistentPop(
              context,
              bottomNavController:
                  context.read<MusicMainScreenNotifier>().musicTabController,
            );
          },
          actions: [
            Padding(
              padding: EdgeInsetsDirectional.only(
                end: 30.w,
              ),
              child: SizedBox(
                height: 75.sp,
                width: 75.sp,
                child: SvgPicture.asset(
                  AppConstants.SVG_SEARCH,
                  color: Colors.black,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: MyLibraryScreenContent(),
      ),
    );
  }
}
