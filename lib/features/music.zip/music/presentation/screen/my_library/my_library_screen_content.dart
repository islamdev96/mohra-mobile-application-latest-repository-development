import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/common/style/gaps.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/ui/appbar/appbar.dart';
import 'package:starter_application/core/ui/error_ui/errors_screens/error_widget.dart';
import 'package:starter_application/core/ui/widgets/empty_error_widget.dart';
import 'package:starter_application/core/ui/widgets/waiting_widget.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/features/music/presentation/widget/music_list2.dart';
import 'package:starter_application/generated/l10n.dart';

import '../../state_m/provider/my_library_screen_notifier.dart';

class MyLibraryScreenContent extends StatefulWidget {
  @override
  State<MyLibraryScreenContent> createState() => _MyLibraryScreenContentState();
}

class _MyLibraryScreenContentState extends State<MyLibraryScreenContent>
    with SingleTickerProviderStateMixin {
  late MyLibraryScreenNotifier sn;
  late final TabController tabController;

  @override
  void initState() {
    super.initState();
    tabController = TabController(
      length: 4,
      vsync: this,
    );
    tabController.addListener(() {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    sn = Provider.of<MyLibraryScreenNotifier>(context);
    sn.context = context;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildAppbarTitle(
          Translation.current.library,
        ),
        Gaps.vGap32,
        _buildTabBar(),
        Gaps.vGap50,
        Expanded(
          child: TabBarView(
            controller: tabController,
            children: [
              _buildPlaylists(),
              _buildArtists(),
              _buildSavedAlbums(),
              _buildSavedTracks(),
            ],
          ),
        ),
        if (context.watch<MusicMainScreenNotifier>().showSongControl)
          SizedBox(
            height: AppConstants.songControlHeight,
          ),
      ],
    );
  }

  Widget _buildPlaylists() {
    return BlocBuilder<MusicCubit, MusicState>(
      bloc: AppConfig()
          .appContext
          .read<MusicMainScreenNotifier>()
          .userPlaylistsCubit,
      builder: (context, state) {
        return state.maybeMap(
          musicInitState: (s) => WaitingWidget(),
          musicLoadingState: (s) => WaitingWidget(),
          userPlaylistsLoaded: (s) => MusicList2(
            items: [
              MusicItem(
                id: "1",
                title: Translation.current.create_playlist,
                icon: AppConstants.SVG_PLAY_LIST2,
                type: null,
              ),
              ...s.playlistsEntity.playlists
                  .map(
                    (e) => MusicItem(
                      id: e.id ?? "",
                      title: e.name ?? "",
                      subtitle:
                          "${e.tracksLink?.total?.toString() ?? 0} ${Translation.current.songs}",
                      image:
                          (e.images?.length ?? 0) > 0 ? e.images![0].url : "",
                      type: SpotifyType.PLAYLIST,
                    ),
                  )
                  .toList()
            ],
            onItemTap: (index) => sn.onItemTap(index,
                index == 0 ? null : s.playlistsEntity.playlists[index - 1]),
            physics: const BouncingScrollPhysics(),
          ),
          musicErrorState: (s) => ErrorScreenWidget(
            error: s.error,
            callback: s.callback,
          ),
          orElse: () => const ScreenNotImplementedError(),
        );
      },
    );
  }

  Widget _buildArtists() {
    return BlocBuilder<MusicCubit, MusicState>(
      bloc: sn.topArtistsCubit,
      builder: (context, state) {
        return state.maybeMap(
          musicInitState: (s) => WaitingWidget(),
          musicLoadingState: (s) => WaitingWidget(),
          userTopArtistsLoaded: (s) => s.artistsEntity.artists.length == 0
              ? EmptyErrorScreenWidget(
                  message: Translation.current.no_artists_now)
              : MusicList2(
                  items: s.artistsEntity.artists
                      .map(
                        (e) => MusicItem(
                          id: e.id ?? "",
                          title: e.name ?? "",
                          image: (e.images?.length ?? 0) > 0
                              ? e.images![0].url
                              : "",
                          type: SpotifyType.ARTIST,
                        ),
                      )
                      .toList(),
                  physics: const BouncingScrollPhysics(),
                  onItemTap: (index) =>
                      sn.onArtistTap(s.artistsEntity.artists[index]),
                ),
          musicErrorState: (s) => ErrorScreenWidget(
            error: s.error,
            callback: s.callback,
          ),
          orElse: () => const ScreenNotImplementedError(),
        );
      },
    );
  }

  Widget _buildSavedTracks() {
    return BlocBuilder<MusicCubit, MusicState>(
      bloc: context.read<MusicMainScreenNotifier>().savedTracksCubit,
      builder: (context, state) {
        return state.maybeMap(
          musicInitState: (s) => WaitingWidget(),
          musicLoadingState: (s) => WaitingWidget(),
          userSavedTracksLoaded: (s) => s.tracksEntity.tracks.length == 0
              ? EmptyErrorScreenWidget(
                  message: Translation.current.no_saved_songs_now)
              : MusicList2(
                  items: s.tracksEntity.tracks
                      .map(
                        (e) => MusicItem(
                          id: e.track?.id ?? "",
                          title: e.track?.name ?? "",
                          image: (e.track?.album?.images?.length ?? 0) > 0
                              ? e.track!.album!.images![0].url
                              : "",
                          type: SpotifyType.TRACK,
                        ),
                      )
                      .toList(),
                  physics: const BouncingScrollPhysics(),
                  onItemTap: (songIndex) => sn.onSavedSongTap(
                      s.tracksEntity.tracks[songIndex].track?.id ?? ""),
                  showFavoriteIcon: true,
                  onFavoriteIconTap: (songIndex) => context
                      .read<MusicMainScreenNotifier>()
                      .saveUnSaveSpotifyItem(
                        s.tracksEntity.tracks[songIndex].track?.id ?? "",
                        type: SpotifyType.TRACK,
                      ),
                ),
          musicErrorState: (s) => ErrorScreenWidget(
            error: s.error,
            callback: s.callback,
          ),
          orElse: () => const ScreenNotImplementedError(),
        );
      },
    );
  }

  Widget _buildTabBar() {
    return TabBar(
      controller: tabController,
      labelStyle: TextStyle(
        color: AppColors.primaryColorLight,
        fontSize: 45.sp,
        fontWeight: FontWeight.w600,
      ),
      labelColor: AppColors.primaryColorLight,
      unselectedLabelStyle: TextStyle(
        color: AppColors.accentColorLight,
        fontSize: 45.sp,
        fontWeight: FontWeight.w600,
      ),
      unselectedLabelColor: AppColors.accentColorLight,
      indicatorColor: AppColors.primaryColorLight,
      indicatorWeight: 3,
      labelPadding: EdgeInsetsDirectional.only(
        bottom: 40.h,
        end: AppConstants.hPadding,
        start: AppConstants.hPadding,
      ),
      indicatorSize: TabBarIndicatorSize.label,
      tabs: [
        Text(
          Translation.current.playlists,
        ),
        Text(
          Translation.current.artists,
        ),
        Text(
          Translation.current.albums,
        ),
        Text(
          Translation.current.favorite,
        ),
      ],
      isScrollable: true,
      onTap: sn.onTabBarItemTap,
    );
  }

  _buildSavedAlbums() {
    return BlocBuilder<MusicCubit, MusicState>(
      bloc: context.read<MusicMainScreenNotifier>().savedAlbumsCubit,
      builder: (context, state) {
        return state.maybeMap(
          musicInitState: (s) => WaitingWidget(),
          musicLoadingState: (s) => WaitingWidget(),
          getSavedAlbumsLoaded: (s) => s.savedAlbumsListEntity.items.length == 0
              ? EmptyErrorScreenWidget(
                  message: Translation.current.no_saved_albums_now)
              : MusicList2(
                  items: s.savedAlbumsListEntity.items
                      .map(
                        (e) => MusicItem(
                          id: e.album?.id ?? "",
                          title: e.album?.name ?? "",
                          image: (e.album?.images.length ?? 0) > 0
                              ? e.album!.images[0].url
                              : "",
                          type: SpotifyType.ALBUM,
                        ),
                      )
                      .toList(),
                  physics: const BouncingScrollPhysics(),
                  onItemTap: (index) => sn.onSavedAlbumTap(
                      s.savedAlbumsListEntity.items[index].album),
                  showFavoriteIcon: true,
                  onFavoriteIconTap: (albumIndex) => context
                      .read<MusicMainScreenNotifier>()
                      .saveUnSaveSpotifyItem(
                          s.savedAlbumsListEntity.items[albumIndex].album?.id ??
                              "",
                          type: SpotifyType.ALBUM),
                ),
          musicErrorState: (s) => ErrorScreenWidget(
            error: s.error,
            callback: s.callback,
          ),
          orElse: () => const ScreenNotImplementedError(),
        );
      },
    );
  }
}
