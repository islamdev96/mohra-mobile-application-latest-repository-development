import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_progress_hud/flutter_progress_hud.dart';
import 'package:provider/provider.dart';
import 'package:spotify/spotify.dart';
import 'package:spotify_sdk/spotify_sdk.dart';
import 'package:starter_application/core/common/utils.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/core/params/no_params.dart';
import 'package:starter_application/core/ui/appbar/appbar.dart';
import 'package:starter_application/core/ui/error_ui/error_viewer/error_viewer.dart';
import 'package:starter_application/core/ui/error_ui/error_viewer/snack_bar/errv_snack_bar_options.dart';
import 'package:starter_application/core/ui/error_ui/error_viewer/snack_bar/show_error_snackbar.dart';
import 'package:starter_application/core/ui/widgets/waiting_widget.dart';
import 'package:starter_application/di/service_locator.dart';
import 'package:starter_application/features/music/domain/usecase/recently_played_tracks_usecase.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/select_tracks_screen_notifier.dart';
import 'package:starter_application/generated/l10n.dart';

import 'select_tracks_screen_content.dart';

class SelectTracksScreenParam {
  Function(List<Track> tracks)? onTracksSelected;
  SelectTracksScreenParam({
    this.onTracksSelected,
  });
}

class SelectTracksScreen extends StatefulWidget {
  static const String routeName = "/SelectTracksScreen";
  final SelectTracksScreenParam param;

  const SelectTracksScreen({
    Key? key,
    required this.param,
  }) : super(key: key);

  @override
  _SelectTracksScreenState createState() => _SelectTracksScreenState();
}

class _SelectTracksScreenState extends State<SelectTracksScreen> {
  late final SelectTracksScreenNotifier sn;
  late final Future<String?> spotifyAuthFuture;

  @override
  void initState() {
    super.initState();
    sn = SelectTracksScreenNotifier(widget.param);
    spotifyAuthFuture = spotifyAuth();
    spotifyAuthFuture.then((authToken) async {
      if (authToken != null) {
        sn.authToken = authToken;
        print("Spotify auth token:$authToken");
      }
    });
  }

  @override
  void dispose() {
    sn.closeNotifier();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ProgressHUD(
      child: ChangeNotifierProvider<SelectTracksScreenNotifier>.value(
        value: sn,
        child: MultiBlocListener(
          listeners: [
            BlocListener<MusicCubit, MusicState>(
              bloc: sn.searchCubit,
              listener: (context, state) {
                if (state is SearchTracksLoaded) {
                  sn.tracks = state.tracks;
                }
              },
            ),
          ],
          child: Scaffold(
            appBar: buildCustomAppbar(),
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            body: FutureBuilder<String?>(
              future: spotifyAuthFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.done &&
                    snapshot.data != null) return SelectTracksScreenContent();
                return WaitingWidget();
              },
            ),
          ),
        ),
      ),
    );
  }

  Future<String?> spotifyAuth() async {
    try {
      final authToken = await SpotifySdkWrapper().getAuthToken();

      if (authToken != null) {
        final success = await SpotifySdk.connectToSpotifyRemote(
          clientId: AppConstants.SPOTIFY_CLIENT_ID,
          redirectUrl: Platform.isIOS?AppConstants.IOS_SPOTIFY_REDIRECT_URL:AppConstants.SPOTIFY_REDIRECT_URL,
          accessToken: authToken,
        );
        if (success) {
          //Todo call random request to check if the user is authorized to use the api (Needed for development only)
          sn.authToken = authToken;

          /// Store spotify auth
          await storeSpotifyAuth(authToken);
          final checkAuthRes =
              await getIt<RecentlyPlayedTracksUsecase>()(NoParams());
          if (checkAuthRes.hasDataOnly) {
            return authToken;
          } else {
            //Todo add retry callback and test
            Nav.pop();
            ErrorViewer.showError(
              error: checkAuthRes.error!,
              callback: () {},
              context: context,
              retryWhenNotAuthorized: false,
              errorViewerOptions: const ErrVSnackBarOptions(),
            );
            return null;
          }
        }
      }
      Nav.pop();
      showErrorSnackBar(message: Translation.of(context).unauthorized);

      return null;
    } catch (e) {
      Nav.pop();
      showErrorSnackBar(message: Translation.of(context).errorOccurred);
      return null;
    }
  }
}
