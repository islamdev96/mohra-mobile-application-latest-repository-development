import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent-tab-view.dart';
import 'package:provider/provider.dart';
import 'package:spotify_sdk/models/image_uri.dart';
import 'package:spotify_sdk/models/player_state.dart';
import 'package:spotify_sdk/spotify_sdk.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/common/extensions/extensions.dart';
import 'package:starter_application/core/common/style/gaps.dart';
import 'package:starter_application/core/common/utils.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/core/navigation/route_generator.dart';
import 'package:starter_application/core/params/no_params.dart';
import 'package:starter_application/core/ui/error_ui/error_viewer/error_viewer.dart';
import 'package:starter_application/core/ui/error_ui/error_viewer/snack_bar/errv_snack_bar_options.dart';
import 'package:starter_application/core/ui/error_ui/error_viewer/snack_bar/show_error_snackbar.dart';
import 'package:starter_application/core/ui/widgets/waiting_widget.dart';
import 'package:starter_application/di/service_locator.dart';
import 'package:starter_application/features/home/presentation/state_m/provider/app_main_screen_notifier.dart';
import 'package:starter_application/features/music/domain/entity/saved_albums_list_entity.dart';
import 'package:starter_application/features/music/domain/usecase/recently_played_tracks_usecase.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/screen/music_home/music_home_screen.dart';
import 'package:starter_application/features/music/presentation/screen/music_search_screen.dart';
import 'package:starter_application/features/music/presentation/screen/my_library/my_library_screen.dart';
import 'package:starter_application/features/music/presentation/screen/play_song_screen.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/generated/l10n.dart';

import '../../../../core/common/style/dimens.dart';
import '../../../../core/ui/dialogs/show_dialog.dart';
import '../state_m/provider/music_main_screen_notifier.dart';

class MusicMainScreenParam {
  final String? songId;
  MusicMainScreenParam({
    this.songId,
  });
}

class MusicMainScreen extends StatefulWidget {
  static const String routeName = "/MusicMainScreenScreen";
  final MusicMainScreenParam param;

  const MusicMainScreen({
    Key? key,
    required this.param,
  }) : super(key: key);

  @override
  _MusicMainScreenState createState() => _MusicMainScreenState();
}

class _MusicMainScreenState extends State<MusicMainScreen> {
  late MusicMainScreenNotifier sn;
  late final Future<String?> spotifyAuthFuture;
  List<Map<int, dynamic>> navItems = [
    {
      AppMainScreenNotifier.NAV_ICON: AppConstants.SVG_HOME_FILL,
      AppMainScreenNotifier.NAV_TITLE: Translation.current.Home,
    },
    {
      AppMainScreenNotifier.NAV_ICON: AppConstants.SVG_PLAY_LIST,
      AppMainScreenNotifier.NAV_TITLE: Translation.current.my_library,
    },
    {
      AppMainScreenNotifier.NAV_ICON: AppConstants.SVG_SEARCH,
      AppMainScreenNotifier.NAV_TITLE: Translation.current.search,
    },
  ];

  @override
  void initState() {
    super.initState();
    sn = Provider.of<MusicMainScreenNotifier>(AppConfig().appContext,
        listen: false);
    spotifyAuthFuture = spotifyAuth();
    spotifyAuthFuture.then((authToken) async {
      if (authToken != null) {
        sn.authToken = authToken;
        print("Spotify auth token:$authToken");

        /// If authentication succeed listen to player state and store the auth token
        sn.playerStateStream = SpotifySdk.subscribePlayerState()
          ..listen((playerState) {
            sn.latestPlayerState = playerState;
            if (playerState.track == null ||
                playerState.track?.name == null ||
                sn.isPlaySongScreenOpen) {
              sn.showHidSongControl(false);
            } else {
              sn.showHidSongControl(true);
            }
            if (playerState.track?.name != sn.prevSongName &&
                playerState.track?.imageUri != null) {
              sn.songImageFuture = sn.spotifySdkWrapper.getImage(
                imageUri: playerState.track!.imageUri,
                dimension: ImageDimension.small,
              );
            }
            sn.prevSongName = playerState.track?.name;
          });

        Future.delayed(const Duration(milliseconds: 300)).then((value) {
          /// If songId != null play the song
          if (widget.param.songId != null) {
            sn.playSong(
              spotifyId: widget.param.songId!,
              type: SpotifyType.TRACK,
            );

            Nav.to(
              PlaySongScreen.routeName,
              context: sn.getNavKey(0).currentContext,
              arguments: PlaySongScreenParam(
                  //TODO Get  it from music main screen param
                  playedFrom: Translation.current.moments,
                  type: SpotifyType.TRACK,
                  collectionId: null,
                  collectionImage: null,
                  onCollectionIconTap: () {
                    Nav.pop(context);
                  }),
            );
          }
        });
      }
    });
  }

  @override
  void dispose() {
    /// Disconnect from spotify
    sn.spotifySdkWrapper.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<MusicMainScreenNotifier>();
    return MultiBlocListener(
      listeners: [
        BlocListener<MusicCubit, MusicState>(
          bloc: sn.savedTracksCubit,
          listener: (context, state) {
            state.whenOrNull(userSavedTracksLoaded: (s) {
              sn.savedTracks = s.tracks;
            });
          },
        ),
        BlocListener<MusicCubit, MusicState>(
          bloc: sn.savedAlbumsCubit,
          listener: (context, state) {
            state.whenOrNull(getSavedAlbumsLoaded: (s) {
              final List<SavedAlbumsItemEntity> itemsWithoutNulls =
                  s.items.whereType<SavedAlbumsItemEntity>().toList();
              sn.savedAlbums = itemsWithoutNulls
                  .map((e) => e.album)
                  .whereType<AlbumEntity>()
                  .toList();
            });
          },
        ),
      ],
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: FutureBuilder<String?>(
            future: spotifyAuthFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.done &&
                  snapshot.data != null)
                return Stack(
                  children: [
                    PersistentTabView(
                      context,
                      handleAndroidBackButtonPress: true,
                      popActionScreens: PopActionScreensType.once,
                      controller: sn.musicTabController,
                      screens: [
                        const MusicHomeScreen(),
                        const MyLibraryScreen(),
                        const MusicSearchScreen(),
                      ],
                      items: [
                        _buildPersistentBottomNavBarItem(0),
                        _buildPersistentBottomNavBarItem(1),
                        _buildPersistentBottomNavBarItem(2),
                      ],
                      onWillPop: (context) async {
                        Navigator.of(context!).pop();
                        return true;
                      },

                      decoration: NavBarDecoration(
                        borderRadius: const BorderRadius.all(Radius.zero),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.mansourNotSelectedBorderColor
                                .withOpacity(0.3),
                            blurRadius: 5,
                          ),
                        ],
                      ),
                      navBarHeight: AppConstants.bottomNavigationBarHeight,
                      navBarStyle: NavBarStyle.simple,
                      // onPageChanged: sn.onPageChanged,
                    ),
                    _buildSongControlPopUp(),
                  ],
                );
              if (snapshot.connectionState == ConnectionState.done &&
                  snapshot.data != null)
                return Center(
                  child: Text(
                    Translation.current.auth_failed,
                  ),
                );
              return WaitingWidget();
            }),
      ),
    );
  }

  Widget songImage(ImageUri? image) {
    if (image == null) {
      return Container(
        height: AppConstants.songControlHeight * 0.7,
        width: AppConstants.songControlHeight * 0.7,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(
            15.r,
          ),
          color: AppColors.primaryColorLight,
        ),
      );
    }
    return FutureBuilder<Uint8List?>(
        future: sn.songImageFuture,
        builder: (BuildContext context, AsyncSnapshot<Uint8List?> snapshot) {
          if (snapshot.hasData) {
            return Container(
              height: AppConstants.songControlHeight * 0.7,
              width: AppConstants.songControlHeight * 0.7,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(
                  15.r,
                ),
                color: AppColors.accentColorLight,
                image: DecorationImage(
                    image: MemoryImage(
                      snapshot.data!,
                    ),
                    fit: BoxFit.cover),
              ),
            );
          } else {
            return Container(
              height: AppConstants.songControlHeight * 0.7,
              width: AppConstants.songControlHeight * 0.7,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(
                  15.r,
                ),
                color: AppColors.accentColorLight,
              ),
            );
          }
        });
  }

  Widget _buildSongControlPopUp() {
    return Positioned(
      bottom: AppConstants.bottomNavigationBarHeight,
      child: StreamBuilder<PlayerState>(
          stream: sn.playerStateStream,
          initialData: sn.latestPlayerState,
          builder: (context, snapshot) {
            final playerState = snapshot.data;
            if (snapshot.data == null || snapshot.data?.track?.name == null)
              return const SizedBox.shrink();
            return InkWell(
              onTap: () => sn.onSongControlTap(playerState!.isPaused),
              child: AnimatedContainer(
                padding: AppConstants.screenPadding,
                duration: const Duration(
                  milliseconds: 300,
                ),
                color: AppColors.primaryColorLight,
                height: sn.showSongControl ? AppConstants.songControlHeight : 0,
                width: 1.sw,
                curve: Curves.easeIn,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        songImage(playerState?.track?.imageUri),
                        SizedBox(
                          width: 40.w,
                        ),
                        SizedBox(
                          width: 0.4.sw,
                          child: Text(
                            playerState?.track?.name ?? "",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 37.sp,
                            ),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        InkWell(
                          onTap: sn.onSkipBackTap,
                          child: SizedBox(
                            height: 55.h,
                            width: 55.h,
                            child: Center(
                              child: SvgPicture.asset(
                                AppConfig().appLanguage == AppConstants.LANG_EN
                                    ? AppConstants.SVG_SONG_BACK
                                    : AppConstants.SVG_SONG_NEXT,
                                color: (playerState?.playbackRestrictions
                                            .canSkipPrevious ??
                                        false)
                                    ? Colors.white
                                    : Colors.white.withOpacity(
                                        0.6,
                                      ),
                              ),
                            ),
                          ),
                        ),
                        Gaps.hGap32,
                        Container(
                          height: AppConstants.songControlHeight * 0.65,
                          width: AppConstants.songControlHeight * 0.65,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(
                              0.29,
                            ),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.primaryColorLight
                                    .withOpacity(0.48),
                                spreadRadius: 0.r,
                                blurRadius: 40.r,
                                offset: Offset(
                                  0.r,
                                  10.r,
                                ),
                              ),
                            ],
                          ),
                          child: InkWell(
                            onTap: () => sn.onPauseResumeTap(
                                playerState?.isPaused ?? false),
                            child: SizedBox(
                              height: 45.h,
                              width: 45.h,
                              child: Center(
                                child: !(playerState?.isPaused ?? false)
                                    ? SvgPicture.asset(
                                        AppConstants.SVG_PAUSE,
                                        color: Colors.white,
                                      )
                                    : const Icon(
                                        Icons.play_arrow,
                                        color: Colors.white,
                                      ),
                              ),
                            ),
                          ),
                        ),
                        Gaps.hGap32,
                        InkWell(
                          onTap: sn.onSkipNextTap,
                          child: SizedBox(
                            height: 55.h,
                            width: 55.h,
                            child: Center(
                              child: SvgPicture.asset(
                                AppConfig().appLanguage == AppConstants.LANG_EN
                                    ? AppConstants.SVG_SONG_NEXT
                                    : AppConstants.SVG_SONG_BACK,
                                color: (playerState?.playbackRestrictions
                                            .canSkipNext ??
                                        false)
                                    ? Colors.white
                                    : Colors.white.withOpacity(
                                        0.6,
                                      ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          }),
    );
  }

  PersistentBottomNavBarItem _buildPersistentBottomNavBarItem(int index) {
    final item = navItems[index];
    return PersistentBottomNavBarItem(
      icon: SizedBox(
        height: 70.h,
        width: 70.h,
        child: SvgPicture.asset(
          item[AppMainScreenNotifier.NAV_ICON],
          color: AppColors.primaryColorLight,
        ),
      ),
      inactiveIcon: SizedBox(
        height: 70.h,
        width: 70.h,
        child: SvgPicture.asset(
          item[AppMainScreenNotifier.NAV_ICON],
          color: AppColors.mansourLightGreyColor_3,
        ),
      ),
      title: item[AppMainScreenNotifier.NAV_TITLE],
      activeColorPrimary: AppColors.primaryColorLight,
      inactiveColorPrimary: AppColors.mansourLightGreyColor_3,
      iconSize: 70.h,
      textStyle: TextStyle(
        fontSize: 30.sp,
        fontWeight: FontWeight.bold,
      ),
      routeAndNavigatorSettings: RouteAndNavigatorSettings(
        navigatorKey: sn.getNavKey(index),
        initialRoute: '/',
        onGenerateRoute: getIt<NavigationRoute>().generateRoute,
        navigatorObservers: [sn.getRouteObserver(index)],
      ),
    );
  }

  Future<String?> spotifyAuth() async {
    try {
      print('aaaa');
      final authToken = await SpotifySdkWrapper().getAuthToken();
      // final authToken = await getAuthToken();
      // final authToken = await getAuthToken2();

      if (authToken != null) {
        final success = await SpotifySdk.connectToSpotifyRemote(
          clientId: AppConstants.SPOTIFY_CLIENT_ID,
          redirectUrl: Platform.isIOS?AppConstants.IOS_SPOTIFY_REDIRECT_URL:AppConstants.SPOTIFY_REDIRECT_URL,
          accessToken: authToken,
        );

        if (success) {
          sn.authToken = authToken;

          /// Store spotify auth
          await storeSpotifyAuth(authToken);
          //Todo call random request to check if the user is authorized to use the api (Needed for development only)
          final checkAuthRes =
              await getIt<RecentlyPlayedTracksUsecase>()(NoParams());
          if (checkAuthRes.hasDataOnly) {
            return authToken;
          }
          else {
            Nav.pop();
            ErrorViewer.showError(
              error: checkAuthRes.error!,
              callback: () {},
              context: context,
              retryWhenNotAuthorized: false,
              errorViewerOptions: const ErrVSnackBarOptions(),
            );
            return null;
          }
        }
      }
      Nav.pop();
      installSpotify();

      return null;
    } catch (e) {
      Nav.pop();
      showErrorSnackBar(message: Translation.of(context).errorOccurred);
      return null;
    }
  }

  /*  Future<String?> getAuthToken() async {
    final token = await sn.oauth2Helper.getToken();
    return token?.accessToken;
  } */

  // Future<String?> getAuthToken2() async {
  //     final url = Uri.https('accounts.spotify.com', '/authorize', {
  //       'response_type': 'code',
  //       'client_id': AppConstants.SPOTIFY_CLIENT_ID,
  //       'redirect_uri': AppConstants.SPOTIFY_REDIRECT_URL_2,
  //       'scope': 'app-remote-control, '
  //           'user-modify-playback-state, '
  //           'ugc-image-upload, '
  //           'user-read-private, '
  //           'user-read-recently-played, '
  //           'playlist-read-private, '
  //           'user-library-read, '
  //           'playlist-modify-private, '
  //           'playlist-modify-public,user-read-currently-playing',
  //     });

  //     final result = await FlutterWebAuth.authenticate(
  //         url: url.toString(), callbackUrlScheme: 'app.mohraapp.com.android');
  //     return result;
  // }
  void installSpotify() {
    ShowDialog().showElasticDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return AlertDialog(
          shape:  RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
              Radius.circular(Dimens.dp15),
            ),
          ),
          title: Text(
            Translation.current.install_spotify,
            style: Colors.black.bodyText2,
          ),
          content: Container(
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.all(const Radius.circular(25)),
            ),
            padding: const EdgeInsets.only(top: 4.0, bottom: 4.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                      style: TextButton.styleFrom(
                        textStyle: TextStyle(
                          color: Theme.of(context).colorScheme.secondary,
                        ),
                      ),
                      child: Text(
                        Translation.of(context).cancel,
                      ),
                      onPressed: () {
                        // Navigator.of(context).pop();
                        Nav.pop();
                      },
                    ),
                    MaterialButton(
                      color: Theme.of(context).primaryColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                          ScreenUtil().setWidth(35),
                        ),
                      ),
                      child: Text(
                        Translation.of(context).install,
                        style: const TextStyle(color: Colors.white),
                      ),
                      onPressed: ()async{
                        if(Platform.isIOS){
                          await launchURL("https://apps.apple.com/us/app/spotify-music-and-podcasts/id324684580");
                        }else{
                          await launchURL("https://play.google.com/store/apps/details?id=com.spotify.music&hl=en&gl=US&pli=1");
                        }
                      },
                      textColor: Theme.of(context).primaryColor,
                    ),
                  ],
                )
              ],
            ),
          ),
        );
      },
    );
  }

}
