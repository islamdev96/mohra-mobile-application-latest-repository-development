import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'package:spotify_sdk/enums/repeat_mode_enum.dart';
import 'package:spotify_sdk/models/player_state.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/common/style/gaps.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/ui/widgets/waiting_widget.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/features/music/presentation/widget/play_song/song_indicator.dart';

import '../screen/../state_m/provider/play_song_screen_notifier.dart';

class PlaySongScreenContent extends StatefulWidget {
  @override
  State<PlaySongScreenContent> createState() => _PlaySongScreenContentState();
}

class _PlaySongScreenContentState extends State<PlaySongScreenContent> {
  late PlaySongScreenNotifier sn;

  /// Screen height without the appBar and bottomNavigationBar height
  late double screenHeight;
  final MusicMainScreenNotifier musicMainScreenNotifier =
      AppConfig().appContext.read<MusicMainScreenNotifier>();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance?.addPostFrameCallback((timeStamp) {
      musicMainScreenNotifier.playerStateStream.listen((PlayerState) {
        if (mounted) {
          /// Get if song is saved
          if (sn.isSongSaved == null && PlayerState.track?.uri != null) {
            sn.isSongSaved =
                context.read<MusicMainScreenNotifier>().isItemSaved(
                      PlayerState.track!.uri,
                      type: SpotifyType.TRACK,
                    );
          }

          /// If start or resume start song progress tracking
          if (!PlayerState.isPaused) {
            sn.startSongProgressTracking(PlayerState.playbackPosition);

            /// If pause stop song progress tracking
          } else {
            sn.stopSongProgressTracking();
          }
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    screenHeight = 1.sh -
        AppConstants.bottomNavigationBarHeight -
        Scaffold.of(context).appBarMaxHeight!;
    sn = Provider.of<PlaySongScreenNotifier>(context);
    sn.context = context;
    return StreamBuilder<PlayerState?>(
        stream: musicMainScreenNotifier.playerStateStream,
        initialData: musicMainScreenNotifier.latestPlayerState,
        builder: (context, snapshot) {
          final PlayerState? playerState = snapshot.data;
          if (snapshot.data == null || snapshot.data?.track == null)
            return WaitingWidget();
          return Padding(
            padding: AppConstants.screenPadding,
            child: Column(
              children: [
                SizedBox(
                  height: 0.12 * screenHeight,
                ),
                FutureBuilder<Uint8List?>(
                    future: musicMainScreenNotifier.songImageFuture,
                    builder: (context, snapshot) {
                      context.select<PlaySongScreenNotifier, int>(
                          (notifier) => notifier.songProgressInMS);
                      return Center(
                        child: SongIndicator(
                          height: 0.4 * screenHeight,
                          type: SongIndicatorType.Circular,
                          image: snapshot.data,
                          maxValueInMs: playerState!.track!.duration,
                          currentValueInMs:
                              context.select<PlaySongScreenNotifier, int>(
                                  (notifier) => notifier.songProgressInMS),
                          onSeek: playerState.playbackRestrictions.canSeek
                              ? sn.onSeekTap
                              : (_) {},
                        ),
                      );
                    }),
                SizedBox(
                  height: 0.12 * screenHeight,
                ),
                _buildTitleAndFavoriteRow(playerState?.track?.name ?? "",
                    playerState?.track?.uri ?? ""),
                Gaps.vGap32,
                SongIndicator(
                  height: 0.1 * screenHeight,
                  type: SongIndicatorType.Linear,
                  maxValueInMs: playerState!.track!.duration,
                  currentValueInMs: sn.songProgressInMS,
                  onSeek: playerState.playbackRestrictions.canSeek
                      ? sn.onSeekTap
                      : (_) {},
                ),
                _buildSongControl(playerState),
              ],
            ),
          );
        });
  }

  /// Widgets
  Widget _buildTitleAndFavoriteRow(final String title, String songUri) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              color: Colors.black,
              fontSize: 60.sp,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        InkWell(
          focusColor: AppColors.primaryColorLight.withOpacity(0.4),
          hoverColor: AppColors.primaryColorLight.withOpacity(0.4),
          splashColor: AppColors.primaryColorLight.withOpacity(0.4),
          highlightColor: AppColors.primaryColorLight.withOpacity(0.4),
          borderRadius: BorderRadius.circular(
            55.r,
          ),
          onTap: () => sn.onSaveButtonTap(songUri),
          child: SizedBox(
            height: 55.h,
            width: 55.h,
            child: SvgPicture.asset(
              AppConstants.SVG_LOVE,
              color: sn.isSongSaved == true
                  ? AppColors.primaryColorLight
                  : AppColors.mansourGrey,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSongControl(PlayerState? playerState) {
    return Expanded(
        child: SizedBox(
      width: 1.sw - AppConstants.hPadding * 2,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildRepeatButton(
            playerState,
          ),
          InkWell(
            splashColor: Colors.transparent,
            hoverColor: Colors.transparent,
            focusColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: musicMainScreenNotifier.onSkipBackTap,
            child: SizedBox(
              height: 55.h,
              width: 55.h,
              child: Center(
                child: SvgPicture.asset(
                  AppConfig().appLanguage == AppConstants.LANG_EN
                      ? AppConstants.SVG_SONG_BACK
                      : AppConstants.SVG_SONG_NEXT,
                  color: (playerState?.playbackRestrictions.canSkipPrevious ??
                          false)
                      ? Colors.black
                      : Colors.black.withOpacity(
                          0.4,
                        ),
                ),
              ),
            ),
          ),
          FractionallySizedBox(
            heightFactor: 0.56,
            child: AspectRatio(
              aspectRatio: 1,
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.primaryColorLight,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primaryColorLight.withOpacity(0.48),
                      spreadRadius: 0.r,
                      blurRadius: 40.r,
                      offset: Offset(
                        0.r,
                        10.r,
                      ),
                    ),
                  ],
                ),
                child: InkWell(
                  splashColor: Colors.transparent,
                  hoverColor: Colors.transparent,
                  focusColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                  onTap: () => musicMainScreenNotifier
                      .onPauseResumeTap(playerState?.isPaused ?? false),
                  child: SizedBox(
                    height: 50.h,
                    width: 50.h,
                    child: Center(
                      child: !(playerState?.isPaused ?? false)
                          ? SvgPicture.asset(
                              AppConstants.SVG_PAUSE,
                              color: Colors.white,
                            )
                          : const Icon(
                              Icons.play_arrow,
                              color: Colors.white,
                            ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          InkWell(
            splashColor: Colors.transparent,
            hoverColor: Colors.transparent,
            focusColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: musicMainScreenNotifier.onSkipNextTap,
            child: SizedBox(
              height: 55.h,
              width: 55.h,
              child: Center(
                child: SvgPicture.asset(
                  AppConfig().appLanguage == AppConstants.LANG_EN
                      ? AppConstants.SVG_SONG_NEXT
                      : AppConstants.SVG_SONG_BACK,
                  color:
                      (playerState?.playbackRestrictions.canSkipNext ?? false)
                          ? Colors.black
                          : Colors.black.withOpacity(
                              0.4,
                            ),
                ),
              ),
            ),
          ),
          _buildShuffleButton(playerState),
        ],
      ),
    ));
  }

  Widget _buildShuffleButton(PlayerState? playerState) {
    final buttonColor = (playerState?.playbackOptions.isShuffling ?? false)
        ? AppColors.primaryColorLight
        : AppColors.mansourGrey2;
    return InkWell(
      onTap: (playerState?.playbackRestrictions.canToggleShuffle ?? false)
          ? () => sn.onShuffleTap(
              !(playerState?.playbackOptions.isShuffling ?? false))
          : null,
      child: SizedBox(
        height: 55.h,
        width: 55.h,
        child: Center(
          child: SvgPicture.asset(
            AppConstants.SVG_SHUFFLE3,
            color: (playerState?.playbackRestrictions.canToggleShuffle ?? false)
                ? buttonColor
                : buttonColor.withOpacity(
                    0.5,
                  ),
          ),
        ),
      ),
    );
  }

  Widget _buildRepeatButton(PlayerState? playerState) {
    final buttonColor =
        playerState?.playbackOptions.repeatMode.name != RepeatMode.off.name
            ? AppColors.primaryColorLight
            : AppColors.mansourGrey2;
    return InkWell(
      onTap: (playerState?.playbackRestrictions.canRepeatTrack ?? false)
          ? () => sn.onRepeatTap(playerState?.playbackOptions.repeatMode)
          : null,
      child: SizedBox(
        height: 55.h,
        width: 55.h,
        child: Center(
          child: playerState?.playbackOptions.repeatMode.name ==
                  RepeatMode.track.name
              ? Icon(
                  Icons.repeat_one,
                  color: (playerState?.playbackRestrictions.canRepeatTrack ??
                          false)
                      ? buttonColor
                      : buttonColor.withOpacity(
                          0.5,
                        ),
                )
              : Icon(
                  Icons.repeat,
                  color: (playerState?.playbackRestrictions.canRepeatTrack ??
                          false)
                      ? buttonColor
                      : buttonColor.withOpacity(
                          0.5,
                        ),
                ),
        ),
      ),
    );
  }

  /// Logic

}
