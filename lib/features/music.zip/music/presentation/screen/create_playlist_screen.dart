import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_progress_hud/flutter_progress_hud.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/core/ui/appbar/appbar.dart';
import 'package:starter_application/core/ui/error_ui/error_viewer/error_viewer.dart';
import 'package:starter_application/core/ui/snackbars/show_snackbar.dart';
import 'package:starter_application/core/ui/widgets/waiting_widget.dart';
import 'package:starter_application/features/music/presentation/screen/playlist_details/playlist_details_screen.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/generated/l10n.dart';

import '../screen/../state_m/provider/create_playlist_screen_notifier.dart';
import 'create_playlist_screen_content.dart';

class CreatePlaylistScreenParam {
  final Function(PlaylistDetailsScreenParam playlist)? onPlaylistCreated;
  final Function(PlaylistDetailsScreenParam playlist)? onPlaylistUpdated;

  /// If [playlist != null] then it is edit mode
  PlaylistDetailsScreenParam? playlist;
  CreatePlaylistScreenParam({
    this.onPlaylistCreated,
    this.onPlaylistUpdated,
    this.playlist,
  });
}

class CreatePlaylistScreen extends StatefulWidget {
  static const String routeName = "/CreatePlaylistScreen";
  final CreatePlaylistScreenParam param;

  const CreatePlaylistScreen({
    Key? key,
    required this.param,
  }) : super(key: key);

  @override
  _CreatePlaylistScreenState createState() => _CreatePlaylistScreenState();
}

class _CreatePlaylistScreenState extends State<CreatePlaylistScreen> {
  late final CreatePlaylistScreenNotifier sn;

  @override
  void initState() {
    super.initState();
    sn = CreatePlaylistScreenNotifier(widget.param);
  }

  @override
  void dispose() {
    sn.closeNotifier();

    /// Refresh userPlaylists
    AppConfig()
        .appContext
        .read<MusicMainScreenNotifier>()
        .refreshUserPlaylists();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ProgressHUD(
      indicatorWidget: Material(
        color: Colors.transparent,
        child: TextWaitingWidget(
          Translation.current.uploading,
          textColor: Colors.white,
        ),
      ),
      child: ChangeNotifierProvider<CreatePlaylistScreenNotifier>.value(
        value: sn,
        child: Scaffold(
          appBar: buildCustomAppbar(onBackTap: () {
            Nav.persistentPop(
              context,
              bottomNavController:
                  context.read<MusicMainScreenNotifier>().musicTabController,
            );
          }),
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          body: MultiBlocListener(
            listeners: [
              BlocListener<MusicCubit, MusicState>(
                bloc: sn.playlistCubit,
                listener: (context, state) {
                  state.mapOrNull(musicLoadingState: (s) {
                    sn.isLoading = true;
                  }, createPlaylistLoaded: (s) {
                    sn.isLoading = false;
                    sn.playlist = PlaylistDetailsScreenParam(
                      id: s.playlist.id ?? "",
                      name: s.playlist.name ?? "",
                      image: (s.playlist.images?.length ?? 0) > 0
                          ? s.playlist.images![0].url ?? ""
                          : "",
                      isUserPlaylist: true,
                      autoPlay: false,
                    );
                    widget.param.onPlaylistCreated?.call(sn.playlist!);

                    showSnackbar(
                      Translation.current.create_playlist_success,
                    );
                  }, updatePlaylistInfoLoaded: (s) {
                    sn.isLoading = false;
                    sn.playlist = PlaylistDetailsScreenParam(
                      id: sn.playlist?.id ?? "",
                      name: sn.playlistNameController.text,
                      image: sn.playlist?.image ?? "",
                      isUserPlaylist: true,
                      autoPlay: false,
                    );
                    widget.param.onPlaylistUpdated?.call(sn.playlist!);

                    showSnackbar(
                      Translation.current.update_playlist_success,
                    );
                  }, musicErrorState: (s) {
                    sn.isLoading = false;
                    ErrorViewer.showError(
                      context: context,
                      error: s.error,
                      callback: s.callback,
                    );
                  });
                },
              ),
              BlocListener<MusicCubit, MusicState>(
                bloc: sn.uploadImageCubit,
                listener: (context, state) {
                  state.mapOrNull(musicLoadingState: (_) {
                    ProgressHUD.of(context)!.show();
                  }, updatePlaylistImageLoaded: (s) {
                    ProgressHUD.of(context)!.dismiss();
                    sn.playlist = PlaylistDetailsScreenParam(
                      id: sn.playlist?.id ?? "",
                      name: sn.playlistNameController.text,
                      image: sn.playlistImage ?? "",
                      isUserPlaylist: true,
                      autoPlay: false,
                    );
                    widget.param.onPlaylistUpdated?.call(sn.playlist!);
                    showSnackbar(
                      Translation.current.update_image_success,
                    );
                  }, musicErrorState: (s) {
                    ProgressHUD.of(context)!.dismiss();
                    sn.playlistImage = sn.playlist?.image ?? null;
                    ErrorViewer.showError(
                      context: context,
                      error: s.error,
                      callback: s.callback,
                    );
                  });
                },
              ),
            ],
            child: CreatePlaylistScreenContent(),
          ),
        ),
      ),
    );
  }
}
