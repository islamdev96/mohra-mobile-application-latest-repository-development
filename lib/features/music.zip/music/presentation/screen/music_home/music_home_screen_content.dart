import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/common/style/gaps.dart';
import 'package:starter_application/core/common/utils.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/ui/appbar/appbar.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_home_screen_notifier.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/features/music/presentation/widget/home_playlist_tracks_.dart';
import 'package:starter_application/features/music/presentation/widget/music_card1.dart';
import 'package:starter_application/generated/l10n.dart';

class MusicHomeScreenContent extends StatefulWidget {
  final MusicHomeScreenNotifier screenNotifier;

  const MusicHomeScreenContent({Key? key, required this.screenNotifier})
      : super(key: key);
  @override
  State<MusicHomeScreenContent> createState() => _MusicHomeScreenContentState();
}

class _MusicHomeScreenContentState extends State<MusicHomeScreenContent>
    with SingleTickerProviderStateMixin {
  late MusicHomeScreenNotifier sn;
  late final TabController tabController;

  @override
  void initState() {
    super.initState();
    sn = widget.screenNotifier;
    tabController = TabController(
      length: sn.musicHomeEntity.playlists.length,
      vsync: this,
    );
    tabController.addListener(() {
      setState(() {});
    });
    // if (sn.musicHomeEntity.playlists.length > 0)
    //   sn.getPlaylistTracks(sn.musicHomeEntity.playlists[0].id!);
  }

  @override
  Widget build(BuildContext context) {
    sn = Provider.of<MusicHomeScreenNotifier>(context);
    sn.context = context;
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.only(
        bottom: 64.h,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          buildAppbarTitle(
            Translation.current.music,
          ),
          Gaps.vGap32,
          _buildTabBar(),
          Gaps.vGap50,
          SizedBox(
            height: 550.h,
            child: TabBarView(
              controller: tabController,
              children: List.generate(
                sn.musicHomeEntity.playlists.length,
                (index) => HomePlaylistTracks(
                  playlistId: sn.musicHomeEntity.playlists[index].id ?? "",
                  onTap: (id, songIndex) => sn.onPlaylistTrackTap(
                      playlistId: sn.musicHomeEntity.playlists[index].id ?? "",
                      playlistName:
                          sn.musicHomeEntity.playlists[index].name ?? "",
                      playlistImage: (sn.musicHomeEntity.playlists[index].images
                                      ?.length ??
                                  0) >
                              0
                          ? sn.musicHomeEntity.playlists[index].images![0].url
                          : null,
                      trackIndex: songIndex),
                ),
              ),
            ),
          ),
          Gaps.vGap64,
          _buildPage(),
        ],
      ),
    );
  }

  /// List with title
  Widget _buildScreenWidget({
    required Widget list,
    String? title,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (title != null)
          Padding(
            padding: AppConstants.screenPadding,
            child: Text(
              title,
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.w900,
                fontSize: 45.sp,
              ),
            ),
          ),
        if (title != null) Gaps.vGap50,
        list
      ],
    );
  }

  Widget _buildPage() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildRecentlyPlayed(),
        Gaps.vGap64,
        _buildPopularArtist(),
        Gaps.vGap64,
        _buildYourPlayList(),
        if (context.watch<MusicMainScreenNotifier>().showSongControl)
          SizedBox(
            height: AppConstants.songControlHeight,
          ),
      ],
    );
  }

  Widget _buildPopularArtistsList() {
    return SizedBox(
      height: 350.h,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: AppConstants.screenPadding,
        itemBuilder: (context, index) {
          final artist = sn.musicHomeEntity.mostPopularArtists[index];
          return MusicCard1(
            height: 350.h,
            title: artist.name ?? "",
            image:
                (artist.images?.length ?? 0) > 0 ? artist.images![0].url : null,
                onTap: () => sn.onMostPopularArtistTap(artist),
          );
        },
        separatorBuilder: (context, _) {
          return Gaps.hGap32;
        },
        itemCount: sn.musicHomeEntity.mostPopularArtists.length,
      ),
    );
  }

  Widget _buildRecentlyPlayed() {
    return _buildScreenWidget(
      title: Translation.current.recently_played,
      list: sn.musicHomeEntity.recentlyPlayedTracksListEntity.items.length == 0
          ? Padding(
              padding: AppConstants.screenPadding,
              child: Text(
                Translation.current.no_songs_now,
                style: TextStyle(
                  fontSize: 40.sp,
                  color: AppColors.primaryColorLight,
                ),
              ),
            )
          : SizedBox(
              height: 550.h,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: AppConstants.screenPadding,
                itemBuilder: (context, index) {
                  final track = sn.musicHomeEntity
                      .recentlyPlayedTracksListEntity.items[index];

                  return MusicCard1(
                    height: 550.h,
                    title: track.track?.name ?? "",
                    subtitle: getArtists(track.track?.artists
                            .map((e) => e.name ?? "")
                            .toList() ??
                        []),
                    image: (track.track?.album?.images.length ?? 0) > 0
                        ? track.track?.album?.images[0].url
                        : null,
                    onTap: () =>
                        sn.onRecentlyPlayedTrackTap(track.track?.id ?? ""),
                  );
                },
                separatorBuilder: (context, _) {
                  return Gaps.hGap32;
                },
                itemCount: sn.musicHomeEntity.recentlyPlayedTracksListEntity
                    .items.length,
              ),
            ),
    );
  }

  Widget _buildPopularArtist() {
    return _buildScreenWidget(
      title: Translation.current.popular_artists,
      list: sn.musicHomeEntity.mostPopularArtists.length == 0
          ? Padding(
              padding: AppConstants.screenPadding,
              child: Text(
                Translation.current.no_artists_now,
                style: TextStyle(
                  fontSize: 40.sp,
                  color: AppColors.primaryColorLight,
                ),
              ),
            )
          : _buildPopularArtistsList(),
    );
  }

  Widget _buildYourPlayList() {
    return _buildScreenWidget(
      title: Translation.current.your_playlists,
      list: sn.musicHomeEntity.userPlaylists.length == 0
          ? Padding(
              padding: AppConstants.screenPadding,
              child: Text(
                Translation.current.no_playlists_now,
                style: TextStyle(
                  fontSize: 40.sp,
                  color: AppColors.primaryColorLight,
                ),
              ),
            )
          : SizedBox(
              height: 420.h,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: AppConstants.screenPadding,
                itemBuilder: (context, index) {
                  final playlist = sn.musicHomeEntity.userPlaylists[index];
                  return MusicCard1(
                    height: 420.h,
                    width: 360.h,
                    imageWidth: 360.h,
                    imageHeight: 280.h,
                    title: playlist.name ?? "",
                    subtitle:
                        "${playlist.tracksLink?.total?.toString() ?? 0} ${Translation.current.songs}",
                    image: (playlist.images?.length ?? 0) > 0
                        ? playlist.images![0].url
                        : null,
                    onTap: () => sn.onUserPlaylistTap(playlist),
                  );
                },
                separatorBuilder: (context, _) {
                  return Gaps.hGap32;
                },
                itemCount: sn.musicHomeEntity.userPlaylists.length,
              ),
            ),
    );
  }

  Widget _buildTabBar() {
    return TabBar(
      controller: tabController,
      labelStyle: TextStyle(
        color: AppColors.primaryColorLight,
        fontSize: 45.sp,
        fontWeight: FontWeight.w600,
      ),
      labelColor: AppColors.primaryColorLight,
      unselectedLabelStyle: TextStyle(
        color: AppColors.accentColorLight,
        fontSize: 45.sp,
        fontWeight: FontWeight.w600,
      ),
      unselectedLabelColor: AppColors.accentColorLight,
      indicatorColor: AppColors.primaryColorLight,
      indicatorWeight: 3,
      labelPadding: EdgeInsetsDirectional.only(
        bottom: 40.h,
        end: AppConstants.hPadding,
        start: AppConstants.hPadding,
      ),
      indicatorSize: TabBarIndicatorSize.label,
      tabs: sn.musicHomeEntity.playlists
          .map(
            (e) => Text(
              e.name ?? "",
            ),
          )
          .toList(),
      isScrollable: true,
      onTap: sn.onPlaylistTap,
    );
  }
}
