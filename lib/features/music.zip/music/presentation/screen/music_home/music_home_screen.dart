import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/core/ui/appbar/appbar.dart';
import 'package:starter_application/core/ui/error_ui/errors_screens/error_widget.dart';
import 'package:starter_application/core/ui/widgets/waiting_widget.dart';
import 'package:starter_application/features/music/domain/entity/saved_tracks_entity.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_home_screen_notifier.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';

import 'music_home_screen_content.dart';

class MusicHomeScreen extends StatefulWidget {
  static const String routeName = "/MusicHomeScreen";

  const MusicHomeScreen({Key? key}) : super(key: key);

  @override
  _MusicHomeScreenState createState() => _MusicHomeScreenState();
}

class _MusicHomeScreenState extends State<MusicHomeScreen> {
  final sn = MusicHomeScreenNotifier();

  @override
  void initState() {
    super.initState();
    AppConfig()
        .appContext
        .read<MusicMainScreenNotifier>()
        .homeCubit
        .getMusicHome(
            AppConfig().appContext.read<MusicMainScreenNotifier>().authToken);
    AppConfig().appContext.read<MusicMainScreenNotifier>().getSavedAlbums();
  }

  @override
  void dispose() {
    sn.closeNotifier();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<MusicHomeScreenNotifier>.value(
      value: sn,
      child: Scaffold(
        appBar: buildCustomAppbar(
          onBackTap: () {
            Nav.persistentPop(
              context,
              bottomNavController:
                  context.read<MusicMainScreenNotifier>().musicTabController,
            );
          },
        ),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: BlocConsumer<MusicCubit, MusicState>(
          bloc:
              AppConfig().appContext.read<MusicMainScreenNotifier>().homeCubit,
          listener: (context, state) {
            if (state is MusicHomeLoaded) {
              sn.musicHomeEntity = state.musicHomeEntity;

              /// Update saved tracks
              context
                  .read<MusicMainScreenNotifier>()
                  .savedTracksCubit
                  .emitSavedTracksLoadedState(
                    SavedTracksEntity(
                      sn.musicHomeEntity.savedTracks,
                    ),
                  );
            }
          },
          builder: (context, state) {
            return state.maybeMap(
              musicInitState: (s) => WaitingWidget(),
              musicLoadingState: (s) => WaitingWidget(),
              musicHomeLoaded: (s) => MusicHomeScreenContent(
                screenNotifier: sn,
              ),
              musicErrorState: (s) => ErrorScreenWidget(
                error: s.error,
                callback: s.callback,
              ),
              orElse: () => const ScreenNotImplementedError(),
            );
          },
        ),
      ),
    );
  }
}
