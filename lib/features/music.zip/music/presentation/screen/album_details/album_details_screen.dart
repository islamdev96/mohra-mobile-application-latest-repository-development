import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/core/ui/appbar/appbar.dart';
import 'package:starter_application/core/ui/error_ui/errors_screens/error_widget.dart';
import 'package:starter_application/core/ui/widgets/waiting_widget.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/album_details_screen_notifier.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/generated/l10n.dart';

import 'album_details_screen_content.dart';

class AlbumDetailsScreenParam {
  final String id;
  final String name;
  final String image;
  final bool autoPlay;

  AlbumDetailsScreenParam({
    required this.id,
    required this.name,
    required this.image,
    required this.autoPlay,
  });
}

class AlbumDetailsScreen extends StatefulWidget {
  final AlbumDetailsScreenParam param;
  static const String routeName = "/AlbumDetailsScreen";

  const AlbumDetailsScreen({
    Key? key,
    required this.param,
  }) : super(key: key);

  @override
  _AlbumDetailsScreenState createState() => _AlbumDetailsScreenState();
}

class _AlbumDetailsScreenState extends State<AlbumDetailsScreen> {
  late final AlbumDetailsScreenNotifier sn;

  @override
  void initState() {
    super.initState();
    sn = AlbumDetailsScreenNotifier(widget.param);
    sn.sendAlbumTracksRequest();
  }

  @override
  void dispose() {
    sn.closeNotifier();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<AlbumDetailsScreenNotifier>.value(
      value: sn,
      child: Scaffold(
        appBar: buildCustomAppbar(
          titleText: Translation.current.album_details,
          centerTitle: true,
          onBackTap: () {
            Nav.persistentPop(
              context,
              bottomNavController:
                  context.read<MusicMainScreenNotifier>().musicTabController,
            );
          },
        ),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: BlocConsumer<MusicCubit, MusicState>(
          bloc: sn.albumTracksCubit,
          listener: (context, state) async {
            if (state is GetAlbumTracksLoaded) {
              sn.tracks = state.tracks;
              if (widget.param.autoPlay) {
                await sn.spotifySdkWrapper.play(
                  widget.param.id,
                  null,
                  SpotifyType.ALBUM,
                );
              }
            }
          },
          builder: (context, state) {
            return state.maybeMap(
              musicInitState: (s) => WaitingWidget(),
              musicLoadingState: (s) => WaitingWidget(),
              musicErrorState: (s) => ErrorScreenWidget(
                error: s.error,
                callback: s.callback,
              ),
              getAlbumTracksLoaded: (s) => AlbumDetailsScreenContent(),
              orElse: () => const ScreenNotImplementedError(),
            );
          },
        ),
      ),
    );
  }
}
