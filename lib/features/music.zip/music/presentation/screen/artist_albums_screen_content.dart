import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/common/style/gaps.dart';
import 'package:starter_application/core/common/utils.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/features/music/presentation/widget/music_card2.dart';

import '../screen/../state_m/provider/artist_albums_screen_notifier.dart';

class ArtistAlbumsScreenContent extends StatefulWidget {
  @override
  State<ArtistAlbumsScreenContent> createState() =>
      _ArtistAlbumsScreenContentState();
}

class _ArtistAlbumsScreenContentState extends State<ArtistAlbumsScreenContent> {
  late ArtistAlbumsScreenNotifier sn;

  @override
  Widget build(BuildContext context) {
    sn = Provider.of<ArtistAlbumsScreenNotifier>(context);
    sn.context = context;
    return _buildAlbumsList();
  }

  Widget _buildAlbumsList() {
    return Column(
      children: [
        Expanded(
          child: ListView.separated(
              physics: const BouncingScrollPhysics(),
              padding: EdgeInsets.only(
                left: AppConstants.hPadding,
                right: AppConstants.hPadding,
                bottom: 64.h,
              ),
              itemBuilder: (context, index) {
                final album = sn.albums[index];
                return MusicCard2(
                  title: album.name ?? "",
                  leadingImage: (album.images?.length ?? 0) > 0
                      ? album.images![0].url
                      : null,
                  subtitle: getArtists(
                      album.artists?.map((e) => e.name ?? "").toList() ?? []),
                  onItemTap: () => sn.onAlbumTap(album),
                  trailingWidget: InkWell(
                    focusColor: AppColors.primaryColorLight.withOpacity(0.4),
                    hoverColor: AppColors.primaryColorLight.withOpacity(0.4),
                    splashColor: AppColors.primaryColorLight.withOpacity(0.4),
                    highlightColor:
                        AppColors.primaryColorLight.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(
                      55.r,
                    ),
                    onTap: () => context
                        .read<MusicMainScreenNotifier>()
                        .saveUnSaveSpotifyItem(
                          album.id ?? "",
                          type: SpotifyType.ALBUM,
                        ),
                    child: SizedBox(
                      height: 55.h,
                      width: 55.h,
                      child: SvgPicture.asset(
                        AppConstants.SVG_LOVE,
                        color: context
                                .watch<MusicMainScreenNotifier>()
                                .isItemSaved(
                                  album.id ?? "",
                                  type: SpotifyType.ALBUM,
                                )
                            ? AppColors.primaryColorLight
                            : AppColors.mansourGrey,
                      ),
                    ),
                  ),
                );
              },
              separatorBuilder: (context, index) {
                return Gaps.vGap32;
              },
              itemCount: sn.albums.length),
        ),
        if (context.watch<MusicMainScreenNotifier>().showSongControl)
          SizedBox(
            height: AppConstants.songControlHeight,
          ),
      ],
    );
  }
}
