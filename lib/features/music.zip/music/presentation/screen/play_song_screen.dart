import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/common/style/gaps.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/core/ui/appbar/appbar.dart';
import 'package:starter_application/features/music/presentation/logic/music_route_aware_state.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/generated/l10n.dart';

import '../screen/../state_m/provider/play_song_screen_notifier.dart';
import 'play_song_screen_content.dart';

class PlaySongScreenParam {
  final String playedFrom;

  final SpotifyType type;

  /// Could be playlist, album, ect
  final String? collectionId;
  final String? collectionImage;
  final VoidCallback onCollectionIconTap;

  PlaySongScreenParam({
    required this.playedFrom,
    required this.type,
    required this.collectionId,
    required this.collectionImage,
    required this.onCollectionIconTap,
  }) : assert(type == SpotifyType.TRACK ||
            (type != SpotifyType.TRACK && collectionId != null));
}

class PlaySongScreen extends StatefulWidget {
  static const String routeName = "/PlaySongScreen";
  final PlaySongScreenParam param;

  const PlaySongScreen({
    Key? key,
    required this.param,
  }) : super(key: key);

  @override
  _PlaySongScreenState createState() => _PlaySongScreenState();
}

class _PlaySongScreenState extends MusicRouteAwareState<PlaySongScreen> {
  late final PlaySongScreenNotifier sn;

  @override
  void initState() {
    super.initState();

    /// Store  the song param in MusicMainScreenNotifier
    AppConfig()
        .appContext
        .read<MusicMainScreenNotifier>()
        .currentlyPlayedSongParam = widget.param;
    sn = PlaySongScreenNotifier(widget.param);
    AppConfig()
        .appContext
        .read<MusicMainScreenNotifier>()
        .isPlaySongScreenOpen = true;
  }

  @override
  void dispose() {
    sn.closeNotifier();
    AppConfig()
        .appContext
        .read<MusicMainScreenNotifier>()
        .isPlaySongScreenOpen = false;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<PlaySongScreenNotifier>.value(
      value: sn,
      child: Scaffold(
        appBar: buildCustomAppbar(
          onBackTap: () => Nav.persistentPop(
            context,
            bottomNavController:
                context.read<MusicMainScreenNotifier>().musicTabController,
          ),
          title: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                Translation.current.played_from,
                style: TextStyle(
                  color: AppColors.accentColorLight,
                  fontSize: 45.sp,
                ),
              ),
              Gaps.vGap5,
              Text(
                widget.param.playedFrom,
                style: TextStyle(
                  color: AppColors.primaryColorLight,
                  fontSize: 40.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          actions: [
            InkWell(
              onTap: sn.onGoToPlaylistOrCollectionTap,
              child: Padding(
                padding: EdgeInsetsDirectional.only(
                  end: 30.w,
                ),
                child: SizedBox(
                  height: 75.sp,
                  width: 75.sp,
                  child: SvgPicture.asset(
                    AppConstants.SVG_PLAY_LIST2,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
          ],
          centerTitle: true,
        ),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: PlaySongScreenContent(),
      ),
    );
  }

  @override
  void onEnterScreen() {
    AppConfig()
        .appContext
        .read<MusicMainScreenNotifier>()
        .showHidSongControl(false);
  }

  @override
  void onLeaveScreen() {
    AppConfig().appContext.read<MusicMainScreenNotifier>().showHidSongControl(
          true,
        );
  }
}
