import 'package:flutter/material.dart';
import 'package:provider/src/provider.dart';
import 'package:spotify/spotify.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/features/music/presentation/screen/album_details/album_details_screen.dart';

import 'package:starter_application/features/music/presentation/screen/artist_albums_screen.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';

import '../../../../../core/common/costum_modules/screen_notifier.dart';

class ArtistAlbumsScreenNotifier extends ScreenNotifier {
  ArtistAlbumsScreenNotifier({
    required this.param,
  });
  /// Fields
  late BuildContext context;
  final MusicCubit artistAlbumsCubit = MusicCubit();
  final ArtistAlbumsScreenParam param;
  List<Album> albums = [];
  

  /// Getters and Setters

  /// Methods
  void getArtistAlbums() {
    artistAlbumsCubit.getArtistAlbums(AppConfig().appContext.read<MusicMainScreenNotifier>().authToken, param.id);
  }
  void onAlbumTap(AlbumSimple? album) {
    if (album == null) return;
    Nav.to(
      AlbumDetailsScreen.routeName,
      context: context,
      arguments: AlbumDetailsScreenParam(
        id: album.id ?? "",
        name: album.name ?? "",
        image:
            (album.images?.length ?? 0) > 0 ? album.images![0].url ?? "" : "",
        autoPlay: false,
      ),
    );
  }

  @override
  void closeNotifier() {
    artistAlbumsCubit.close();
    this.dispose();
  }
}
