import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/src/provider.dart';
import 'package:spotify_sdk/models/player_options.dart' as playerOptions;
import 'package:spotify_sdk/spotify_sdk.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/screen/play_song_screen.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';

import '../../../../../core/common/costum_modules/screen_notifier.dart';

class PlaySongScreenNotifier extends ScreenNotifier {
  PlaySongScreenNotifier(this.param);

  /// Fields
  late BuildContext context;
  final PlaySongScreenParam param;
  final spotifySdkWrapper = SpotifySdkWrapper();
  int _songProgressInMS = 0;
  Timer? songProgressTimer;
  DateTime? progressTimerStartingDate;
  bool? _isSongSaved;

  /// Getters and Setters
  int get songProgressInMS => this._songProgressInMS;
  bool? get isSongSaved => this._isSongSaved;
  set isSongSaved(bool? isSongSaved) => this._isSongSaved = isSongSaved;

  /// Methods
  void startSongProgressTracking(int playbackPositionInMS) {
    songProgressTimer?.cancel();
    progressTimerStartingDate = DateTime.now().subtract(
      Duration(
        milliseconds: playbackPositionInMS,
      ),
    );
    songProgressTimer = Timer.periodic(
        const Duration(
          milliseconds: 1,
        ), (timer) {
      _songProgressInMS =
          DateTime.now().difference(progressTimerStartingDate!).inMilliseconds;
      notifyListeners();
    });
  }

  void stopSongProgressTracking() {
    songProgressTimer?.cancel();
  }

  @override
  void closeNotifier() {
    songProgressTimer?.cancel();
    // this.dispose();
  }

  void onShuffleTap(bool setShuffle) async {
    await spotifySdkWrapper.setShuffle(setShuffle);
  }

  void onRepeatTap(playerOptions.RepeatMode? prevRepeatMode) async {
    if (prevRepeatMode != null)
      await spotifySdkWrapper
          .setRepeatMode(RepeatMode.values[(prevRepeatMode.index + 1) % 3]);
  }

  onSaveButtonTap(String songId) {
    _isSongSaved = _isSongSaved == null ? null : !_isSongSaved!;
    notifyListeners();
    AppConfig()
        .appContext
        .read<MusicMainScreenNotifier>()
        .saveUnSaveSpotifyItem(
          songId,
          type: SpotifyType.TRACK,
        );
  }

  void onSeekTap(Duration newDuration) async {
    try {
      stopSongProgressTracking();
      await SpotifySdkWrapper.seekTo(newDuration.inMilliseconds);
      startSongProgressTracking(newDuration.inMilliseconds);
    } catch (e) {
      startSongProgressTracking(newDuration.inMilliseconds);
    }
  }

  void onGoToPlaylistOrCollectionTap() {
    param.onCollectionIconTap();
    // /// If playlist
    // if (param.isPlaylist) {
    //   Nav.to(PlayListDetailsScreen.routeName,
    //       context: context,
    //       arguments: PlaylistDetailsScreenParam(
    //         id: param.collectionId ?? "",
    //         name: param.playedFrom,
    //         image: param.collectionImage ?? "",
    //         isUserPlaylist: false,
    //         autoPlay: false,
    //       ));
    // }

    // /// If custom collection
    // else {
    //   //Todo handle collection tap (Fav list - recently played ... ect)
    //   Nav.pop(context);
    // }
  }
}
