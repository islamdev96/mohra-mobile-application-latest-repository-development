import 'package:flutter/material.dart';
import 'package:spotify/spotify.dart';
import 'package:spotify_sdk/models/player_state.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/screen/select_tracks_screen/select_tracks_screen.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';

import '../../../../../core/common/costum_modules/screen_notifier.dart';

class SelectTracksScreenNotifier extends ScreenNotifier {
  SelectTracksScreenNotifier(this.param);

  /// Fields
  late BuildContext context;
  late String authToken;
  final SpotifySdkWrapper spotifySdkWrapper = SpotifySdkWrapper();
  late Stream<PlayerState> playerStateStream;
  final SelectTracksScreenParam param;
  final searchCubit = MusicCubit();
  final searchController = TextEditingController(text: null);
  final searchFocusNode = FocusNode();
  final searchKey = GlobalKey<FormFieldState>();
  List<Track> _tracks = [];

  /// Getters and Setters
  List<Track> get tracks => this._tracks;
  set tracks(List<Track> tracks) {
    this._tracks = tracks;
    notifyListeners();
  }

  /// Methods
  void onSearchSubmitted() {
    sendSearchRequest();
  }

  void sendSearchRequest() {
    searchCubit.searchTracks(
      authToken,
      search: searchController.text,
      page: 0,
    );
  }

  void onSelectTrackTap(int index, String trackId) {
    param.onTracksSelected?.call([tracks[index]]);
    Nav.pop();
  }

  @override
  void closeNotifier() {
    searchCubit.close();
    searchFocusNode.dispose();
    searchController.dispose();
    this.dispose();
  }
}
