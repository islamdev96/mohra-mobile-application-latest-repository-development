import 'package:flutter/material.dart';
import 'package:provider/src/provider.dart';
import 'package:spotify/spotify.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/screen/album_details/album_details_screen.dart';
import 'package:starter_application/features/music/presentation/screen/play_song_screen.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/generated/l10n.dart';

import '../../../../../core/common/costum_modules/screen_notifier.dart';

class MusicSearchScreenNotifier extends ScreenNotifier {
  MusicSearchScreenNotifier();

  /// Fields
  late BuildContext context;
  final searchTracksCubit = MusicCubit();
  final searchAlbumsCubit = MusicCubit();
  final searchController = TextEditingController(text: null);
  final searchFocusNode = FocusNode();
  final searchKey = GlobalKey<FormFieldState>();
  List<Track> _tracks = [];
  List<AlbumSimple> _albums = [];
  String? currentTrackId;

  /// Getters and Setters
  List<Track> get tracks => this._tracks;
  set tracks(List<Track> tracks) {
    this._tracks = tracks;
    notifyListeners();
  }

  List<AlbumSimple> get albums => this._albums;
  set albums(List<AlbumSimple> albums) {
    this._albums = albums;
    notifyListeners();
  }

  set isLoading(bool value) {
    notifyListeners();
  }

  /// Methods
  void onSearchSubmitted() {
    sendSearchRequest();
  }

  void sendSearchRequest() {
    searchTracksCubit.searchTracks(
      AppConfig().appContext.read<MusicMainScreenNotifier>().authToken,
      search: searchController.text,
      page: 0,
    );
    searchAlbumsCubit.searchAlbums(
      AppConfig().appContext.read<MusicMainScreenNotifier>().authToken,
      search: searchController.text,
      page: 0,
    );
  }

  @override
  void closeNotifier() {
    searchTracksCubit.close();
    searchAlbumsCubit.close();
    searchFocusNode.dispose();
    searchController.dispose();
    this.dispose();
  }

  void onClearTextTap() {
    searchController.text = "";
  }

  void onSongTap(String itemId) {
    context.read<MusicMainScreenNotifier>().playSong(
          spotifyId: itemId,
          type: SpotifyType.TRACK,
        );
    Nav.to(
      PlaySongScreen.routeName,
      context: context,
      arguments: PlaySongScreenParam(
          playedFrom: Translation.current.search,
          type: SpotifyType.TRACK,
          collectionId: null,
          collectionImage: null,
          onCollectionIconTap: () {
            Nav.pop(context);
          }),
    );
  }

  void onTabBarItemTap(int value) {}
  void onAlbumTap(AlbumSimple? album) {
    if (album == null) return;
    Nav.to(
      AlbumDetailsScreen.routeName,
      context: context,
      arguments: AlbumDetailsScreenParam(
        id: album.id ?? "",
        name: album.name ?? "",
        image:
            (album.images?.length ?? 0) > 0 ? album.images![0].url ?? "" : "",
        autoPlay: false,
      ),
    );
  }
}
