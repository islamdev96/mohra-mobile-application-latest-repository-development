import 'package:flutter/material.dart';
import 'package:provider/src/provider.dart';
import 'package:spotify/spotify.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/features/music/presentation/screen/add_tracks_to_playlist_screen.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';

import '../../../../../core/common/costum_modules/screen_notifier.dart';

class AddTracksToPlaylistScreenNotifier extends ScreenNotifier {
  AddTracksToPlaylistScreenNotifier(this.param);

  /// Fields
  late BuildContext context;
  final AddTracksToPlaylistScreenParam param;
  final searchCubit = MusicCubit();
  final addTrackCubit = MusicCubit();
  final searchController = TextEditingController(text: null);
  final searchFocusNode = FocusNode();
  final searchKey = GlobalKey<FormFieldState>();
  List<Track> _tracks = [];
  String? currentTrackId;
  bool _isLoading = false;

  /// Getters and Setters
  List<Track> get tracks => this._tracks;
  set tracks(List<Track> tracks) {
    this._tracks = tracks;
    notifyListeners();
  }

  bool get isLoading => this._isLoading;

  set isLoading(bool value) {
    this._isLoading = value;
    notifyListeners();
  }

  /// Methods
  void onSearchSubmitted() {
    sendSearchRequest();
  }

  void sendSearchRequest() {
    searchCubit.searchTracks(
      AppConfig().appContext.read<MusicMainScreenNotifier>().authToken,
      search: searchController.text,
      page: 0,
    );
  }

  void onAddTrackTap(String trackId) {
    currentTrackId = trackId;
    sendAddSongRequest(trackId);
  }

  void sendAddSongRequest(String trackId) {
    addTrackCubit.addTrackToPlaylist(
        AppConfig().appContext.read<MusicMainScreenNotifier>().authToken,
        trackId: trackId,
        playlistId: param.playlistId);
  }

  @override
  void closeNotifier() {
    searchCubit.close();
    addTrackCubit.close();
    searchFocusNode.dispose();
    searchController.dispose();
    this.dispose();
  }
}
