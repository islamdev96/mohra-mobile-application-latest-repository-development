import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/src/provider.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/common/utils.dart';
import 'package:starter_application/features/music/data/model/request/update_playlist_image_param.dart';
import 'package:starter_application/features/music/data/model/request/update_playlist_param.dart';
import 'package:starter_application/features/music/presentation/screen/create_playlist_screen.dart';
import 'package:starter_application/features/music/presentation/screen/playlist_details/playlist_details_screen.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';

import '../../../../../core/common/costum_modules/screen_notifier.dart';

class CreatePlaylistScreenNotifier extends ScreenNotifier {
  CreatePlaylistScreenNotifier(this.param) {
    playlist = param.playlist;
    _playlistImage = (param.playlist?.image.isNotEmpty ?? false)
        ? param.playlist?.image
        : null;
    playlistNameController = TextEditingController.fromValue(TextEditingValue(
      text: playlist?.name ?? "",
    ));
  }

  /// Fields
  late BuildContext context;
  final MusicCubit playlistCubit = MusicCubit();
  final MusicCubit uploadImageCubit = MusicCubit();
  final CreatePlaylistScreenParam param;
  String? _playlistImage;
  bool _isLoading = false;
  PlaylistDetailsScreenParam? playlist;

  /// PlaylistName textField fields
  late final TextEditingController playlistNameController;
  final GlobalKey<FormFieldState<String>> playlistNameKey =
      GlobalKey<FormFieldState<String>>();
  final playlistFocusNode = FocusNode();

  /// Getters and Setters
  String? get playlistImage => this._playlistImage;
  bool get isPlaylistNameEmpty => playlistNameController.text.isEmpty;
  bool get isLoading => this._isLoading;

  set isLoading(bool value) {
    this._isLoading = value;
    notifyListeners();
  }

  set playlistImage(String? value) {
    this._playlistImage = value;
    notifyListeners();
  }

  bool get isEdit => playlist != null;
  bool get isCreate => !isEdit;
  bool get isNewlyCreated => param.playlist == null;

  /// Methods

  @override
  void closeNotifier() {
    playlistNameController.dispose();
    playlistFocusNode.dispose();
    playlistCubit.close();
    uploadImageCubit.close();
    this.dispose();
  }

  onImagesPicked(List<XFile> imagesFiles) {
    if (imagesFiles.length > 0) {
      _playlistImage = imagesFiles[0].path;
      updatePlaylistImageRequest(imagesFiles[0]);

      notifyListeners();
    }
  }

  void onPlayListNameChanged(String value) {
    notifyListeners();
  }

  void createPlaylistRequest() {
    playlistCubit.createPlaylist(
      AppConfig().appContext.read<MusicMainScreenNotifier>().authToken,
      name: playlistNameController.text,
      //Todo
      description: "",
    );
  }

  void updatePlaylistRequest() {
    if (playlist?.id == null) return;
    playlistCubit.updatePlaylistInfo(UpdatePlaylistParam(
      id: playlist!.id,
      name: playlistNameController.text,
    ));
  }

  void onCreatePlaylistTap() {
    if (playlistNameKey.currentState!.validate()) {
      if (isCreate) {
        createPlaylistRequest();
      } else {
        updatePlaylistRequest();
      }
    }
  }

  void updatePlaylistImageRequest(XFile image) async {
    if (playlist?.id == null) return;
    final bytes = await image.readAsBytes();
    final base64Image = imageToBase64(bytes);
    uploadImageCubit.updatePlaylistImage(UpdatePlaylistImageParam(
        playlistId: playlist!.id, base64Image: base64Image!));
  }
}
