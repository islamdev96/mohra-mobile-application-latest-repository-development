import 'package:flutter/material.dart';
import 'package:provider/src/provider.dart';
import 'package:spotify/spotify.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/features/music/domain/entity/saved_albums_list_entity.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/screen/album_details/album_details_screen.dart';
import 'package:starter_application/features/music/presentation/screen/artist_albums_screen.dart';
import 'package:starter_application/features/music/presentation/screen/create_playlist_screen.dart';
import 'package:starter_application/features/music/presentation/screen/play_song_screen.dart';
import 'package:starter_application/features/music/presentation/screen/playlist_details/playlist_details_screen.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/generated/l10n.dart';

import '../../../../../core/common/costum_modules/screen_notifier.dart';
import 'music_main_screen_notifier.dart';

class MyLibraryScreenNotifier extends ScreenNotifier {
  final topArtistsCubit = MusicCubit();

  /// Fields
  late BuildContext context;

  /// Getters and Setters

  /// Methods

  @override
  void closeNotifier() {
    topArtistsCubit.close();
    this.dispose();
  }

  onItemTap(int index, PlaylistSimple? playlist) {
    if (index == 0)
      Nav.to(CreatePlaylistScreen.routeName,
          arguments: CreatePlaylistScreenParam(
              // onPlaylistCreated: () => getUserPlaylists(),
              ));
    else if (playlist != null)
      Nav.to(PlayListDetailsScreen.routeName,
          context: context,
          arguments: PlaylistDetailsScreenParam(
            id: playlist.id ?? "",
            name: playlist.name ?? "",
            image: (playlist.images?.length ?? 0) > 0
                ? playlist.images![0].url ?? ""
                : "",
            isUserPlaylist: true,
            autoPlay: false,
          ));
  }

  void getUserPlaylists() {
    AppConfig()
        .appContext
        .read<MusicMainScreenNotifier>()
        .userPlaylistsCubit
        .getUserPlaylists(
            AppConfig().appContext.read<MusicMainScreenNotifier>().authToken);
  }

  void getUserTopArtists() {
    topArtistsCubit.getUserTopArtists(
        AppConfig().appContext.read<MusicMainScreenNotifier>().authToken);
  }

  void getUserSavedAlbums() {}
  void getUserSavedTracks() {
    AppConfig()
        .appContext
        .read<MusicMainScreenNotifier>()
        .savedTracksCubit
        .getUserSavedTracks(
            AppConfig().appContext.read<MusicMainScreenNotifier>().authToken);
  }

  void onTabBarItemTap(int value) {}

  void onSavedSongTap(String itemId) {
    context.read<MusicMainScreenNotifier>().playSong(
          spotifyId: itemId,
          type: SpotifyType.TRACK,
        );
    Nav.to(
      PlaySongScreen.routeName,
      context: context,
      arguments: PlaySongScreenParam(
          playedFrom: Translation.current.favorite,
          type: SpotifyType.TRACK,
          collectionId: null,
          collectionImage: null,
          onCollectionIconTap: () {
            Nav.pop(context);
          }),
    );
  }

  onSavedAlbumTap(AlbumEntity? album) {
    if (album == null) return;
    Nav.to(
      AlbumDetailsScreen.routeName,
      context: context,
      arguments: AlbumDetailsScreenParam(
        id: album.id ?? "",
        name: album.name ?? "",
        image: album.images.length > 0 ? album.images[0].url ?? "" : "",
        autoPlay: false,
      ),
    );
  }

  onArtistTap(Artist artist) {
    Nav.to(
      ArtistAlbumsScreen.routeName,
      context: context,
      arguments: ArtistAlbumsScreenParam(
          id: artist.id ?? "",
          name: artist.name ?? "",
          image: (artist.images?.length ?? 0) > 0
              ? artist.images![0].url ?? ""
              : ""),
    );
  }
}
