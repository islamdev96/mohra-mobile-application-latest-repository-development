import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent-tab-view.dart';
import 'package:spotify/spotify.dart';
import 'package:spotify_sdk/models/player_state.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/features/home/presentation/state_m/provider/app_main_screen_notifier.dart';
import 'package:starter_application/features/music/data/model/request/music_pagination_param.dart';
import 'package:starter_application/features/music/domain/entity/saved_albums_list_entity.dart';
import 'package:starter_application/features/music/presentation/logic/spoitfy_util.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/screen/play_song_screen.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/generated/l10n.dart';

import '../../../../../core/common/costum_modules/screen_notifier.dart';

class MusicMainScreenNotifier extends ScreenNotifier {
  /// Constructors
  MusicMainScreenNotifier() {
    // oauth2Helper = OAuth2Helper(
    //   client,
    //   grantType: OAuth2Helper.AUTHORIZATION_CODE,
    //   clientId: AppConstants.SPOTIFY_CLIENT_ID,
    //   scopes: [
    //     'app-remote-control',
    //     'user-modify-playback-state',
    //     'ugc-image-upload',
    //     'user-read-private',
    //     'user-read-recently-played',
    //     'playlist-read-private',
    //     'user-library-read',
    //     'playlist-modify-private',
    //     'playlist-modify-public,user-read-currently-playing'
    //   ],
    // );
  }

  /// Fields
  late BuildContext context;

  /// Saved tracks cubit
  final savedTracksCubit = MusicCubit();
  final savedAlbumsCubit = MusicCubit();

  late String authToken;

  // SpotifyOAuth2Client client = SpotifyOAuth2Client(
  //   customUriScheme:
  //       'app.mohraapp.com.android', //Must correspond to the AndroidManifest's "android:scheme" attribute

  //   redirectUri: AppConstants.SPOTIFY_REDIRECT_URL_2,
  // );

  // late final OAuth2Helper oauth2Helper;

  final PersistentTabController musicTabController =
      PersistentTabController(initialIndex: 0);
  int _selectedIndex = 0;
  final homeKey = GlobalKey<NavigatorState>();
  final myLibraryKey = GlobalKey<NavigatorState>();
  final searchKey = GlobalKey<NavigatorState>();
  final SpotifySdkWrapper spotifySdkWrapper = SpotifySdkWrapper();
  Future<Uint8List?>? songImageFuture;
  String? prevSongName;
  late Stream<PlayerState> playerStateStream;
  PlayerState? latestPlayerState;
  bool isPlaySongScreenOpen = false;
  List<TrackSaved> _savedTracks = [];
  List<AlbumEntity> _savedAlbums = [];
  final RouteObserver<PageRoute> routeObserverHome = RouteObserver();
  final RouteObserver<PageRoute> routeObserverMyLibrary = RouteObserver();
  final RouteObserver<PageRoute> routeObserverSearch = RouteObserver();

  /// This variable is used as param to navigate to the currently played song when hitting on the song controller
  PlaySongScreenParam? currentlyPlayedSongParam;

  bool _showSongControl = false;

  /// Home Cubit
  final MusicCubit homeCubit = MusicCubit();

  /// User Playlists Cubit
  final userPlaylistsCubit = MusicCubit();

  /// Getters and Setters
  int get selectedIndex => this._selectedIndex;
  bool get showSongControl => this._showSongControl;
  GlobalKey<NavigatorState> getNavKey(int index) {
    switch (index) {
      case 0:
        return homeKey;
      case 1:
        return myLibraryKey;
      case 2:
        return searchKey;
      default:
        return homeKey;
    }
  }

  RouteObserver<PageRoute> getRouteObserver(int index) {
    switch (index) {
      case 0:
        return routeObserverHome;
      case 1:
        return routeObserverMyLibrary;
      case 2:
        return routeObserverSearch;
      default:
        return routeObserverHome;
    }
  }

  RouteObserver<PageRoute> getCurrentRouteObserver() {
    return getRouteObserver(musicTabController.index);
  }

  List<TrackSaved> get savedTracks => this._savedTracks;
  List<AlbumEntity> get savedAlbums => this._savedAlbums;

  set savedTracks(List<TrackSaved> value) {
    this._savedTracks = value;
    notifyListeners();
  }

  set savedAlbums(List<AlbumEntity> value) {
    this._savedAlbums = value;
    notifyListeners();
  }

  /// Methods

  @override
  void closeNotifier() {
    musicTabController.jumpToTab(0);
    savedTracksCubit.close();
    userPlaylistsCubit.close();
    homeCubit.close();
    savedAlbumsCubit.close();
    //Todo disconnect from spotify and close all streams

    this.dispose();
  }

  void onBottomNavigationTap(int value) {
    musicTabController.jumpToTab(
      value,
    );
    _selectedIndex = value;
    notifyListeners();
  }

  void getSavedAlbums() {
    savedAlbumsCubit.getSavedAlbums(MusicPaginationParam(30, 0));
  }

  /// Song Control logic

  void showHidSongControl(bool show, {bool listen = true}) {
    if (show != _showSongControl) {
      _showSongControl = show;
      if (listen) notifyListeners();
    }
  }

  //Todo move play song  to PlaySongScreen
  /// Play a song
  void playSong({
    required String spotifyId,
    required SpotifyType type,
    int? songIndex,
  }) {
    // _playerInfo =
    //     PlayerInfo(spotifyId: spotifyId, type: type, trackIndex: songIndex);
    notifyListeners();
    SpotifySdkWrapper().play(
      spotifyId,
      songIndex,
      type,
    );
  }

  void onPauseResumeTap(bool isPaused) {
    if (isPaused) {
      spotifySdkWrapper.resume();
    } else {
      spotifySdkWrapper.pause();
    }
  }

  void onSkipBackTap() {
    spotifySdkWrapper.skipPrevious();
  }

  void onSkipNextTap() async {
    spotifySdkWrapper.skipNext();
  }

  void saveUnSaveSpotifyItem(
    /// URI EX: spotify:track:4LRPiXqCikLlN15c3yImP7
    /// ID  EX: 4LRPiXqCikLlN15c3yImP7
    String uriOrId, {
    required SpotifyType type,
  }) async {
    try {
      /// get the real id
      final id = SpotifyUtils.getIdFromUri(uriOrId);
      // print("Saved/UnSaved Song id: ${id}");
      /// Check if track is Saved or not
      bool isSaved = isItemSaved(id, type: type);

      /// If saved then un save it
      if (isSaved) {
        await spotifySdkWrapper.removeFromLibrary(id, type);
      }

      /// If Unsaved then save it
      else {
        await spotifySdkWrapper.addToLibrary(
          id,
          type,
        );
      }

      /// Refresh saved items
      refreshSavedItems(type);
      //Todo handle album,ect messages
      // showSnackbar("Track saved successfully");
    } catch (e) {
      //Todo handle album,ect messages
      // showSnackbar("Failed to save the track");
    }
  }

  /// Currently save songs only
  /// URI EX: spotify:track:4LRPiXqCikLlN15c3yImP7
  /// ID  EX: 4LRPiXqCikLlN15c3yImP7
  /// For Now it only save tracks and albums
  bool isItemSaved(
    String uriOrId, {
    required SpotifyType type,
  }) {
    final id = SpotifyUtils.getIdFromUri(uriOrId);
    if (type == SpotifyType.TRACK)
      return savedTracks.map((e) => e.track?.id?.toString()).contains(id);
    if (type == SpotifyType.ALBUM)
      return savedAlbums.map((e) => e.id?.toString()).contains(id);
    return false;
  }

  void onSongControlTap(bool isPaused) {
    if (currentlyPlayedSongParam != null) {
      onPauseResumeTap(!isPaused);
      Nav.to(
        PlaySongScreen.routeName,
        context: getNavKey(musicTabController.index).currentContext,
        arguments: currentlyPlayedSongParam,
      );
    }
  }

  /// Refresh user playlists
  void refreshUserPlaylists() {
    /// Refresh home because it has user playlists section
    homeCubit.getMusicHome(authToken);

    /// Refresh user playlists in myLibrary
    userPlaylistsCubit.getUserPlaylists(authToken);
  }

  /// It only support tracks and albums for now
  void refreshSavedItems(SpotifyType type) {
    if (type == SpotifyType.TRACK)
      savedTracksCubit.getUserSavedTracks(authToken);
    if (type == SpotifyType.ALBUM) getSavedAlbums();
  }
}
