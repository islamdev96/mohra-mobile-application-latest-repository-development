import 'package:flutter/material.dart';
import 'package:provider/src/provider.dart';
import 'package:spotify/spotify.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/common/utils.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/screen/add_tracks_to_playlist_screen.dart';
import 'package:starter_application/features/music/presentation/screen/play_song_screen.dart';
import 'package:starter_application/features/music/presentation/screen/playlist_details/playlist_details_screen.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/generated/l10n.dart';

import '../../../../../core/common/costum_modules/screen_notifier.dart';
import 'music_main_screen_notifier.dart';

class PlayListDetailsScreenNotifier extends ScreenNotifier {
  PlayListDetailsScreenNotifier(PlaylistDetailsScreenParam param) {
    this.param = param;
  }

  /// Fields
  late BuildContext context;
  late PlaylistDetailsScreenParam _param;

  final playlistTracksCubit = MusicCubit();
  final libraryCubit = MusicCubit();
  List<Track> tracks = [];
  bool _isLoading = false;
  final spotifySdkWrapper = SpotifySdkWrapper();

  /// Getters and Setters
  bool get isLoading => this._isLoading;

  set isLoading(bool value) {
    this._isLoading = value;
    notifyListeners();
  }

  PlaylistDetailsScreenParam get param => this._param;

  set param(PlaylistDetailsScreenParam value) {
    this._param = value;
    notifyListeners();
  }

  /// Methods

  @override
  void closeNotifier() {
    playlistTracksCubit.close();
    libraryCubit.close();
    this.dispose();
  }

  onSongTap({
    required String playlistId,
    required String playlistName,
    required String? playlistImage,
    required int songIndex,
  }) {
    context.read<MusicMainScreenNotifier>().playSong(
          spotifyId: playlistId,
          type: SpotifyType.PLAYLIST,
          songIndex: songIndex,
        );
    Nav.to(
      PlaySongScreen.routeName,
      context: context,
      arguments: PlaySongScreenParam(
          playedFrom: playlistName,
          type: SpotifyType.PLAYLIST,
          collectionId: playlistId,
          collectionImage: playlistImage,
          onCollectionIconTap: () {
            Nav.to(PlayListDetailsScreen.routeName,
                context: context,
                arguments: PlaylistDetailsScreenParam(
                  id: playlistId,
                  name: playlistName,
                  image: playlistImage ?? "",
                  isUserPlaylist: param.isUserPlaylist,
                  autoPlay: false,
                ));
          }),
    );
  }

  String artistsToString() {
    /// The artists that we will display
    List<Artist> filteredArtists = [];
    for (int i = 0; i < tracks.length; i++) {
      final artists = tracks[0].artists ?? [];
      for (int j = 0; j < artists.length; j++) {
        final artist = artists[j];
        if (artist.name != null) {
          filteredArtists.add(artist);
        }
      }
    }
    final artistsCount = filteredArtists.length;
    return "${getArtists(artistsCount > 2 ? [
            (filteredArtists[0].name ?? ""),
            (filteredArtists[1].name ?? "")
          ] : filteredArtists.map((e) => e.name ?? "").toList())}${artistsCount > 2 ? " ${Translation.current.and_many_more}" : ""}"
        .toUpperCase();
  }

  void onAddSongTap() {
    Nav.to(AddTracksToPlaylistScreen.routeName,
        arguments: AddTracksToPlaylistScreenParam(
            playlistId: param.id,
            onTrackAdded: () {
              sendPlaylistsTracksRequest();
            }));
  }

  void sendPlaylistsTracksRequest() {
    playlistTracksCubit.getPlaylistTracks(
        AppConfig().appContext.read<MusicMainScreenNotifier>().authToken,
        param.id);
  }

  void onShuffleTap(bool setShuffle) async {
    await spotifySdkWrapper.setShuffle(setShuffle);
  }
}
