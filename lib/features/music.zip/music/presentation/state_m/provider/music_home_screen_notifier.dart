import 'package:flutter/material.dart';
import 'package:provider/src/provider.dart';
import 'package:spotify/spotify.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/features/music/domain/entity/music_home_entity.dart.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/screen/artist_albums_screen.dart';
import 'package:starter_application/features/music/presentation/screen/play_song_screen.dart';
import 'package:starter_application/features/music/presentation/screen/playlist_details/playlist_details_screen.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/generated/l10n.dart';

import '../../../../../core/common/costum_modules/screen_notifier.dart';

class MusicHomeScreenNotifier extends ScreenNotifier {
  /// Fields
  late BuildContext context;

  final MusicCubit playlistTracksCubit = MusicCubit();

  late MusicHomeEntity musicHomeEntity;

  /// Getters and Setters

  /// Methods

  @override
  void closeNotifier() {
    playlistTracksCubit.close();
    this.dispose();
  }

  void onPlaylistTap(int index) {
    getPlaylistTracks(musicHomeEntity.playlists[index].id!);
  }

  void getPlaylistTracks(String playlistId) {
    playlistTracksCubit.getPlaylistTracks(
        AppConfig().appContext.read<MusicMainScreenNotifier>().authToken,
        playlistId);
  }

  void onUserPlaylistTap(PlaylistSimple playlist) {
    Nav.to(PlayListDetailsScreen.routeName,
        context: context,
        arguments: PlaylistDetailsScreenParam(
          id: playlist.id ?? "",
          name: playlist.name ?? "",
          image: (playlist.images?.length ?? 0) > 0
              ? playlist.images![0].url ?? ""
              : "",
          isUserPlaylist: true,
          autoPlay: false,
        ));
  }

  void onRecentlyPlayedTrackTap(
    String id,
  ) {
    context.read<MusicMainScreenNotifier>().playSong(
          spotifyId: id,
          type: SpotifyType.TRACK,
        );
    Nav.to(
      PlaySongScreen.routeName,
      context: context,
      arguments: PlaySongScreenParam(
          //Todo
          playedFrom: Translation.current.recently_played,
          type: SpotifyType.TRACK,
          collectionId: null,
          collectionImage: null,
          onCollectionIconTap: () {
            Nav.pop(context);
          }),
    );
  }

  void onPlaylistTrackTap({
    required String playlistId,
    required String playlistName,
    required String? playlistImage,
    required int trackIndex,
  }) {
    context.read<MusicMainScreenNotifier>().playSong(
          spotifyId: playlistId,
          type: SpotifyType.PLAYLIST,
          songIndex: trackIndex,
        );
    Nav.to(
      PlaySongScreen.routeName,
      context: context,
      arguments: PlaySongScreenParam(
          playedFrom: playlistName,
          type: SpotifyType.PLAYLIST,
          collectionId: playlistId,
          collectionImage: playlistImage,
          onCollectionIconTap: () {
            Nav.to(PlayListDetailsScreen.routeName,
                context: context,
                arguments: PlaylistDetailsScreenParam(
                  id: playlistId,
                  name: playlistName,
                  image: playlistImage ?? "",
                  isUserPlaylist: false,
                  autoPlay: false,
                ));
          }),
    );
  }

  onMostPopularArtistTap(Artist artist) {
    Nav.to(
      ArtistAlbumsScreen.routeName,
      context: context,
      arguments: ArtistAlbumsScreenParam(
          id: artist.id ?? "",
          name: artist.name ?? "",
          image: (artist.images?.length ?? 0) > 0
              ? artist.images![0].url ?? ""
              : ""),
    );
  }
}
