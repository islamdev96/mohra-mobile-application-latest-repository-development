import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:spotify/spotify.dart';
import 'package:starter_application/core/params/no_params.dart';
import 'package:starter_application/di/service_locator.dart';
import 'package:starter_application/features/music/data/model/request/music_pagination_param.dart';
import 'package:starter_application/features/music/data/model/request/update_playlist_image_param.dart';
import 'package:starter_application/features/music/data/model/request/update_playlist_param.dart';
import 'package:starter_application/features/music/domain/entity/artists_entity.dart';
import 'package:starter_application/features/music/domain/entity/music_home_entity.dart.dart';
import 'package:starter_application/features/music/domain/entity/playlist_tracks_list_entity.dart';
import 'package:starter_application/features/music/domain/entity/saved_albums_list_entity.dart';
import 'package:starter_application/features/music/domain/entity/saved_tracks_entity.dart';
import 'package:starter_application/features/music/domain/entity/user_playlists_entity.dart';
import 'package:starter_application/features/music/domain/usecase/get_saved_albums_usecase.dart';
import 'package:starter_application/features/music/domain/usecase/recently_played_tracks_usecase.dart';
import 'package:starter_application/features/music/domain/usecase/update_playlist_image_usecase.dart';
import 'package:starter_application/features/music/domain/usecase/update_playlist_usecase.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_api_wrapper.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_constants.dart';
import 'package:starter_application/generated/l10n.dart';

import '../../../../../core/errors/app_errors.dart';

part 'music_cubit.freezed.dart';
part 'music_state.dart';

//Todo Refactor
//Todo Create External api response validator (Validator that return Either<AppErrors,Model/Entity> so we it is easier to add it to the structure)
//Todo handle error types
class MusicCubit extends Cubit<MusicState> {
  MusicCubit() : super(const MusicState.musicInitState());
  //Todo use await to call all the requests in the same time
  void getMusicHome(final String authToken) async {
    emit(const MusicState.musicLoadingState());
    try {
      /// Get SpotifyApiWrapper instance
      final spotifyApiWrapper = SpotifyApiWrapper(authToken);

      /// Get first category playlists
      final playlists = await spotifyApiWrapper.getPlaylistsByCategoryIndex(0);

      /// Get recently played tracks
      final recentlyPlayedTracksResult =
          await getIt<RecentlyPlayedTracksUsecase>()(NoParams());

      /// Get Most Popular artists by getting the first artists of the top popular songs
      final top50PlaylistTracks = await spotifyApiWrapper
          .getPlaylistTracks(SpotifyConstants.TOP_50_GLOBALS_PLAYLIST_ID);
      final List<String> mostPopularArtistsIds = [];

      /// Get first artist of each song
      for (int i = 0; i < top50PlaylistTracks.length; i++) {
        final track = top50PlaylistTracks[i];
        if ((track.artists?.length ?? 0) > 0) {
          final artist = track.artists![0];
          if (artist.id != null && !mostPopularArtistsIds.contains(artist.id))
            mostPopularArtistsIds.add(artist.id!);
        }
      }
      final List<Artist> mostPopularArtists =
          await spotifyApiWrapper.getArtistByIds(mostPopularArtistsIds);

      /// GET user's playlists
      final userPlaylists = await spotifyApiWrapper.getCurrentUserPlaylists();

      /// Get user's saved tracks
      final userSavedTracks =
          await spotifyApiWrapper.getCurrentUserSavedTracks();

      if (recentlyPlayedTracksResult.hasDataOnly) {
        emit(MusicState.musicHomeLoaded(MusicHomeEntity(
          playlists: playlists,
          recentlyPlayedTracksListEntity: recentlyPlayedTracksResult.data!,
          mostPopularArtists: mostPopularArtists,
          userPlaylists: userPlaylists,
          savedTracks: userSavedTracks,
        )));
      } else {
        emit(MusicState.musicErrorState(
          recentlyPlayedTracksResult.error!,
          () => this.getMusicHome(authToken),
        ));
      }
    } catch (e) {
      emit(MusicState.musicErrorState(
        CustomError(
          message: e.toString(),
        ),
        () => this.getMusicHome(authToken),
      ));
    }
  }

  void getPlaylistTracks(
      final String authToken, final String playlistId) async {
    emit(const MusicState.musicLoadingState());
    try {
      /// Get SpotifyApiWrapper instance
      final spotifyApiWrapper = SpotifyApiWrapper(authToken);

      /// Get first category playlists
      final tracks = await spotifyApiWrapper.getPlaylistTracks(playlistId);

      emit(MusicState.playlistTracksLoaded(PlaylistTracksListEntity(
        tracks,
      )));
    } catch (e) {
      emit(MusicState.musicErrorState(
        CustomError(
          message: e.toString(),
        ),
        () => this.getPlaylistTracks(authToken, playlistId),
      ));
    }
  }

  void getUserPlaylists(final String authToken) async {
    emit(const MusicState.musicLoadingState());
    try {
      /// Get SpotifyApiWrapper instance
      final spotifyApiWrapper = SpotifyApiWrapper(authToken);

      /// GET user's playlists
      final userPlaylists = await spotifyApiWrapper.getCurrentUserPlaylists();

      emit(MusicState.userPlaylistsLoaded(UserPlaylistsEntity(
        userPlaylists,
      )));
    } catch (e) {
      emit(MusicState.musicErrorState(
        CustomError(
          message: e.toString(),
        ),
        () => this.getUserPlaylists(authToken),
      ));
    }
  }

  void getUserTopArtists(final String authToken) async {
    emit(const MusicState.musicLoadingState());
    try {
      /// Get SpotifyApiWrapper instance
      final spotifyApiWrapper = SpotifyApiWrapper(authToken);

      /// Get user's top artists
      final userTopArtists = await spotifyApiWrapper.getCurrentTopUserArtists();

      emit(MusicState.userTopArtistsLoaded(ArtistsListEntity(
        userTopArtists,
      )));
    } catch (e) {
      emit(MusicState.musicErrorState(
        CustomError(
          message: e.toString(),
        ),
        () => this.getUserTopArtists(authToken),
      ));
    }
  }

  void getUserSavedTracks(final String authToken) async {
    emit(const MusicState.musicLoadingState());
    try {
      /// Get SpotifyApiWrapper instance
      final spotifyApiWrapper = SpotifyApiWrapper(authToken);

      /// Get user's saved tracks
      final userSavedTracks =
          await spotifyApiWrapper.getCurrentUserSavedTracks();

      emit(MusicState.userSavedTracksLoaded(SavedTracksEntity(
        userSavedTracks,
      )));
    } catch (e) {
      emit(MusicState.musicErrorState(
        CustomError(
          message: e.toString(),
        ),
        () => this.getUserSavedTracks(authToken),
      ));
    }
  }

  void createPlaylist(final String authToken,
      {required String name, required String description}) async {
    emit(const MusicState.musicLoadingState());
    try {
      /// Get SpotifyApiWrapper instance
      final spotifyApiWrapper = SpotifyApiWrapper(authToken);

      final playlist = await spotifyApiWrapper.createPlaylist(
        name: name,
        description: description,
      );
      if (playlist != null)
        emit(MusicState.createPlaylistLoaded(playlist));
      else {
        emit(MusicState.musicErrorState(
          CustomError(
            message: Translation.current.errorOccurred,
          ),
          () => this
              .createPlaylist(authToken, name: name, description: description),
        ));
      }
    } catch (e) {
      emit(MusicState.musicErrorState(
        CustomError(
          message: e.toString(),
        ),
        () => this.createPlaylist(
          authToken,
          name: name,
          description: description,
        ),
      ));
    }
  }

  void addTrackToPlaylist(final String authToken,
      {required String trackId, required String playlistId}) async {
    emit(const MusicState.musicLoadingState());
    try {
      /// Get SpotifyApiWrapper instance
      final spotifyApiWrapper = SpotifyApiWrapper(authToken);

      final res = await spotifyApiWrapper.addTrackToPlaylist(
        trackId: trackId,
        playlistId: playlistId,
      );
      if (res == true) {
        emit(const MusicState.addTrackToPlaylistLoaded());
      } else {
        emit(
          MusicState.musicErrorState(
            CustomError(
              message: Translation.current.errorOccurred,
            ),
            () => this.addTrackToPlaylist(
              authToken,
              trackId: trackId,
              playlistId: playlistId,
            ),
          ),
        );
      }
    } catch (e) {
      emit(
        MusicState.musicErrorState(
          CustomError(
            message: e.toString(),
          ),
          () => this.addTrackToPlaylist(
            authToken,
            trackId: trackId,
            playlistId: playlistId,
          ),
        ),
      );
    }
  }

  void searchTracks(
    final String authToken, {
    required String search,
    required int page,
  }) async {
    emit(const MusicState.musicLoadingState());
    try {
      /// Get SpotifyApiWrapper instance
      final spotifyApiWrapper = SpotifyApiWrapper(authToken);

      final tracks =
          await spotifyApiWrapper.searchTracks(page: page, search: search);
      if (tracks == null) {
        MusicState.musicErrorState(
          CustomError(
            message: Translation.current.errorOccurred,
          ),
          () => this.searchTracks(
            authToken,
            page: page,
            search: search,
          ),
        );
      } else
        emit(
          MusicState.searchTracksLoaded(
            tracks,
          ),
        );
    } catch (e) {
      emit(MusicState.musicErrorState(
        CustomError(
          message: e.toString(),
        ),
        () => this.searchTracks(
          authToken,
          page: page,
          search: search,
        ),
      ));
    }
  }

  void searchAlbums(
    final String authToken, {
    required String search,
    required int page,
  }) async {
    emit(const MusicState.musicLoadingState());
    try {
      /// Get SpotifyApiWrapper instance
      final spotifyApiWrapper = SpotifyApiWrapper(authToken);

      final albums =
          await spotifyApiWrapper.searchAlbums(page: page, search: search);
      if (albums == null) {
        MusicState.musicErrorState(
          CustomError(
            message: Translation.current.errorOccurred,
          ),
          () => this.searchAlbums(
            authToken,
            page: page,
            search: search,
          ),
        );
      } else
        emit(
          MusicState.searchAlbumsLoaded(
            albums,
          ),
        );
    } catch (e) {
      emit(MusicState.musicErrorState(
        CustomError(
          message: e.toString(),
        ),
        () => this.searchAlbums(
          authToken,
          page: page,
          search: search,
        ),
      ));
    }
  }

  /// For now it search tracks and albums only
  void searchItems(
    final String authToken, {
    required String search,
    required int page,
  }) async {
    emit(const MusicState.musicLoadingState());
    try {
      /// Get SpotifyApiWrapper instance
      final spotifyApiWrapper = SpotifyApiWrapper(authToken);

      final result =
          await spotifyApiWrapper.searchSpotifyItem(page: page, search: search);
      if (result == null) {
        MusicState.musicErrorState(
          CustomError(
            message: Translation.current.errorOccurred,
          ),
          () => this.searchItems(
            authToken,
            page: page,
            search: search,
          ),
        );
      } else
        emit(
          MusicState.searchItemsLoaded(
            result,
          ),
        );
    } catch (e) {
      emit(MusicState.musicErrorState(
        CustomError(
          message: e.toString(),
        ),
        () => this.searchItems(
          authToken,
          page: page,
          search: search,
        ),
      ));
    }
  }

  void getRecentlyPlayedTracks() async {
    emit(const MusicState.musicLoadingState());
    final result = await getIt<RecentlyPlayedTracksUsecase>()(NoParams());
    result.pick(
      onData: (d) => emit(MusicState.recentlyPlayedTracksLoaded(d)),
      onError: (e) => emit(
          MusicState.musicErrorState(e, () => this.getRecentlyPlayedTracks())),
    );
  }

  void updatePlaylistImage(UpdatePlaylistImageParam param) async {
    emit(const MusicState.musicLoadingState());
    final result = await getIt<UpdatePlaylistImageUsecase>()(param);
    result.pick(
      onData: (d) => emit(const MusicState.updatePlaylistImageLoaded()),
      onError: (e) => emit(
          MusicState.musicErrorState(e, () => this.updatePlaylistImage(param))),
    );
  }

  void updatePlaylistInfo(UpdatePlaylistParam param) async {
    emit(const MusicState.musicLoadingState());
    final result = await getIt<UpdatePlaylistUsecase>()(param);
    result.pick(
      onData: (d) => emit(const MusicState.updatePlaylistInfoLoaded()),
      onError: (e) => emit(
          MusicState.musicErrorState(e, () => this.updatePlaylistInfo(param))),
    );
  }

  void getSavedAlbums(MusicPaginationParam param) async {
    emit(const MusicState.musicLoadingState());
    final result = await getIt<GetSavedAlbumsUsecase>()(param);
    result.pick(
      onData: (d) => emit(MusicState.getSavedAlbumsLoaded(d)),
      onError: (e) =>
          emit(MusicState.musicErrorState(e, () => this.getSavedAlbums(param))),
    );
  }

  void getAlbumTracks(final String authToken, final String id) async {
    emit(const MusicState.musicLoadingState());
    try {
      /// Get SpotifyApiWrapper instance
      final spotifyApiWrapper = SpotifyApiWrapper(authToken);

      /// Get first category playlists
      final tracks = await spotifyApiWrapper.getAlbumTracks(id);

      emit(MusicState.getAlbumTracksLoaded(tracks));
    } catch (e) {
      emit(MusicState.musicErrorState(
        CustomError(
          message: e.toString(),
        ),
        () => this.getAlbumTracks(authToken, id),
      ));
    }
  }

  void getArtistAlbums(final String authToken, final String id) async {
    emit(const MusicState.musicLoadingState());
    try {
      /// Get SpotifyApiWrapper instance
      final spotifyApiWrapper = SpotifyApiWrapper(authToken);

      /// Get first category playlists
      final albums = await spotifyApiWrapper.getArtistAlbums(id);

      emit(MusicState.getArtistAlbumsLoaded(albums));
    } catch (e) {
      emit(MusicState.musicErrorState(
        CustomError(
          message: e.toString(),
        ),
        () => this.getArtistAlbums(authToken, id),
      ));
    }
  }

  void emitSavedTracksLoadedState(SavedTracksEntity entity) {
    emit(
      UserSavedTracksLoaded(
        entity,
      ),
    );
  }
}
