part of 'music_cubit.dart';

@freezed
class MusicState with _$MusicState {
  const factory MusicState.musicInitState() = MusicInitState;

  const factory MusicState.musicLoadingState() = MusicLoadingState;
  const factory MusicState.musicHomeLoaded(MusicHomeEntity musicHomeEntity) =
      MusicHomeLoaded;
  const factory MusicState.playlistTracksLoaded(
      PlaylistTracksListEntity tracksListEntity) = PlaylistTracksLoaded;
  const factory MusicState.userPlaylistsLoaded(
      UserPlaylistsEntity playlistsEntity) = UserPlaylistsLoaded;
  const factory MusicState.userTopArtistsLoaded(
      ArtistsListEntity artistsEntity) = UserTopArtistsLoaded;
  const factory MusicState.userSavedTracksLoaded(
      SavedTracksEntity tracksEntity) = UserSavedTracksLoaded;
  const factory MusicState.createPlaylistLoaded(Playlist playlist) =
      CreatePlaylistLoaded;
  const factory MusicState.addTrackToPlaylistLoaded() =
      AddTrackToPlaylistLoaded;
  const factory MusicState.searchTracksLoaded(List<Track> tracks) =
      SearchTracksLoaded;
  const factory MusicState.searchAlbumsLoaded(List<AlbumSimple> albums) =
      SearchAlbumsLoaded;
  const factory MusicState.recentlyPlayedTracksLoaded(
      RecentlyPlayedTracksListEntity) = RecentlyPlayedTracksLoaded;
  const factory MusicState.updatePlaylistImageLoaded() =
      UpdatePlaylistImageLoaded;
  const factory MusicState.updatePlaylistInfoLoaded() =
      UpdatePlaylistInfoLoaded;
  const factory MusicState.getSavedAlbumsLoaded(SavedAlbumsListEntity savedAlbumsListEntity) =
      GetSavedAlbumsLoaded;
  const factory MusicState.searchItemsLoaded(SpotifySearchResult result) =
      SearchItemsLoaded;
  const factory MusicState.getAlbumTracksLoaded(List<TrackSimple> tracks) =
      GetAlbumTracksLoaded;
  const factory MusicState.getArtistAlbumsLoaded(List<Album> albums) =
      GetArtistAlbumsLoaded;

  const factory MusicState.musicErrorState(
    AppErrors error,
    VoidCallback callback,
  ) = MusicErrorState;
}
