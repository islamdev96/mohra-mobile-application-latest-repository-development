// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'music_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more informations: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
class _$MusicStateTearOff {
  const _$MusicStateTearOff();

  MusicInitState musicInitState() {
    return const MusicInitState();
  }

  MusicLoadingState musicLoadingState() {
    return const MusicLoadingState();
  }

  MusicHomeLoaded musicHomeLoaded(MusicHomeEntity musicHomeEntity) {
    return MusicHomeLoaded(
      musicHomeEntity,
    );
  }

  PlaylistTracksLoaded playlistTracksLoaded(
      PlaylistTracksListEntity tracksListEntity) {
    return PlaylistTracksLoaded(
      tracksListEntity,
    );
  }

  UserPlaylistsLoaded userPlaylistsLoaded(UserPlaylistsEntity playlistsEntity) {
    return UserPlaylistsLoaded(
      playlistsEntity,
    );
  }

  UserTopArtistsLoaded userTopArtistsLoaded(ArtistsListEntity artistsEntity) {
    return UserTopArtistsLoaded(
      artistsEntity,
    );
  }

  UserSavedTracksLoaded userSavedTracksLoaded(SavedTracksEntity tracksEntity) {
    return UserSavedTracksLoaded(
      tracksEntity,
    );
  }

  CreatePlaylistLoaded createPlaylistLoaded(Playlist playlist) {
    return CreatePlaylistLoaded(
      playlist,
    );
  }

  AddTrackToPlaylistLoaded addTrackToPlaylistLoaded() {
    return const AddTrackToPlaylistLoaded();
  }

  SearchTracksLoaded searchTracksLoaded(List<Track> tracks) {
    return SearchTracksLoaded(
      tracks,
    );
  }

  SearchAlbumsLoaded searchAlbumsLoaded(List<AlbumSimple> albums) {
    return SearchAlbumsLoaded(
      albums,
    );
  }

  RecentlyPlayedTracksLoaded recentlyPlayedTracksLoaded(
      dynamic RecentlyPlayedTracksListEntity) {
    return RecentlyPlayedTracksLoaded(
      RecentlyPlayedTracksListEntity,
    );
  }

  UpdatePlaylistImageLoaded updatePlaylistImageLoaded() {
    return const UpdatePlaylistImageLoaded();
  }

  UpdatePlaylistInfoLoaded updatePlaylistInfoLoaded() {
    return const UpdatePlaylistInfoLoaded();
  }

  GetSavedAlbumsLoaded getSavedAlbumsLoaded(
      SavedAlbumsListEntity savedAlbumsListEntity) {
    return GetSavedAlbumsLoaded(
      savedAlbumsListEntity,
    );
  }

  SearchItemsLoaded searchItemsLoaded(SpotifySearchResult result) {
    return SearchItemsLoaded(
      result,
    );
  }

  GetAlbumTracksLoaded getAlbumTracksLoaded(List<TrackSimple> tracks) {
    return GetAlbumTracksLoaded(
      tracks,
    );
  }

  GetArtistAlbumsLoaded getArtistAlbumsLoaded(List<Album> albums) {
    return GetArtistAlbumsLoaded(
      albums,
    );
  }

  MusicErrorState musicErrorState(AppErrors error, VoidCallback callback) {
    return MusicErrorState(
      error,
      callback,
    );
  }
}

/// @nodoc
const $MusicState = _$MusicStateTearOff();

/// @nodoc
mixin _$MusicState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MusicStateCopyWith<$Res> {
  factory $MusicStateCopyWith(
          MusicState value, $Res Function(MusicState) then) =
      _$MusicStateCopyWithImpl<$Res>;
}

/// @nodoc
class _$MusicStateCopyWithImpl<$Res> implements $MusicStateCopyWith<$Res> {
  _$MusicStateCopyWithImpl(this._value, this._then);

  final MusicState _value;
  // ignore: unused_field
  final $Res Function(MusicState) _then;
}

/// @nodoc
abstract class $MusicInitStateCopyWith<$Res> {
  factory $MusicInitStateCopyWith(
          MusicInitState value, $Res Function(MusicInitState) then) =
      _$MusicInitStateCopyWithImpl<$Res>;
}

/// @nodoc
class _$MusicInitStateCopyWithImpl<$Res> extends _$MusicStateCopyWithImpl<$Res>
    implements $MusicInitStateCopyWith<$Res> {
  _$MusicInitStateCopyWithImpl(
      MusicInitState _value, $Res Function(MusicInitState) _then)
      : super(_value, (v) => _then(v as MusicInitState));

  @override
  MusicInitState get _value => super._value as MusicInitState;
}

/// @nodoc

class _$MusicInitState implements MusicInitState {
  const _$MusicInitState();

  @override
  String toString() {
    return 'MusicState.musicInitState()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is MusicInitState);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return musicInitState();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return musicInitState?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (musicInitState != null) {
      return musicInitState();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return musicInitState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return musicInitState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (musicInitState != null) {
      return musicInitState(this);
    }
    return orElse();
  }
}

abstract class MusicInitState implements MusicState {
  const factory MusicInitState() = _$MusicInitState;
}

/// @nodoc
abstract class $MusicLoadingStateCopyWith<$Res> {
  factory $MusicLoadingStateCopyWith(
          MusicLoadingState value, $Res Function(MusicLoadingState) then) =
      _$MusicLoadingStateCopyWithImpl<$Res>;
}

/// @nodoc
class _$MusicLoadingStateCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $MusicLoadingStateCopyWith<$Res> {
  _$MusicLoadingStateCopyWithImpl(
      MusicLoadingState _value, $Res Function(MusicLoadingState) _then)
      : super(_value, (v) => _then(v as MusicLoadingState));

  @override
  MusicLoadingState get _value => super._value as MusicLoadingState;
}

/// @nodoc

class _$MusicLoadingState implements MusicLoadingState {
  const _$MusicLoadingState();

  @override
  String toString() {
    return 'MusicState.musicLoadingState()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is MusicLoadingState);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return musicLoadingState();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return musicLoadingState?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (musicLoadingState != null) {
      return musicLoadingState();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return musicLoadingState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return musicLoadingState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (musicLoadingState != null) {
      return musicLoadingState(this);
    }
    return orElse();
  }
}

abstract class MusicLoadingState implements MusicState {
  const factory MusicLoadingState() = _$MusicLoadingState;
}

/// @nodoc
abstract class $MusicHomeLoadedCopyWith<$Res> {
  factory $MusicHomeLoadedCopyWith(
          MusicHomeLoaded value, $Res Function(MusicHomeLoaded) then) =
      _$MusicHomeLoadedCopyWithImpl<$Res>;
  $Res call({MusicHomeEntity musicHomeEntity});
}

/// @nodoc
class _$MusicHomeLoadedCopyWithImpl<$Res> extends _$MusicStateCopyWithImpl<$Res>
    implements $MusicHomeLoadedCopyWith<$Res> {
  _$MusicHomeLoadedCopyWithImpl(
      MusicHomeLoaded _value, $Res Function(MusicHomeLoaded) _then)
      : super(_value, (v) => _then(v as MusicHomeLoaded));

  @override
  MusicHomeLoaded get _value => super._value as MusicHomeLoaded;

  @override
  $Res call({
    Object? musicHomeEntity = freezed,
  }) {
    return _then(MusicHomeLoaded(
      musicHomeEntity == freezed
          ? _value.musicHomeEntity
          : musicHomeEntity // ignore: cast_nullable_to_non_nullable
              as MusicHomeEntity,
    ));
  }
}

/// @nodoc

class _$MusicHomeLoaded implements MusicHomeLoaded {
  const _$MusicHomeLoaded(this.musicHomeEntity);

  @override
  final MusicHomeEntity musicHomeEntity;

  @override
  String toString() {
    return 'MusicState.musicHomeLoaded(musicHomeEntity: $musicHomeEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is MusicHomeLoaded &&
            const DeepCollectionEquality()
                .equals(other.musicHomeEntity, musicHomeEntity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(musicHomeEntity));

  @JsonKey(ignore: true)
  @override
  $MusicHomeLoadedCopyWith<MusicHomeLoaded> get copyWith =>
      _$MusicHomeLoadedCopyWithImpl<MusicHomeLoaded>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return musicHomeLoaded(musicHomeEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return musicHomeLoaded?.call(musicHomeEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (musicHomeLoaded != null) {
      return musicHomeLoaded(musicHomeEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return musicHomeLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return musicHomeLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (musicHomeLoaded != null) {
      return musicHomeLoaded(this);
    }
    return orElse();
  }
}

abstract class MusicHomeLoaded implements MusicState {
  const factory MusicHomeLoaded(MusicHomeEntity musicHomeEntity) =
      _$MusicHomeLoaded;

  MusicHomeEntity get musicHomeEntity;
  @JsonKey(ignore: true)
  $MusicHomeLoadedCopyWith<MusicHomeLoaded> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PlaylistTracksLoadedCopyWith<$Res> {
  factory $PlaylistTracksLoadedCopyWith(PlaylistTracksLoaded value,
          $Res Function(PlaylistTracksLoaded) then) =
      _$PlaylistTracksLoadedCopyWithImpl<$Res>;
  $Res call({PlaylistTracksListEntity tracksListEntity});
}

/// @nodoc
class _$PlaylistTracksLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $PlaylistTracksLoadedCopyWith<$Res> {
  _$PlaylistTracksLoadedCopyWithImpl(
      PlaylistTracksLoaded _value, $Res Function(PlaylistTracksLoaded) _then)
      : super(_value, (v) => _then(v as PlaylistTracksLoaded));

  @override
  PlaylistTracksLoaded get _value => super._value as PlaylistTracksLoaded;

  @override
  $Res call({
    Object? tracksListEntity = freezed,
  }) {
    return _then(PlaylistTracksLoaded(
      tracksListEntity == freezed
          ? _value.tracksListEntity
          : tracksListEntity // ignore: cast_nullable_to_non_nullable
              as PlaylistTracksListEntity,
    ));
  }
}

/// @nodoc

class _$PlaylistTracksLoaded implements PlaylistTracksLoaded {
  const _$PlaylistTracksLoaded(this.tracksListEntity);

  @override
  final PlaylistTracksListEntity tracksListEntity;

  @override
  String toString() {
    return 'MusicState.playlistTracksLoaded(tracksListEntity: $tracksListEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is PlaylistTracksLoaded &&
            const DeepCollectionEquality()
                .equals(other.tracksListEntity, tracksListEntity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(tracksListEntity));

  @JsonKey(ignore: true)
  @override
  $PlaylistTracksLoadedCopyWith<PlaylistTracksLoaded> get copyWith =>
      _$PlaylistTracksLoadedCopyWithImpl<PlaylistTracksLoaded>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return playlistTracksLoaded(tracksListEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return playlistTracksLoaded?.call(tracksListEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (playlistTracksLoaded != null) {
      return playlistTracksLoaded(tracksListEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return playlistTracksLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return playlistTracksLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (playlistTracksLoaded != null) {
      return playlistTracksLoaded(this);
    }
    return orElse();
  }
}

abstract class PlaylistTracksLoaded implements MusicState {
  const factory PlaylistTracksLoaded(
      PlaylistTracksListEntity tracksListEntity) = _$PlaylistTracksLoaded;

  PlaylistTracksListEntity get tracksListEntity;
  @JsonKey(ignore: true)
  $PlaylistTracksLoadedCopyWith<PlaylistTracksLoaded> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserPlaylistsLoadedCopyWith<$Res> {
  factory $UserPlaylistsLoadedCopyWith(
          UserPlaylistsLoaded value, $Res Function(UserPlaylistsLoaded) then) =
      _$UserPlaylistsLoadedCopyWithImpl<$Res>;
  $Res call({UserPlaylistsEntity playlistsEntity});
}

/// @nodoc
class _$UserPlaylistsLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $UserPlaylistsLoadedCopyWith<$Res> {
  _$UserPlaylistsLoadedCopyWithImpl(
      UserPlaylistsLoaded _value, $Res Function(UserPlaylistsLoaded) _then)
      : super(_value, (v) => _then(v as UserPlaylistsLoaded));

  @override
  UserPlaylistsLoaded get _value => super._value as UserPlaylistsLoaded;

  @override
  $Res call({
    Object? playlistsEntity = freezed,
  }) {
    return _then(UserPlaylistsLoaded(
      playlistsEntity == freezed
          ? _value.playlistsEntity
          : playlistsEntity // ignore: cast_nullable_to_non_nullable
              as UserPlaylistsEntity,
    ));
  }
}

/// @nodoc

class _$UserPlaylistsLoaded implements UserPlaylistsLoaded {
  const _$UserPlaylistsLoaded(this.playlistsEntity);

  @override
  final UserPlaylistsEntity playlistsEntity;

  @override
  String toString() {
    return 'MusicState.userPlaylistsLoaded(playlistsEntity: $playlistsEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is UserPlaylistsLoaded &&
            const DeepCollectionEquality()
                .equals(other.playlistsEntity, playlistsEntity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(playlistsEntity));

  @JsonKey(ignore: true)
  @override
  $UserPlaylistsLoadedCopyWith<UserPlaylistsLoaded> get copyWith =>
      _$UserPlaylistsLoadedCopyWithImpl<UserPlaylistsLoaded>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return userPlaylistsLoaded(playlistsEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return userPlaylistsLoaded?.call(playlistsEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (userPlaylistsLoaded != null) {
      return userPlaylistsLoaded(playlistsEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return userPlaylistsLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return userPlaylistsLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (userPlaylistsLoaded != null) {
      return userPlaylistsLoaded(this);
    }
    return orElse();
  }
}

abstract class UserPlaylistsLoaded implements MusicState {
  const factory UserPlaylistsLoaded(UserPlaylistsEntity playlistsEntity) =
      _$UserPlaylistsLoaded;

  UserPlaylistsEntity get playlistsEntity;
  @JsonKey(ignore: true)
  $UserPlaylistsLoadedCopyWith<UserPlaylistsLoaded> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserTopArtistsLoadedCopyWith<$Res> {
  factory $UserTopArtistsLoadedCopyWith(UserTopArtistsLoaded value,
          $Res Function(UserTopArtistsLoaded) then) =
      _$UserTopArtistsLoadedCopyWithImpl<$Res>;
  $Res call({ArtistsListEntity artistsEntity});
}

/// @nodoc
class _$UserTopArtistsLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $UserTopArtistsLoadedCopyWith<$Res> {
  _$UserTopArtistsLoadedCopyWithImpl(
      UserTopArtistsLoaded _value, $Res Function(UserTopArtistsLoaded) _then)
      : super(_value, (v) => _then(v as UserTopArtistsLoaded));

  @override
  UserTopArtistsLoaded get _value => super._value as UserTopArtistsLoaded;

  @override
  $Res call({
    Object? artistsEntity = freezed,
  }) {
    return _then(UserTopArtistsLoaded(
      artistsEntity == freezed
          ? _value.artistsEntity
          : artistsEntity // ignore: cast_nullable_to_non_nullable
              as ArtistsListEntity,
    ));
  }
}

/// @nodoc

class _$UserTopArtistsLoaded implements UserTopArtistsLoaded {
  const _$UserTopArtistsLoaded(this.artistsEntity);

  @override
  final ArtistsListEntity artistsEntity;

  @override
  String toString() {
    return 'MusicState.userTopArtistsLoaded(artistsEntity: $artistsEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is UserTopArtistsLoaded &&
            const DeepCollectionEquality()
                .equals(other.artistsEntity, artistsEntity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(artistsEntity));

  @JsonKey(ignore: true)
  @override
  $UserTopArtistsLoadedCopyWith<UserTopArtistsLoaded> get copyWith =>
      _$UserTopArtistsLoadedCopyWithImpl<UserTopArtistsLoaded>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return userTopArtistsLoaded(artistsEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return userTopArtistsLoaded?.call(artistsEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (userTopArtistsLoaded != null) {
      return userTopArtistsLoaded(artistsEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return userTopArtistsLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return userTopArtistsLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (userTopArtistsLoaded != null) {
      return userTopArtistsLoaded(this);
    }
    return orElse();
  }
}

abstract class UserTopArtistsLoaded implements MusicState {
  const factory UserTopArtistsLoaded(ArtistsListEntity artistsEntity) =
      _$UserTopArtistsLoaded;

  ArtistsListEntity get artistsEntity;
  @JsonKey(ignore: true)
  $UserTopArtistsLoadedCopyWith<UserTopArtistsLoaded> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserSavedTracksLoadedCopyWith<$Res> {
  factory $UserSavedTracksLoadedCopyWith(UserSavedTracksLoaded value,
          $Res Function(UserSavedTracksLoaded) then) =
      _$UserSavedTracksLoadedCopyWithImpl<$Res>;
  $Res call({SavedTracksEntity tracksEntity});
}

/// @nodoc
class _$UserSavedTracksLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $UserSavedTracksLoadedCopyWith<$Res> {
  _$UserSavedTracksLoadedCopyWithImpl(
      UserSavedTracksLoaded _value, $Res Function(UserSavedTracksLoaded) _then)
      : super(_value, (v) => _then(v as UserSavedTracksLoaded));

  @override
  UserSavedTracksLoaded get _value => super._value as UserSavedTracksLoaded;

  @override
  $Res call({
    Object? tracksEntity = freezed,
  }) {
    return _then(UserSavedTracksLoaded(
      tracksEntity == freezed
          ? _value.tracksEntity
          : tracksEntity // ignore: cast_nullable_to_non_nullable
              as SavedTracksEntity,
    ));
  }
}

/// @nodoc

class _$UserSavedTracksLoaded implements UserSavedTracksLoaded {
  const _$UserSavedTracksLoaded(this.tracksEntity);

  @override
  final SavedTracksEntity tracksEntity;

  @override
  String toString() {
    return 'MusicState.userSavedTracksLoaded(tracksEntity: $tracksEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is UserSavedTracksLoaded &&
            const DeepCollectionEquality()
                .equals(other.tracksEntity, tracksEntity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(tracksEntity));

  @JsonKey(ignore: true)
  @override
  $UserSavedTracksLoadedCopyWith<UserSavedTracksLoaded> get copyWith =>
      _$UserSavedTracksLoadedCopyWithImpl<UserSavedTracksLoaded>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return userSavedTracksLoaded(tracksEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return userSavedTracksLoaded?.call(tracksEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (userSavedTracksLoaded != null) {
      return userSavedTracksLoaded(tracksEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return userSavedTracksLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return userSavedTracksLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (userSavedTracksLoaded != null) {
      return userSavedTracksLoaded(this);
    }
    return orElse();
  }
}

abstract class UserSavedTracksLoaded implements MusicState {
  const factory UserSavedTracksLoaded(SavedTracksEntity tracksEntity) =
      _$UserSavedTracksLoaded;

  SavedTracksEntity get tracksEntity;
  @JsonKey(ignore: true)
  $UserSavedTracksLoadedCopyWith<UserSavedTracksLoaded> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CreatePlaylistLoadedCopyWith<$Res> {
  factory $CreatePlaylistLoadedCopyWith(CreatePlaylistLoaded value,
          $Res Function(CreatePlaylistLoaded) then) =
      _$CreatePlaylistLoadedCopyWithImpl<$Res>;
  $Res call({Playlist playlist});
}

/// @nodoc
class _$CreatePlaylistLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $CreatePlaylistLoadedCopyWith<$Res> {
  _$CreatePlaylistLoadedCopyWithImpl(
      CreatePlaylistLoaded _value, $Res Function(CreatePlaylistLoaded) _then)
      : super(_value, (v) => _then(v as CreatePlaylistLoaded));

  @override
  CreatePlaylistLoaded get _value => super._value as CreatePlaylistLoaded;

  @override
  $Res call({
    Object? playlist = freezed,
  }) {
    return _then(CreatePlaylistLoaded(
      playlist == freezed
          ? _value.playlist
          : playlist // ignore: cast_nullable_to_non_nullable
              as Playlist,
    ));
  }
}

/// @nodoc

class _$CreatePlaylistLoaded implements CreatePlaylistLoaded {
  const _$CreatePlaylistLoaded(this.playlist);

  @override
  final Playlist playlist;

  @override
  String toString() {
    return 'MusicState.createPlaylistLoaded(playlist: $playlist)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is CreatePlaylistLoaded &&
            const DeepCollectionEquality().equals(other.playlist, playlist));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(playlist));

  @JsonKey(ignore: true)
  @override
  $CreatePlaylistLoadedCopyWith<CreatePlaylistLoaded> get copyWith =>
      _$CreatePlaylistLoadedCopyWithImpl<CreatePlaylistLoaded>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return createPlaylistLoaded(playlist);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return createPlaylistLoaded?.call(playlist);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (createPlaylistLoaded != null) {
      return createPlaylistLoaded(playlist);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return createPlaylistLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return createPlaylistLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (createPlaylistLoaded != null) {
      return createPlaylistLoaded(this);
    }
    return orElse();
  }
}

abstract class CreatePlaylistLoaded implements MusicState {
  const factory CreatePlaylistLoaded(Playlist playlist) =
      _$CreatePlaylistLoaded;

  Playlist get playlist;
  @JsonKey(ignore: true)
  $CreatePlaylistLoadedCopyWith<CreatePlaylistLoaded> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AddTrackToPlaylistLoadedCopyWith<$Res> {
  factory $AddTrackToPlaylistLoadedCopyWith(AddTrackToPlaylistLoaded value,
          $Res Function(AddTrackToPlaylistLoaded) then) =
      _$AddTrackToPlaylistLoadedCopyWithImpl<$Res>;
}

/// @nodoc
class _$AddTrackToPlaylistLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $AddTrackToPlaylistLoadedCopyWith<$Res> {
  _$AddTrackToPlaylistLoadedCopyWithImpl(AddTrackToPlaylistLoaded _value,
      $Res Function(AddTrackToPlaylistLoaded) _then)
      : super(_value, (v) => _then(v as AddTrackToPlaylistLoaded));

  @override
  AddTrackToPlaylistLoaded get _value =>
      super._value as AddTrackToPlaylistLoaded;
}

/// @nodoc

class _$AddTrackToPlaylistLoaded implements AddTrackToPlaylistLoaded {
  const _$AddTrackToPlaylistLoaded();

  @override
  String toString() {
    return 'MusicState.addTrackToPlaylistLoaded()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is AddTrackToPlaylistLoaded);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return addTrackToPlaylistLoaded();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return addTrackToPlaylistLoaded?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (addTrackToPlaylistLoaded != null) {
      return addTrackToPlaylistLoaded();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return addTrackToPlaylistLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return addTrackToPlaylistLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (addTrackToPlaylistLoaded != null) {
      return addTrackToPlaylistLoaded(this);
    }
    return orElse();
  }
}

abstract class AddTrackToPlaylistLoaded implements MusicState {
  const factory AddTrackToPlaylistLoaded() = _$AddTrackToPlaylistLoaded;
}

/// @nodoc
abstract class $SearchTracksLoadedCopyWith<$Res> {
  factory $SearchTracksLoadedCopyWith(
          SearchTracksLoaded value, $Res Function(SearchTracksLoaded) then) =
      _$SearchTracksLoadedCopyWithImpl<$Res>;
  $Res call({List<Track> tracks});
}

/// @nodoc
class _$SearchTracksLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $SearchTracksLoadedCopyWith<$Res> {
  _$SearchTracksLoadedCopyWithImpl(
      SearchTracksLoaded _value, $Res Function(SearchTracksLoaded) _then)
      : super(_value, (v) => _then(v as SearchTracksLoaded));

  @override
  SearchTracksLoaded get _value => super._value as SearchTracksLoaded;

  @override
  $Res call({
    Object? tracks = freezed,
  }) {
    return _then(SearchTracksLoaded(
      tracks == freezed
          ? _value.tracks
          : tracks // ignore: cast_nullable_to_non_nullable
              as List<Track>,
    ));
  }
}

/// @nodoc

class _$SearchTracksLoaded implements SearchTracksLoaded {
  const _$SearchTracksLoaded(this.tracks);

  @override
  final List<Track> tracks;

  @override
  String toString() {
    return 'MusicState.searchTracksLoaded(tracks: $tracks)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is SearchTracksLoaded &&
            const DeepCollectionEquality().equals(other.tracks, tracks));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(tracks));

  @JsonKey(ignore: true)
  @override
  $SearchTracksLoadedCopyWith<SearchTracksLoaded> get copyWith =>
      _$SearchTracksLoadedCopyWithImpl<SearchTracksLoaded>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return searchTracksLoaded(tracks);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return searchTracksLoaded?.call(tracks);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (searchTracksLoaded != null) {
      return searchTracksLoaded(tracks);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return searchTracksLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return searchTracksLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (searchTracksLoaded != null) {
      return searchTracksLoaded(this);
    }
    return orElse();
  }
}

abstract class SearchTracksLoaded implements MusicState {
  const factory SearchTracksLoaded(List<Track> tracks) = _$SearchTracksLoaded;

  List<Track> get tracks;
  @JsonKey(ignore: true)
  $SearchTracksLoadedCopyWith<SearchTracksLoaded> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SearchAlbumsLoadedCopyWith<$Res> {
  factory $SearchAlbumsLoadedCopyWith(
          SearchAlbumsLoaded value, $Res Function(SearchAlbumsLoaded) then) =
      _$SearchAlbumsLoadedCopyWithImpl<$Res>;
  $Res call({List<AlbumSimple> albums});
}

/// @nodoc
class _$SearchAlbumsLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $SearchAlbumsLoadedCopyWith<$Res> {
  _$SearchAlbumsLoadedCopyWithImpl(
      SearchAlbumsLoaded _value, $Res Function(SearchAlbumsLoaded) _then)
      : super(_value, (v) => _then(v as SearchAlbumsLoaded));

  @override
  SearchAlbumsLoaded get _value => super._value as SearchAlbumsLoaded;

  @override
  $Res call({
    Object? albums = freezed,
  }) {
    return _then(SearchAlbumsLoaded(
      albums == freezed
          ? _value.albums
          : albums // ignore: cast_nullable_to_non_nullable
              as List<AlbumSimple>,
    ));
  }
}

/// @nodoc

class _$SearchAlbumsLoaded implements SearchAlbumsLoaded {
  const _$SearchAlbumsLoaded(this.albums);

  @override
  final List<AlbumSimple> albums;

  @override
  String toString() {
    return 'MusicState.searchAlbumsLoaded(albums: $albums)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is SearchAlbumsLoaded &&
            const DeepCollectionEquality().equals(other.albums, albums));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(albums));

  @JsonKey(ignore: true)
  @override
  $SearchAlbumsLoadedCopyWith<SearchAlbumsLoaded> get copyWith =>
      _$SearchAlbumsLoadedCopyWithImpl<SearchAlbumsLoaded>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return searchAlbumsLoaded(albums);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return searchAlbumsLoaded?.call(albums);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (searchAlbumsLoaded != null) {
      return searchAlbumsLoaded(albums);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return searchAlbumsLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return searchAlbumsLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (searchAlbumsLoaded != null) {
      return searchAlbumsLoaded(this);
    }
    return orElse();
  }
}

abstract class SearchAlbumsLoaded implements MusicState {
  const factory SearchAlbumsLoaded(List<AlbumSimple> albums) =
      _$SearchAlbumsLoaded;

  List<AlbumSimple> get albums;
  @JsonKey(ignore: true)
  $SearchAlbumsLoadedCopyWith<SearchAlbumsLoaded> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RecentlyPlayedTracksLoadedCopyWith<$Res> {
  factory $RecentlyPlayedTracksLoadedCopyWith(RecentlyPlayedTracksLoaded value,
          $Res Function(RecentlyPlayedTracksLoaded) then) =
      _$RecentlyPlayedTracksLoadedCopyWithImpl<$Res>;
  $Res call({dynamic RecentlyPlayedTracksListEntity});
}

/// @nodoc
class _$RecentlyPlayedTracksLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $RecentlyPlayedTracksLoadedCopyWith<$Res> {
  _$RecentlyPlayedTracksLoadedCopyWithImpl(RecentlyPlayedTracksLoaded _value,
      $Res Function(RecentlyPlayedTracksLoaded) _then)
      : super(_value, (v) => _then(v as RecentlyPlayedTracksLoaded));

  @override
  RecentlyPlayedTracksLoaded get _value =>
      super._value as RecentlyPlayedTracksLoaded;

  @override
  $Res call({
    Object? RecentlyPlayedTracksListEntity = freezed,
  }) {
    return _then(RecentlyPlayedTracksLoaded(
      RecentlyPlayedTracksListEntity == freezed
          ? _value.RecentlyPlayedTracksListEntity
          : RecentlyPlayedTracksListEntity,
    ));
  }
}

/// @nodoc

class _$RecentlyPlayedTracksLoaded implements RecentlyPlayedTracksLoaded {
  const _$RecentlyPlayedTracksLoaded(this.RecentlyPlayedTracksListEntity);

  @override
  final dynamic RecentlyPlayedTracksListEntity;

  @override
  String toString() {
    return 'MusicState.recentlyPlayedTracksLoaded(RecentlyPlayedTracksListEntity: $RecentlyPlayedTracksListEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is RecentlyPlayedTracksLoaded &&
            const DeepCollectionEquality().equals(
                other.RecentlyPlayedTracksListEntity,
                RecentlyPlayedTracksListEntity));
  }

  @override
  int get hashCode => Object.hash(runtimeType,
      const DeepCollectionEquality().hash(RecentlyPlayedTracksListEntity));

  @JsonKey(ignore: true)
  @override
  $RecentlyPlayedTracksLoadedCopyWith<RecentlyPlayedTracksLoaded>
      get copyWith =>
          _$RecentlyPlayedTracksLoadedCopyWithImpl<RecentlyPlayedTracksLoaded>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return recentlyPlayedTracksLoaded(RecentlyPlayedTracksListEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return recentlyPlayedTracksLoaded?.call(RecentlyPlayedTracksListEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (recentlyPlayedTracksLoaded != null) {
      return recentlyPlayedTracksLoaded(RecentlyPlayedTracksListEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return recentlyPlayedTracksLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return recentlyPlayedTracksLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (recentlyPlayedTracksLoaded != null) {
      return recentlyPlayedTracksLoaded(this);
    }
    return orElse();
  }
}

abstract class RecentlyPlayedTracksLoaded implements MusicState {
  const factory RecentlyPlayedTracksLoaded(
      dynamic RecentlyPlayedTracksListEntity) = _$RecentlyPlayedTracksLoaded;

  dynamic get RecentlyPlayedTracksListEntity;
  @JsonKey(ignore: true)
  $RecentlyPlayedTracksLoadedCopyWith<RecentlyPlayedTracksLoaded>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UpdatePlaylistImageLoadedCopyWith<$Res> {
  factory $UpdatePlaylistImageLoadedCopyWith(UpdatePlaylistImageLoaded value,
          $Res Function(UpdatePlaylistImageLoaded) then) =
      _$UpdatePlaylistImageLoadedCopyWithImpl<$Res>;
}

/// @nodoc
class _$UpdatePlaylistImageLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $UpdatePlaylistImageLoadedCopyWith<$Res> {
  _$UpdatePlaylistImageLoadedCopyWithImpl(UpdatePlaylistImageLoaded _value,
      $Res Function(UpdatePlaylistImageLoaded) _then)
      : super(_value, (v) => _then(v as UpdatePlaylistImageLoaded));

  @override
  UpdatePlaylistImageLoaded get _value =>
      super._value as UpdatePlaylistImageLoaded;
}

/// @nodoc

class _$UpdatePlaylistImageLoaded implements UpdatePlaylistImageLoaded {
  const _$UpdatePlaylistImageLoaded();

  @override
  String toString() {
    return 'MusicState.updatePlaylistImageLoaded()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is UpdatePlaylistImageLoaded);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return updatePlaylistImageLoaded();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return updatePlaylistImageLoaded?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (updatePlaylistImageLoaded != null) {
      return updatePlaylistImageLoaded();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return updatePlaylistImageLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return updatePlaylistImageLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (updatePlaylistImageLoaded != null) {
      return updatePlaylistImageLoaded(this);
    }
    return orElse();
  }
}

abstract class UpdatePlaylistImageLoaded implements MusicState {
  const factory UpdatePlaylistImageLoaded() = _$UpdatePlaylistImageLoaded;
}

/// @nodoc
abstract class $UpdatePlaylistInfoLoadedCopyWith<$Res> {
  factory $UpdatePlaylistInfoLoadedCopyWith(UpdatePlaylistInfoLoaded value,
          $Res Function(UpdatePlaylistInfoLoaded) then) =
      _$UpdatePlaylistInfoLoadedCopyWithImpl<$Res>;
}

/// @nodoc
class _$UpdatePlaylistInfoLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $UpdatePlaylistInfoLoadedCopyWith<$Res> {
  _$UpdatePlaylistInfoLoadedCopyWithImpl(UpdatePlaylistInfoLoaded _value,
      $Res Function(UpdatePlaylistInfoLoaded) _then)
      : super(_value, (v) => _then(v as UpdatePlaylistInfoLoaded));

  @override
  UpdatePlaylistInfoLoaded get _value =>
      super._value as UpdatePlaylistInfoLoaded;
}

/// @nodoc

class _$UpdatePlaylistInfoLoaded implements UpdatePlaylistInfoLoaded {
  const _$UpdatePlaylistInfoLoaded();

  @override
  String toString() {
    return 'MusicState.updatePlaylistInfoLoaded()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is UpdatePlaylistInfoLoaded);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return updatePlaylistInfoLoaded();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return updatePlaylistInfoLoaded?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (updatePlaylistInfoLoaded != null) {
      return updatePlaylistInfoLoaded();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return updatePlaylistInfoLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return updatePlaylistInfoLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (updatePlaylistInfoLoaded != null) {
      return updatePlaylistInfoLoaded(this);
    }
    return orElse();
  }
}

abstract class UpdatePlaylistInfoLoaded implements MusicState {
  const factory UpdatePlaylistInfoLoaded() = _$UpdatePlaylistInfoLoaded;
}

/// @nodoc
abstract class $GetSavedAlbumsLoadedCopyWith<$Res> {
  factory $GetSavedAlbumsLoadedCopyWith(GetSavedAlbumsLoaded value,
          $Res Function(GetSavedAlbumsLoaded) then) =
      _$GetSavedAlbumsLoadedCopyWithImpl<$Res>;
  $Res call({SavedAlbumsListEntity savedAlbumsListEntity});
}

/// @nodoc
class _$GetSavedAlbumsLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $GetSavedAlbumsLoadedCopyWith<$Res> {
  _$GetSavedAlbumsLoadedCopyWithImpl(
      GetSavedAlbumsLoaded _value, $Res Function(GetSavedAlbumsLoaded) _then)
      : super(_value, (v) => _then(v as GetSavedAlbumsLoaded));

  @override
  GetSavedAlbumsLoaded get _value => super._value as GetSavedAlbumsLoaded;

  @override
  $Res call({
    Object? savedAlbumsListEntity = freezed,
  }) {
    return _then(GetSavedAlbumsLoaded(
      savedAlbumsListEntity == freezed
          ? _value.savedAlbumsListEntity
          : savedAlbumsListEntity // ignore: cast_nullable_to_non_nullable
              as SavedAlbumsListEntity,
    ));
  }
}

/// @nodoc

class _$GetSavedAlbumsLoaded implements GetSavedAlbumsLoaded {
  const _$GetSavedAlbumsLoaded(this.savedAlbumsListEntity);

  @override
  final SavedAlbumsListEntity savedAlbumsListEntity;

  @override
  String toString() {
    return 'MusicState.getSavedAlbumsLoaded(savedAlbumsListEntity: $savedAlbumsListEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is GetSavedAlbumsLoaded &&
            const DeepCollectionEquality()
                .equals(other.savedAlbumsListEntity, savedAlbumsListEntity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(savedAlbumsListEntity));

  @JsonKey(ignore: true)
  @override
  $GetSavedAlbumsLoadedCopyWith<GetSavedAlbumsLoaded> get copyWith =>
      _$GetSavedAlbumsLoadedCopyWithImpl<GetSavedAlbumsLoaded>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return getSavedAlbumsLoaded(savedAlbumsListEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return getSavedAlbumsLoaded?.call(savedAlbumsListEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (getSavedAlbumsLoaded != null) {
      return getSavedAlbumsLoaded(savedAlbumsListEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return getSavedAlbumsLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return getSavedAlbumsLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (getSavedAlbumsLoaded != null) {
      return getSavedAlbumsLoaded(this);
    }
    return orElse();
  }
}

abstract class GetSavedAlbumsLoaded implements MusicState {
  const factory GetSavedAlbumsLoaded(
      SavedAlbumsListEntity savedAlbumsListEntity) = _$GetSavedAlbumsLoaded;

  SavedAlbumsListEntity get savedAlbumsListEntity;
  @JsonKey(ignore: true)
  $GetSavedAlbumsLoadedCopyWith<GetSavedAlbumsLoaded> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SearchItemsLoadedCopyWith<$Res> {
  factory $SearchItemsLoadedCopyWith(
          SearchItemsLoaded value, $Res Function(SearchItemsLoaded) then) =
      _$SearchItemsLoadedCopyWithImpl<$Res>;
  $Res call({SpotifySearchResult result});
}

/// @nodoc
class _$SearchItemsLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $SearchItemsLoadedCopyWith<$Res> {
  _$SearchItemsLoadedCopyWithImpl(
      SearchItemsLoaded _value, $Res Function(SearchItemsLoaded) _then)
      : super(_value, (v) => _then(v as SearchItemsLoaded));

  @override
  SearchItemsLoaded get _value => super._value as SearchItemsLoaded;

  @override
  $Res call({
    Object? result = freezed,
  }) {
    return _then(SearchItemsLoaded(
      result == freezed
          ? _value.result
          : result // ignore: cast_nullable_to_non_nullable
              as SpotifySearchResult,
    ));
  }
}

/// @nodoc

class _$SearchItemsLoaded implements SearchItemsLoaded {
  const _$SearchItemsLoaded(this.result);

  @override
  final SpotifySearchResult result;

  @override
  String toString() {
    return 'MusicState.searchItemsLoaded(result: $result)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is SearchItemsLoaded &&
            const DeepCollectionEquality().equals(other.result, result));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(result));

  @JsonKey(ignore: true)
  @override
  $SearchItemsLoadedCopyWith<SearchItemsLoaded> get copyWith =>
      _$SearchItemsLoadedCopyWithImpl<SearchItemsLoaded>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return searchItemsLoaded(result);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return searchItemsLoaded?.call(result);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (searchItemsLoaded != null) {
      return searchItemsLoaded(result);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return searchItemsLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return searchItemsLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (searchItemsLoaded != null) {
      return searchItemsLoaded(this);
    }
    return orElse();
  }
}

abstract class SearchItemsLoaded implements MusicState {
  const factory SearchItemsLoaded(SpotifySearchResult result) =
      _$SearchItemsLoaded;

  SpotifySearchResult get result;
  @JsonKey(ignore: true)
  $SearchItemsLoadedCopyWith<SearchItemsLoaded> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetAlbumTracksLoadedCopyWith<$Res> {
  factory $GetAlbumTracksLoadedCopyWith(GetAlbumTracksLoaded value,
          $Res Function(GetAlbumTracksLoaded) then) =
      _$GetAlbumTracksLoadedCopyWithImpl<$Res>;
  $Res call({List<TrackSimple> tracks});
}

/// @nodoc
class _$GetAlbumTracksLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $GetAlbumTracksLoadedCopyWith<$Res> {
  _$GetAlbumTracksLoadedCopyWithImpl(
      GetAlbumTracksLoaded _value, $Res Function(GetAlbumTracksLoaded) _then)
      : super(_value, (v) => _then(v as GetAlbumTracksLoaded));

  @override
  GetAlbumTracksLoaded get _value => super._value as GetAlbumTracksLoaded;

  @override
  $Res call({
    Object? tracks = freezed,
  }) {
    return _then(GetAlbumTracksLoaded(
      tracks == freezed
          ? _value.tracks
          : tracks // ignore: cast_nullable_to_non_nullable
              as List<TrackSimple>,
    ));
  }
}

/// @nodoc

class _$GetAlbumTracksLoaded implements GetAlbumTracksLoaded {
  const _$GetAlbumTracksLoaded(this.tracks);

  @override
  final List<TrackSimple> tracks;

  @override
  String toString() {
    return 'MusicState.getAlbumTracksLoaded(tracks: $tracks)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is GetAlbumTracksLoaded &&
            const DeepCollectionEquality().equals(other.tracks, tracks));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(tracks));

  @JsonKey(ignore: true)
  @override
  $GetAlbumTracksLoadedCopyWith<GetAlbumTracksLoaded> get copyWith =>
      _$GetAlbumTracksLoadedCopyWithImpl<GetAlbumTracksLoaded>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return getAlbumTracksLoaded(tracks);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return getAlbumTracksLoaded?.call(tracks);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (getAlbumTracksLoaded != null) {
      return getAlbumTracksLoaded(tracks);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return getAlbumTracksLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return getAlbumTracksLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (getAlbumTracksLoaded != null) {
      return getAlbumTracksLoaded(this);
    }
    return orElse();
  }
}

abstract class GetAlbumTracksLoaded implements MusicState {
  const factory GetAlbumTracksLoaded(List<TrackSimple> tracks) =
      _$GetAlbumTracksLoaded;

  List<TrackSimple> get tracks;
  @JsonKey(ignore: true)
  $GetAlbumTracksLoadedCopyWith<GetAlbumTracksLoaded> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetArtistAlbumsLoadedCopyWith<$Res> {
  factory $GetArtistAlbumsLoadedCopyWith(GetArtistAlbumsLoaded value,
          $Res Function(GetArtistAlbumsLoaded) then) =
      _$GetArtistAlbumsLoadedCopyWithImpl<$Res>;
  $Res call({List<Album> albums});
}

/// @nodoc
class _$GetArtistAlbumsLoadedCopyWithImpl<$Res>
    extends _$MusicStateCopyWithImpl<$Res>
    implements $GetArtistAlbumsLoadedCopyWith<$Res> {
  _$GetArtistAlbumsLoadedCopyWithImpl(
      GetArtistAlbumsLoaded _value, $Res Function(GetArtistAlbumsLoaded) _then)
      : super(_value, (v) => _then(v as GetArtistAlbumsLoaded));

  @override
  GetArtistAlbumsLoaded get _value => super._value as GetArtistAlbumsLoaded;

  @override
  $Res call({
    Object? albums = freezed,
  }) {
    return _then(GetArtistAlbumsLoaded(
      albums == freezed
          ? _value.albums
          : albums // ignore: cast_nullable_to_non_nullable
              as List<Album>,
    ));
  }
}

/// @nodoc

class _$GetArtistAlbumsLoaded implements GetArtistAlbumsLoaded {
  const _$GetArtistAlbumsLoaded(this.albums);

  @override
  final List<Album> albums;

  @override
  String toString() {
    return 'MusicState.getArtistAlbumsLoaded(albums: $albums)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is GetArtistAlbumsLoaded &&
            const DeepCollectionEquality().equals(other.albums, albums));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(albums));

  @JsonKey(ignore: true)
  @override
  $GetArtistAlbumsLoadedCopyWith<GetArtistAlbumsLoaded> get copyWith =>
      _$GetArtistAlbumsLoadedCopyWithImpl<GetArtistAlbumsLoaded>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return getArtistAlbumsLoaded(albums);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return getArtistAlbumsLoaded?.call(albums);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (getArtistAlbumsLoaded != null) {
      return getArtistAlbumsLoaded(albums);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return getArtistAlbumsLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return getArtistAlbumsLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (getArtistAlbumsLoaded != null) {
      return getArtistAlbumsLoaded(this);
    }
    return orElse();
  }
}

abstract class GetArtistAlbumsLoaded implements MusicState {
  const factory GetArtistAlbumsLoaded(List<Album> albums) =
      _$GetArtistAlbumsLoaded;

  List<Album> get albums;
  @JsonKey(ignore: true)
  $GetArtistAlbumsLoadedCopyWith<GetArtistAlbumsLoaded> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MusicErrorStateCopyWith<$Res> {
  factory $MusicErrorStateCopyWith(
          MusicErrorState value, $Res Function(MusicErrorState) then) =
      _$MusicErrorStateCopyWithImpl<$Res>;
  $Res call({AppErrors error, VoidCallback callback});

  $AppErrorsCopyWith<$Res> get error;
}

/// @nodoc
class _$MusicErrorStateCopyWithImpl<$Res> extends _$MusicStateCopyWithImpl<$Res>
    implements $MusicErrorStateCopyWith<$Res> {
  _$MusicErrorStateCopyWithImpl(
      MusicErrorState _value, $Res Function(MusicErrorState) _then)
      : super(_value, (v) => _then(v as MusicErrorState));

  @override
  MusicErrorState get _value => super._value as MusicErrorState;

  @override
  $Res call({
    Object? error = freezed,
    Object? callback = freezed,
  }) {
    return _then(MusicErrorState(
      error == freezed
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as AppErrors,
      callback == freezed
          ? _value.callback
          : callback // ignore: cast_nullable_to_non_nullable
              as VoidCallback,
    ));
  }

  @override
  $AppErrorsCopyWith<$Res> get error {
    return $AppErrorsCopyWith<$Res>(_value.error, (value) {
      return _then(_value.copyWith(error: value));
    });
  }
}

/// @nodoc

class _$MusicErrorState implements MusicErrorState {
  const _$MusicErrorState(this.error, this.callback);

  @override
  final AppErrors error;
  @override
  final VoidCallback callback;

  @override
  String toString() {
    return 'MusicState.musicErrorState(error: $error, callback: $callback)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is MusicErrorState &&
            const DeepCollectionEquality().equals(other.error, error) &&
            (identical(other.callback, callback) ||
                other.callback == callback));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(error), callback);

  @JsonKey(ignore: true)
  @override
  $MusicErrorStateCopyWith<MusicErrorState> get copyWith =>
      _$MusicErrorStateCopyWithImpl<MusicErrorState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() musicInitState,
    required TResult Function() musicLoadingState,
    required TResult Function(MusicHomeEntity musicHomeEntity) musicHomeLoaded,
    required TResult Function(PlaylistTracksListEntity tracksListEntity)
        playlistTracksLoaded,
    required TResult Function(UserPlaylistsEntity playlistsEntity)
        userPlaylistsLoaded,
    required TResult Function(ArtistsListEntity artistsEntity)
        userTopArtistsLoaded,
    required TResult Function(SavedTracksEntity tracksEntity)
        userSavedTracksLoaded,
    required TResult Function(Playlist playlist) createPlaylistLoaded,
    required TResult Function() addTrackToPlaylistLoaded,
    required TResult Function(List<Track> tracks) searchTracksLoaded,
    required TResult Function(List<AlbumSimple> albums) searchAlbumsLoaded,
    required TResult Function(dynamic RecentlyPlayedTracksListEntity)
        recentlyPlayedTracksLoaded,
    required TResult Function() updatePlaylistImageLoaded,
    required TResult Function() updatePlaylistInfoLoaded,
    required TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)
        getSavedAlbumsLoaded,
    required TResult Function(SpotifySearchResult result) searchItemsLoaded,
    required TResult Function(List<TrackSimple> tracks) getAlbumTracksLoaded,
    required TResult Function(List<Album> albums) getArtistAlbumsLoaded,
    required TResult Function(AppErrors error, VoidCallback callback)
        musicErrorState,
  }) {
    return musicErrorState(error, callback);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
  }) {
    return musicErrorState?.call(error, callback);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? musicInitState,
    TResult Function()? musicLoadingState,
    TResult Function(MusicHomeEntity musicHomeEntity)? musicHomeLoaded,
    TResult Function(PlaylistTracksListEntity tracksListEntity)?
        playlistTracksLoaded,
    TResult Function(UserPlaylistsEntity playlistsEntity)? userPlaylistsLoaded,
    TResult Function(ArtistsListEntity artistsEntity)? userTopArtistsLoaded,
    TResult Function(SavedTracksEntity tracksEntity)? userSavedTracksLoaded,
    TResult Function(Playlist playlist)? createPlaylistLoaded,
    TResult Function()? addTrackToPlaylistLoaded,
    TResult Function(List<Track> tracks)? searchTracksLoaded,
    TResult Function(List<AlbumSimple> albums)? searchAlbumsLoaded,
    TResult Function(dynamic RecentlyPlayedTracksListEntity)?
        recentlyPlayedTracksLoaded,
    TResult Function()? updatePlaylistImageLoaded,
    TResult Function()? updatePlaylistInfoLoaded,
    TResult Function(SavedAlbumsListEntity savedAlbumsListEntity)?
        getSavedAlbumsLoaded,
    TResult Function(SpotifySearchResult result)? searchItemsLoaded,
    TResult Function(List<TrackSimple> tracks)? getAlbumTracksLoaded,
    TResult Function(List<Album> albums)? getArtistAlbumsLoaded,
    TResult Function(AppErrors error, VoidCallback callback)? musicErrorState,
    required TResult orElse(),
  }) {
    if (musicErrorState != null) {
      return musicErrorState(error, callback);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MusicInitState value) musicInitState,
    required TResult Function(MusicLoadingState value) musicLoadingState,
    required TResult Function(MusicHomeLoaded value) musicHomeLoaded,
    required TResult Function(PlaylistTracksLoaded value) playlistTracksLoaded,
    required TResult Function(UserPlaylistsLoaded value) userPlaylistsLoaded,
    required TResult Function(UserTopArtistsLoaded value) userTopArtistsLoaded,
    required TResult Function(UserSavedTracksLoaded value)
        userSavedTracksLoaded,
    required TResult Function(CreatePlaylistLoaded value) createPlaylistLoaded,
    required TResult Function(AddTrackToPlaylistLoaded value)
        addTrackToPlaylistLoaded,
    required TResult Function(SearchTracksLoaded value) searchTracksLoaded,
    required TResult Function(SearchAlbumsLoaded value) searchAlbumsLoaded,
    required TResult Function(RecentlyPlayedTracksLoaded value)
        recentlyPlayedTracksLoaded,
    required TResult Function(UpdatePlaylistImageLoaded value)
        updatePlaylistImageLoaded,
    required TResult Function(UpdatePlaylistInfoLoaded value)
        updatePlaylistInfoLoaded,
    required TResult Function(GetSavedAlbumsLoaded value) getSavedAlbumsLoaded,
    required TResult Function(SearchItemsLoaded value) searchItemsLoaded,
    required TResult Function(GetAlbumTracksLoaded value) getAlbumTracksLoaded,
    required TResult Function(GetArtistAlbumsLoaded value)
        getArtistAlbumsLoaded,
    required TResult Function(MusicErrorState value) musicErrorState,
  }) {
    return musicErrorState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
  }) {
    return musicErrorState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MusicInitState value)? musicInitState,
    TResult Function(MusicLoadingState value)? musicLoadingState,
    TResult Function(MusicHomeLoaded value)? musicHomeLoaded,
    TResult Function(PlaylistTracksLoaded value)? playlistTracksLoaded,
    TResult Function(UserPlaylistsLoaded value)? userPlaylistsLoaded,
    TResult Function(UserTopArtistsLoaded value)? userTopArtistsLoaded,
    TResult Function(UserSavedTracksLoaded value)? userSavedTracksLoaded,
    TResult Function(CreatePlaylistLoaded value)? createPlaylistLoaded,
    TResult Function(AddTrackToPlaylistLoaded value)? addTrackToPlaylistLoaded,
    TResult Function(SearchTracksLoaded value)? searchTracksLoaded,
    TResult Function(SearchAlbumsLoaded value)? searchAlbumsLoaded,
    TResult Function(RecentlyPlayedTracksLoaded value)?
        recentlyPlayedTracksLoaded,
    TResult Function(UpdatePlaylistImageLoaded value)?
        updatePlaylistImageLoaded,
    TResult Function(UpdatePlaylistInfoLoaded value)? updatePlaylistInfoLoaded,
    TResult Function(GetSavedAlbumsLoaded value)? getSavedAlbumsLoaded,
    TResult Function(SearchItemsLoaded value)? searchItemsLoaded,
    TResult Function(GetAlbumTracksLoaded value)? getAlbumTracksLoaded,
    TResult Function(GetArtistAlbumsLoaded value)? getArtistAlbumsLoaded,
    TResult Function(MusicErrorState value)? musicErrorState,
    required TResult orElse(),
  }) {
    if (musicErrorState != null) {
      return musicErrorState(this);
    }
    return orElse();
  }
}

abstract class MusicErrorState implements MusicState {
  const factory MusicErrorState(AppErrors error, VoidCallback callback) =
      _$MusicErrorState;

  AppErrors get error;
  VoidCallback get callback;
  @JsonKey(ignore: true)
  $MusicErrorStateCopyWith<MusicErrorState> get copyWith =>
      throw _privateConstructorUsedError;
}
