import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/ui/mansour/custom_list_tile.dart';

class MusicCard2 extends StatelessWidget {
  final String? leadingImage;
  final String? leadingIcon;
  final String? trailingIcon;
  final Widget? trailingWidget;
  final Color? trailingIconColor;
  final String title;
  final String? subtitle;
  final VoidCallback? onItemTap;
  final VoidCallback? onTrailingTap;

  const MusicCard2({
    Key? key,
    required this.title,
    this.leadingImage,
    this.leadingIcon,
    this.trailingIcon,
    this.trailingIconColor,
    this.subtitle,
    this.onItemTap,
    this.onTrailingTap,
    this.trailingWidget,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomListTile(
      leadingFlex: 2,
      trailingFlex: 1,
      onTap: onItemTap,
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(
          20.r,
        ),
        child: Container(
            height: 170.h,
            width: 170.h,
            decoration: BoxDecoration(
              color: AppColors.primaryColorLight,
              image: leadingImage != null
                  ? DecorationImage(
                      image: NetworkImage(leadingImage!), fit: BoxFit.cover)
                  : null,
            ),
            child: leadingIcon != null
                ? Center(
                    child: SizedBox(
                      height: 70.h,
                      width: 70.h,
                      child: SvgPicture.asset(
                        leadingIcon!,
                        color: Colors.white,
                      ),
                    ),
                  )
                : null),
      ),
      title: Padding(
        padding: EdgeInsetsDirectional.only(
          bottom: subtitle == null ? 0 : 20.h,
          start: 10.w,
        ),
        child: Text(
          title,
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 45.sp,
          ),
        ),
      ),
      subtitle: subtitle == null
          ? null
          : Padding(
              padding: EdgeInsetsDirectional.only(
                start: 10.w,
              ),
              child: Text(
                subtitle!,
                style: TextStyle(
                  color: AppColors.accentColorLight,
                  fontSize: 35.sp,
                ),
              ),
            ),
      trailing: trailingWidget != null
          ? trailingWidget!
          : trailingIcon == null
              ? null
              : InkWell(
                  onTap: onTrailingTap,
                  child: SizedBox(
                    height: 60.h,
                    width: 60.h,
                    child: SvgPicture.asset(
                      trailingIcon!,
                      color: trailingIconColor ?? AppColors.primaryColorLight,
                    ),
                  ),
                ),
    );
  }
}
