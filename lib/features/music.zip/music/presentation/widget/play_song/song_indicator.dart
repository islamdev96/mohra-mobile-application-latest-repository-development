import 'dart:math';
import 'dart:typed_data';

import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/common/utils.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';

enum SongIndicatorType { Linear, Circular }

class SongIndicator extends StatelessWidget {
  final double height;
  final SongIndicatorType type;
  final Uint8List? image;
  final int durationInSeconds;
  final int maxValueInMs;
  final int currentValueInMs;
  final Function(Duration newDuration) onSeek;
  const SongIndicator({
    Key? key,
    required this.height,
    required this.maxValueInMs,
    required this.currentValueInMs,
    required this.onSeek,
    this.durationInSeconds = 1,
    this.type = SongIndicatorType.Linear,
    this.image,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (type == SongIndicatorType.Circular) return buildCircularIndicator();
    if (type == SongIndicatorType.Linear) return buildLinearIndicator();
    return buildLinearIndicator();
  }

  CircularPercentIndicator buildCircularIndicator() {
    return CircularPercentIndicator(
      radius: height,
      lineWidth: 15.w,
      backgroundWidth: 5.w,
      percent: min(currentValueInMs / maxValueInMs, 1),
      animationDuration: 1000 * durationInSeconds,
      backgroundColor: AppColors.mansourLightGreyColor_12,
      progressColor: AppColors.primaryColorLight,
      circularStrokeCap: CircularStrokeCap.round,
      animateFromLastPercent: true,
      widgetIndicator: Center(
        child: Container(
          height: 45.h,
          width: 45.h,
          decoration: const BoxDecoration(
            color: AppColors.primaryColorLight,
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Container(
              height: 20.h,
              width: 20.h,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
            ),
          ),
        ),
      ),
      animation: true,
      center: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          image: image == null
              ? null
              : DecorationImage(
                  image: MemoryImage(
                    image!,
                  ),
                  fit: BoxFit.cover),
          boxShadow: [
            BoxShadow(
              color: AppColors.primaryColorLight.withOpacity(0.2),
              spreadRadius: 0.r,
              blurRadius: 70.r,
              offset: Offset(
                0.r,
                70.r,
              ),
            ),
          ],
        ),
        child: const FractionallySizedBox(
          heightFactor: 0.8,
          widthFactor: 0.8,
        ),
      ),
    );
  }

  Widget buildLinearIndicator() {
    return SizedBox(
      height: height,
      width: 1.sw - AppConstants.hPadding * 2,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "",
            style: TextStyle(
              fontSize: 40.sp,
              color: AppColors.accentColorLight,
            ),
          ),
          ProgressBar(
            progress:
                Duration(milliseconds: min(currentValueInMs, maxValueInMs)),
            // buffered: const Duration(milliseconds: 2000),
            total: Duration(milliseconds: maxValueInMs),
            barHeight: 0.1 * height,
            thumbRadius: 20.r,
            thumbColor: AppColors.primaryColorLight,
            thumbGlowColor: AppColors.primaryColorLight.withOpacity(
              0.4,
            ),
            baseBarColor: AppColors.mansourLightGreyColor_12,
            progressBarColor: AppColors.primaryColorLight,
            thumbGlowRadius: 50.r,
            thumbCanPaintOutsideBar: true,
            onSeek: (duration) {
              onSeek.call(duration);
            },
            timeLabelTextStyle: TextStyle(
              fontSize: 0.sp,
              color: AppColors.accentColorLight,
            ),
            timeLabelPadding: 0,
            timeLabelLocation: TimeLabelLocation.none,
          ),
          // LinearPercentIndicator(
          //   lineHeight: 0.1 * height,
          //   width: 1.sw - AppConstants.hPadding * 2,
          //   padding: EdgeInsets.zero,
          //   percent: currentValueInMs / maxValueInMs,
          //   animationDuration: 1000 * durationInSeconds,
          //   backgroundColor: AppColors.mansourLightGreyColor_12,
          //   progressColor: AppColors.primaryColorLight,
          //   animation: true,
          //   animateFromLastPercent: true,
          //   restartAnimation: false,
          // ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                formattedDuration(
                  Duration(milliseconds: currentValueInMs),
                ),
                style: TextStyle(
                  fontSize: 40.sp,
                  color: AppColors.accentColorLight,
                ),
              ),
              Text(
                formattedDuration(
                  Duration(milliseconds: maxValueInMs),
                ),
                style: TextStyle(
                  fontSize: 40.sp,
                  color: AppColors.accentColorLight,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
