import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/common/style/gaps.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/features/music/presentation/screen/play_song_screen.dart';

class MusicCard1 extends StatelessWidget {
  late final double height;
  late final double width;
  final String title;
  final String? subtitle;
  final double? imageHeight;
  final double? imageWidth;
  final String? image;
  final VoidCallback? onTap;
  MusicCard1(
      {Key? key,
      required this.title,
      double? height,
      double? width,
      this.imageHeight,
      this.imageWidth,
      this.subtitle,
      this.image,
      this.onTap,
      })
      : super(key: key) {
    this.height = height ?? 450.h;
    this.width = width ?? 0.75 * this.height;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            height: imageHeight ?? width,
            width: imageWidth ?? width,
            decoration: BoxDecoration(
              color: AppColors.accentColorLight,
              borderRadius: BorderRadius.circular(
                20.r,
              ),
              image: image == null
                  ? null
                  : DecorationImage(
                      image: NetworkImage(
                        image!,
                      ),
                      fit: BoxFit.cover),
            ),
            child: InkWell(
              onTap: onTap,
            ),
          ),
          SizedBox(
            width: width,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 38.sp,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                if (subtitle != null) Gaps.vGap12,
                if (subtitle != null)
                  Text(
                    subtitle!,
                    style: TextStyle(
                      color: AppColors.mansourLightGreyColor_11,
                      fontWeight: FontWeight.bold,
                      fontSize: 38.sp,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
