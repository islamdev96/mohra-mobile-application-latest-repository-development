import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:starter_application/core/common/app_config.dart';
import 'package:starter_application/core/common/style/gaps.dart';
import 'package:starter_application/core/common/utils.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/ui/error_ui/errors_screens/error_widget.dart';
import 'package:starter_application/core/ui/widgets/waiting_widget.dart';
import 'package:starter_application/features/music/presentation/state_m/cubit/music_cubit.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';

import 'music_card1.dart';

class HomePlaylistTracks extends StatefulWidget {
  final String playlistId;
  final Function(String id, int index) onTap;
  const HomePlaylistTracks({
    Key? key,
    required this.playlistId,
    required this.onTap,
  }) : super(key: key);

  @override
  State<HomePlaylistTracks> createState() => _HomePlaylistTracksState();
}

class _HomePlaylistTracksState extends State<HomePlaylistTracks> {
  final MusicCubit playlistTracksCubit = MusicCubit();
  @override
  void initState() {
    super.initState();
    playlistTracksCubit.getPlaylistTracks(
        AppConfig().appContext.read<MusicMainScreenNotifier>().authToken,
        widget.playlistId);
  }

  @override
  void dispose() {
    playlistTracksCubit.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _buildPlaylistsTracks();
  }

  Widget _buildPlaylistsTracks() {
    return BlocBuilder<MusicCubit, MusicState>(
      bloc: playlistTracksCubit,
      builder: (context, state) {
        return state.maybeMap(
          musicInitState: (s) => WaitingWidget(),
          musicLoadingState: (s) => WaitingWidget(),
          playlistTracksLoaded: (s) => SizedBox(
            height: 550.h,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: AppConstants.screenPadding,
              itemBuilder: (context, index) {
                final track = s.tracksListEntity.tracks[index];

                return MusicCard1(
                  height: 550.h,
                  title: track.name ?? "",
                  subtitle: getArtists(
                      track.artists?.map((e) => e.name ?? "").toList() ?? []),
                  image: (track.album?.images?.length ?? 0) > 0
                      ? track.album?.images![0].url
                      : null,
                  onTap: () => widget.onTap(track.id ?? "", index),
                );
              },
              separatorBuilder: (context, _) {
                return Gaps.hGap32;
              },
              itemCount: s.tracksListEntity.tracks.length,
            ),
          ),
          musicErrorState: (s) => ErrorScreenWidget(
            error: s.error,
            callback: s.callback,
          ),
          orElse: () => const ScreenNotImplementedError(),
        );
      },
    );
  }
}
