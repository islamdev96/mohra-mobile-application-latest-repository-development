import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/src/provider.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/common/style/gaps.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/features/music/presentation/logic/spotify_sdk_wrapper.dart';
import 'package:starter_application/features/music/presentation/state_m/provider/music_main_screen_notifier.dart';
import 'package:starter_application/features/music/presentation/widget/music_card2.dart';

class MusicList2 extends StatelessWidget {
  final List<MusicItem> items;
  final ScrollPhysics? physics;
  final EdgeInsetsGeometry? padding;
  final bool shrinkWrap;
  final bool showFavoriteIcon;
  final Function(int index)? onItemTap;
  final Function(int index)? onFavoriteIconTap;
  const MusicList2({
    Key? key,
    required this.items,
    this.physics,
    this.padding,
    this.shrinkWrap = false,
    this.showFavoriteIcon = false,
    this.onItemTap,
    this.onFavoriteIconTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
        padding: padding ??
            AppConstants.screenPadding.copyWith(
              bottom: 64.h,
            ),
        physics: physics,
        shrinkWrap: shrinkWrap,
        itemBuilder: (context, index) {
          final item = items[index];
          return MusicCard2(
            title: item.title,
            leadingImage: item.image,
            leadingIcon: item.icon,
            subtitle: item.subtitle,
            // trailingIcon: showFavoriteIcon ? AppConstants.SVG_LOVE : null,
            //   trailingIconColor:
            //     context.read<MusicMainScreenNotifier>().isSongSaved(item.id)
            //         ? AppColors.primaryColorLight
            //         : AppColors.mansourGrey,
            // onTrailingTap: onFavoriteIconTap,
            trailingWidget: showFavoriteIcon && item.type != null
                ? InkWell(
                    focusColor: AppColors.primaryColorLight.withOpacity(0.4),
                    hoverColor: AppColors.primaryColorLight.withOpacity(0.4),
                    splashColor: AppColors.primaryColorLight.withOpacity(0.4),
                    highlightColor:
                        AppColors.primaryColorLight.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(
                      55.r,
                    ),
                    onTap: () => onFavoriteIconTap?.call(index),
                    child: SizedBox(
                      height: 55.h,
                      width: 55.h,
                      child: SvgPicture.asset(
                        AppConstants.SVG_LOVE,
                        color:
                            context.read<MusicMainScreenNotifier>().isItemSaved(
                                      item.id,
                                      type: item.type!,
                                    )
                                ? AppColors.primaryColorLight
                                : AppColors.mansourGrey,
                      ),
                    ),
                  )
                : null,
            onItemTap: () => onItemTap?.call(index),
          );
        },
        separatorBuilder: (context, index) {
          return Gaps.vGap32;
        },
        itemCount: items.length);
  }
}

class MusicItem {
  final String id;
  final String title;
  final SpotifyType? type;
  final String? subtitle;
  final String? image;
  final String? icon;

  MusicItem({
    required this.id,
    required this.title,
    required this.type,
    this.subtitle,
    this.image,
    this.icon,
  });
}
