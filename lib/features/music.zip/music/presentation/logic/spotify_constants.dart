class SpotifyConstants {
  SpotifyConstants._();

  static const TOP_50_GLOBALS_PLAYLIST_ID = "37i9dQZEVXbMDoHDwVN2tF";
}
