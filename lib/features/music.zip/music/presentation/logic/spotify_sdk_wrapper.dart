import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:spotify_sdk/models/image_uri.dart';
import 'package:spotify_sdk/spotify_sdk.dart';
import 'package:starter_application/core/common/extensions/logger_extension.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';

//Todo Create error handler to handle errors and return Result<AppErrors,Data>
/// Class to interface with Spotify Sdk (Android/Ios)
class SpotifySdkWrapper {
  /// Get the Access/Token that enable us to work with spotify api
  //Todo check when we need to update the auth token
  Future<String?> getAuthToken() async {
    try {
      var authenticationToken = await SpotifySdk.getAuthenticationToken(
          clientId: AppConstants.SPOTIFY_CLIENT_ID,
          redirectUrl: Platform.isIOS?AppConstants.IOS_SPOTIFY_REDIRECT_URL:AppConstants.SPOTIFY_REDIRECT_URL,
          //Todo refactor scopes (Create enum for them and pass them as list<enum>)
          scope: 'app-remote-control, '
              'user-modify-playback-state, '
              'ugc-image-upload, '
              'user-read-private, '
              'user-read-recently-played, '
              'playlist-read-private, '
              'user-library-read, '
              'playlist-modify-private, '
              'playlist-modify-public,user-read-currently-playing');
      return authenticationToken;
    } on PlatformException catch (e) {
      "'$e.code: $e.message'".logE;
      return null;
    } on MissingPluginException {
      "not implemented".logE;
      return null;
    }
  }

  Future<void> disconnect() async {
    try {
      await SpotifySdk.disconnect();
    } on PlatformException catch (e) {
      "'$e.code: $e.message'".logE;
    } on MissingPluginException {
      "not implemented".logE;
    }
  }

  Future<bool> addToLibrary(String id, SpotifyType type) async {
    try {
      await SpotifySdk.addToLibrary(
          spotifyUri: 'spotify:${spotifyTypeToString(type)}:${id}');
      return true;
    } on PlatformException catch (e) {
      "'$e.code: $e.message'".logE;
      return false;
    } on MissingPluginException {
      "not implemented".logE;
      return false;
    }
  }

  Future<bool> removeFromLibrary(String id, SpotifyType type) async {
    try {
      await SpotifySdk.removeFromLibrary(
          spotifyUri: 'spotify:${spotifyTypeToString(type)}:${id}');
      return true;
    } on PlatformException catch (e) {
      "'$e.code: $e.message'".logE;
      return false;
    } on MissingPluginException {
      "not implemented".logE;
      return false;
    }
  }

  Future<void> play(String spotifyId, int? trackIndex, SpotifyType type) async {
    try {
      final contextUri = 'spotify:${spotifyTypeToString(type)}:${spotifyId}';
      if (type == SpotifyType.TRACK || trackIndex == null) {
        await SpotifySdk.play(
          spotifyUri: contextUri,
        );
      } else {
        await SpotifySdk.skipToIndex(
            spotifyUri: contextUri, trackIndex: trackIndex);
      }
    } on PlatformException catch (e) {
      "'$e.code: $e.message'".logE;
    } on MissingPluginException {
      "not implemented".logE;
    }
  }

  Future<void> pause() async {
    try {
      await SpotifySdk.pause();
    } on PlatformException catch (e) {
      "'$e.code: $e.message'".logE;
    } on MissingPluginException {
      "not implemented".logE;
    }
  }

  Future<void> resume() async {
    try {
      await SpotifySdk.resume();
    } on PlatformException catch (e) {
      "'$e.code: $e.message'".logE;
    } on MissingPluginException {
      "not implemented".logE;
    }
  }

  Future<void> skipNext() async {
    try {
      await SpotifySdk.skipNext();
    } on PlatformException catch (e) {
      "'$e.code: $e.message'".logE;
    } on MissingPluginException {
      "not implemented".logE;
    }
  }

  Future<void> skipPrevious() async {
    try {
      await SpotifySdk.skipPrevious();
    } on PlatformException catch (e) {
      "'$e.code: $e.message'".logE;
    } on MissingPluginException {
      "not implemented".logE;
    }
  }

  Future<Uint8List?> getImage({
    required ImageUri imageUri,
    ImageDimension dimension = ImageDimension.medium,
  }) async {
    try {
      final unit8List = await SpotifySdk.getImage(
        imageUri: imageUri,
        dimension: dimension,
      );
      return unit8List;
    } on PlatformException catch (e) {
      "'$e.code: $e.message'".logE;
    } on MissingPluginException {
      "not implemented".logE;
    }
  }

  Future<void> setRepeatMode(RepeatMode repeatMode) async {
    try {
      await SpotifySdk.setRepeatMode(
        repeatMode: repeatMode,
      );
    } on PlatformException catch (e) {
      "'$e.code: $e.message'".logE;
    } on MissingPluginException {
      "not implemented".logE;
    }
  }

  Future<void> setShuffle(bool shuffle) async {
    try {
      await SpotifySdk.setShuffle(
        shuffle: shuffle,
      );
    } on PlatformException catch (e) {
      "'$e.code: $e.message'".logE;
    } on MissingPluginException {
      "not implemented".logE;
    }
  }

  static Future<void> seekTo(int newMilliseconds) async {
    try {
      await SpotifySdk.seekTo(positionedMilliseconds: newMilliseconds);
    } on PlatformException catch (e) {
      "'$e.code: $e.message'".logE;
    } on MissingPluginException {
      "not implemented".logE;
    }
  }

  //Todo implement the other methods
}

enum SpotifyType { PLAYLIST, TRACK, ALBUM, ARTIST }

String spotifyTypeToString(SpotifyType type) {
  switch (type) {
    case SpotifyType.PLAYLIST:
      return "playlist";
    case SpotifyType.TRACK:
      return "track";
    case SpotifyType.ALBUM:
      return "album";
    case SpotifyType.ARTIST:
      return "artist";

    default:
      return "playlist";
  }
}
