import 'package:starter_application/core/datasources/shared_preference.dart';

class SpotifyUtils {
  static const KEY_SPOTIFY_AUTH_TOKEN = "SPOTIFY_AUTH_TOKEN";
  static void storeSpotifyAuthToken(String authToken) async {
    final sp = await SpUtil.instance;
    sp.putString(KEY_SPOTIFY_AUTH_TOKEN, authToken);
  }

  static Future<String?> getSpotifyAuthToken() async {
    final sp = await SpUtil.instance;
    return sp.getString(KEY_SPOTIFY_AUTH_TOKEN);
  }

 static String getIdFromUri(String id) {
    return id.split(':').last;
  }
}
