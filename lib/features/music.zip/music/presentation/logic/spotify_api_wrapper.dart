import 'package:spotify/spotify.dart';
import 'package:starter_application/core/common/extensions/logger_extension.dart';

//Todo handle pagination
/// Class to with with Spotify Api
class SpotifyApiWrapper {
  SpotifyApiWrapper(String authToken) {
    spotify = SpotifyApi.withAccessToken(authToken);
    user = spotify.me;
  }
  late final SpotifyApi spotify;
  late final Me user;

  /// Get All Spotify Categories
  Future<List<Category>> getCategories() async {
    try {
      return (await spotify.categories.list().all()).toList();
    } catch (e) {
      return [];
    }
  }

  /// Get Playlists By CategoryID
  //Todo Merge all playlist methods to one method with  filters to get playlists by is,category...ect
  Future<List<PlaylistSimple>> getPlaylistsByCategoryId(
      String categoryId) async {
    return (await spotify.playlists.getByCategoryId(categoryId).all()).toList();
  }

  /// Get Playlists By CategoryIndex
  Future<List<PlaylistSimple>> getPlaylistsByCategoryIndex(
      int categoryIndex) async {
    try {
      final categories = await getCategories();
      if (categoryIndex < categories.length && categoryIndex >= 0) {
        return (await spotify.playlists
                .getByCategoryId(categories[categoryIndex].id!)
                .all())
            .toList();
      } else {
        return [];
      }
    } catch (e) {
      return [];
    }
  }

  /// Get a playlist tracks
  Future<List<Track>> getPlaylistTracks(String playlistId) async {
    try {
      return (await spotify.playlists.getTracksByPlaylistId(playlistId).all())
          .toList();
    } catch (e) {
      return [];
    }
  }

  /// Get current user recently played tracks
  Future<List<PlayHistory>> getRecentlyPlayedTracks() async {
    try {
      final currentPlayedTracks = await user.recentlyPlayed();
      return currentPlayedTracks.toList();
    } catch (e) {
      return [];
    }
  }

  /// Get current user playlists
  Future<List<PlaylistSimple>> getCurrentUserPlaylists() async {
    try {
      final userPlaylists = await spotify.playlists.me.all();
      return userPlaylists.toList();
    } catch (e) {
      return [];
    }
  }

  /// Get current user top artists
  Future<List<Artist>> getCurrentTopUserArtists() async {
    try {
      final artists = await spotify.me.topArtists();
      return artists.toList();
    } catch (e) {
      return [];
    }
  }

  /// Get current user saved tracks
  Future<List<TrackSaved>> getCurrentUserSavedTracks() async {
    try {
      final tracks = await spotify.tracks.me.saved.all();
      return tracks.toList();
    } catch (e) {
      return [];
    }
  }

  /// Get current user saved tracks
  Future<Playlist?> createPlaylist({
    required String name,
    String? description,
  }) async {
    try {
      final userId = (await spotify.me.get()).id;
      final playlist = await spotify.playlists.createPlaylist(
        userId ?? "",
        name,
        description: description,
        public: false,
        collaborative: false,
      );
      return playlist;
    } catch (e) {}
  }

  /// Add a track to a playlist
  Future<bool> addTrackToPlaylist({
    required String trackId,
    required String playlistId,
  }) async {
    try {
      await spotify.playlists.addTrack(
        "spotify:track:${trackId}",
        playlistId,
      );
      return true;
    } catch (e) {
      return false;
    }
  }

  /// search for tracks
  Future<List<Track>?> searchTracks({
    required String search,
    required int page,
    int limit = 10,
  }) async {
    try {
      /// Page is list of different type (track - artist -ect )but in this case it contains 1 items (Track)
      final List<Page> pageResult = await spotify.search
          .get(search, types: [SearchType.track]).getPage(limit, page * limit);

      final tracks =
          pageResult.first.items?.toList().map((e) => e as Track).toList();

      return tracks;
    } catch (e) {
      e.toString().logE;
      return [];
    }
  }
  /// search for Albums
  Future<List<AlbumSimple>?> searchAlbums({
    required String search,
    required int page,
    int limit = 10,
  }) async {
    try {
      /// Page is list of different type (track - artist -ect )but in this case it contains 1 items (Track)
      final List<Page> pageResult = await spotify.search
          .get(search, types: [SearchType.album]).getPage(limit, page * limit);

      final albums =
          pageResult.first.items?.toList().map((e) => e as AlbumSimple).toList();

      return albums;
    } catch (e) {
      e.toString().logE;
      return [];
    }
  }

  //Todo not tested
  /// Search all spotify items (Currently Support tracks and albums only)
  Future<SpotifySearchResult?> searchSpotifyItem({
    required String search,
    required int page,
    int limit = 10,
  }) async {
    try {
      /// Page is list of different type (track - artist -ect )but in this case it contains 1 items (Track)
      final List<Page> pageResult = await spotify.search
          //Todo Add other types here to get them in the search result
          .get(search, types: [
        SearchType.track,
        SearchType.album,
      ]).getPage(limit, page * limit);

      final tracks =
          pageResult.first.items?.toList().map((e) => e as Track).toList();
      final albums =
          pageResult.first.items?.toList().map((e) => e as Album).toList();

      return SpotifySearchResult(tracks: tracks, albums: albums);
    } catch (e) {
      e.toString().logE;
      return null;
    }
  }
  /// Get an Album tracks
  Future<List<TrackSimple>> getAlbumTracks(String albumId) async {
    try {
      return (await spotify.albums.getTracks(albumId).all())
          .toList();
    } catch (e) {
      return [];
    }
  }
  /// Get an Artist albums
  Future<List<Album>> getArtistAlbums(String artistId) async {
    try {
      return (await spotify.artists.albums(artistId).all())
          .toList();
    } catch (e) {
      return [];
    }
  }
  /// Get Artists by ids
  Future<List<Artist>> getArtistByIds(List<String>ids) async {
    try {
      return (await spotify.artists.list(ids))
          .toList();
    } catch (e) {
      return [];
    }
  }
}

/// For now it support tracks and albums only
//Todo Add other types here to get them in the search result
class SpotifySearchResult {
  final List<Track>? tracks;
  final List<Album>? albums;

  SpotifySearchResult({
    this.tracks,
    this.albums,
  });
}
