import 'package:starter_application/core/params/base_params.dart';

class UpdatePlaylistImageParam extends BaseParams {
  String playlistId;
  String base64Image;
  UpdatePlaylistImageParam({
    required this.playlistId,
    required this.base64Image,
  });

  @override
  Map<String, dynamic> toMap() => {};
}
