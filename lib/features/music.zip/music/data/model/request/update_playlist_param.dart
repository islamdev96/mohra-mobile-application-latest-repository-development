import 'package:starter_application/core/params/base_params.dart';

class UpdatePlaylistParam extends BaseParams {
  final String id;
  final String? name;

  UpdatePlaylistParam({
    required this.id,
    this.name,
  });

  @override
  Map<String, dynamic> toMap() => {
        if (name != null) "name": name,
      };
}
