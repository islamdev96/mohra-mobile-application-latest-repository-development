import 'package:starter_application/core/params/base_params.dart';

class MusicPaginationParam extends BaseParams {
  final int limit;
  final int offset;

  MusicPaginationParam(this.limit, this.offset);
  @override
  Map<String, dynamic> toMap() =>{
    "limit":limit,
    "offset":offset,
  };
}
