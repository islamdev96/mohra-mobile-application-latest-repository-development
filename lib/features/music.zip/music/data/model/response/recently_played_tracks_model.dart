// To parse this JSON data, do
//
//     final recentlyPlayedTracksListEntity = recentlyPlayedTracksListEntityFromMap(jsonString);

import 'dart:convert';

import 'package:starter_application/core/common/extensions/base_model_list_extension.dart';
import 'package:starter_application/core/models/base_model.dart';
import 'package:starter_application/features/music/data/model/response/saved_albums_list_model.dart';
import 'package:starter_application/features/music/domain/entity/recently_played_tracks_entity.dart';

class RecentlyPlayedTracksListModel
    extends BaseModel<RecentlyPlayedTracksListEntity> {
  RecentlyPlayedTracksListModel({
    required this.items,

  });
  final List<RecentlyPlayedItemModel> items;

  factory RecentlyPlayedTracksListModel.fromMap(Map<String, dynamic> json) =>
      RecentlyPlayedTracksListModel(
        items: json["items"] == null
            ? []
            : List<RecentlyPlayedItemModel>.from(
                json["items"].map((x) => RecentlyPlayedItemModel.fromMap(x))),
      );

  @override
  RecentlyPlayedTracksListEntity toEntity() {
    return RecentlyPlayedTracksListEntity(items: items.toListEntity());
  }
}

class RecentlyPlayedItemModel extends BaseModel<RecentlyPlayedItemEntity> {
  RecentlyPlayedItemModel({
    required this.track,
    required this.playedAt,
    required this.context,
  });

  final RecentlyPlayedTrackModel? track;
  final DateTime? playedAt;
  final RecentlyPlayedContextModel? context;

  factory RecentlyPlayedItemModel.fromJson(String str) =>
      RecentlyPlayedItemModel.fromMap(json.decode(str));

  factory RecentlyPlayedItemModel.fromMap(Map<String, dynamic> json) =>
      RecentlyPlayedItemModel(
        track: json["track"] == null
            ? null
            : RecentlyPlayedTrackModel.fromMap(json["track"]),
        playedAt: json["played_at"] == null
            ? null
            : DateTime.parse(json["played_at"]),
        context: json["context"] == null
            ? null
            : RecentlyPlayedContextModel.fromMap(json["context"]),
      );

  @override
  RecentlyPlayedItemEntity toEntity() {
    return RecentlyPlayedItemEntity(
      track: track?.toEntity(),
      playedAt: playedAt,
      context: context?.toEntity(),
    );
  }
}

class RecentlyPlayedContextModel
    extends BaseModel<RecentlyPlayedContextEntity> {
  RecentlyPlayedContextModel({
    required this.href,
    required this.type,
    required this.uri,
  });

  final String? href;
  final String? type;
  final String? uri;

  factory RecentlyPlayedContextModel.fromMap(Map<String, dynamic> json) =>
      RecentlyPlayedContextModel(
        href: json["href"] == null ? null : json["href"],
        type: json["type"] == null ? null : json["type"],
        uri: json["uri"] == null ? null : json["uri"],
      );

  @override
  RecentlyPlayedContextEntity toEntity() {
    return RecentlyPlayedContextEntity(
      href: href,
      type: type,
      uri: uri,
    );
  }
}

class RecentlyPlayedTrackModel extends BaseModel<RecentlyPlayedTrackEntity> {
  RecentlyPlayedTrackModel({
    required this.album,
    required this.artists,
    required this.availableMarkets,
    required this.discNumber,
    required this.durationMs,
    required this.explicit,
    required this.href,
    required this.id,
    required this.isLocal,
    required this.name,
    required this.popularity,
    required this.previewUrl,
    required this.trackNumber,
    required this.type,
    required this.uri,
  });

  final RecentlyPlayedAlbumModel? album;
  final List<ArtistModel> artists;
  final List<String> availableMarkets;
  final int? discNumber;
  final int? durationMs;
  final bool? explicit;
  final String? href;
  final String? id;
  final bool? isLocal;
  final String? name;
  final int? popularity;
  final String? previewUrl;
  final int? trackNumber;
  final String? type;
  final String? uri;
  factory RecentlyPlayedTrackModel.fromMap(Map<String, dynamic> json) =>
      RecentlyPlayedTrackModel(
        album: json["album"] == null
            ? null
            : RecentlyPlayedAlbumModel.fromMap(json["album"]),
        artists: json["artists"] == null
            ? []
            : List<ArtistModel>.from(
                json["artists"].map((x) => ArtistModel.fromMap(x))),
        availableMarkets: json["available_markets"] == null
            ? []
            : List<String>.from(json["available_markets"].map((x) => x)),
        discNumber: json["disc_number"] == null ? null : json["disc_number"],
        durationMs: json["duration_ms"] == null ? null : json["duration_ms"],
        explicit: json["explicit"] == null ? null : json["explicit"],
        href: json["href"] == null ? null : json["href"],
        id: json["id"] == null ? null : json["id"],
        isLocal: json["is_local"] == null ? null : json["is_local"],
        name: json["name"] == null ? null : json["name"],
        popularity: json["popularity"] == null ? null : json["popularity"],
        previewUrl: json["preview_url"] == null ? null : json["preview_url"],
        trackNumber: json["track_number"] == null ? null : json["track_number"],
        type: json["type"] == null ? null : json["type"],
        uri: json["uri"] == null ? null : json["uri"],
      );

  @override
  RecentlyPlayedTrackEntity toEntity() {
    return RecentlyPlayedTrackEntity(
      album: album?.toEntity(),
      artists: artists.toListEntity(),
      availableMarkets: availableMarkets,
      discNumber: discNumber,
      durationMs: durationMs,
      explicit: explicit,
      href: href,
      id: id,
      isLocal: isLocal,
      name: name,
      popularity: popularity,
      previewUrl: previewUrl,
      trackNumber: trackNumber,
      type: type,
      uri: uri,
    );
  }
}

class RecentlyPlayedAlbumModel extends BaseModel<RecentlyPlayedAlbumEntity> {
  RecentlyPlayedAlbumModel({
    required this.albumType,
    required this.artists,
    required this.availableMarkets,
    required this.href,
    required this.id,
    required this.images,
    required this.name,
    required this.releaseDate,
    required this.releaseDatePrecision,
    required this.totalTracks,
    required this.type,
    required this.uri,
  });

  final String? albumType;
  final List<ArtistModel> artists;
  final List<String> availableMarkets;
  final String? href;
  final String? id;
  final List<ImageModel> images;
  final String? name;
  final DateTime? releaseDate;
  final String? releaseDatePrecision;
  final int? totalTracks;
  final String? type;
  final String? uri;

  factory RecentlyPlayedAlbumModel.fromMap(Map<String, dynamic> json) =>
      RecentlyPlayedAlbumModel(
        albumType: json["album_type"] == null ? null : json["album_type"],
        artists: json["artists"] == null
            ? []
            : List<ArtistModel>.from(
                json["artists"].map((x) => ArtistModel.fromMap(x))),
        availableMarkets: json["available_markets"] == null
            ? []
            : List<String>.from(json["available_markets"].map((x) => x)),
        href: json["href"] == null ? null : json["href"],
        id: json["id"] == null ? null : json["id"],
        images: json["images"] == null
            ? []
            : List<ImageModel>.from(
                json["images"].map((x) => ImageModel.fromMap(x))),
        name: json["name"] == null ? null : json["name"],
        releaseDate: json["release_date"] == null
            ? null
            : DateTime.parse(json["release_date"]),
        releaseDatePrecision: json["release_date_precision"] == null
            ? null
            : json["release_date_precision"],
        totalTracks: json["total_tracks"] == null ? null : json["total_tracks"],
        type: json["type"] == null ? null : json["type"],
        uri: json["uri"] == null ? null : json["uri"],
      );

  @override
  RecentlyPlayedAlbumEntity toEntity() {
    return RecentlyPlayedAlbumEntity(
        albumType: albumType,
        artists: artists.toListEntity(),
        availableMarkets: availableMarkets,
        href: href,
        id: id,
        images: images.toListEntity(),
        name: name,
        releaseDate: releaseDate,
        releaseDatePrecision: releaseDatePrecision,
        totalTracks: totalTracks,
        type: type,
        uri: uri);
  }
}
