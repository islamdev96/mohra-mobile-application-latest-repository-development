// To parse this JSON data, do
//
//     final savedAlbmusListModel = savedAlbmusListModelFromMap(jsonString);

import 'dart:convert';

import 'package:starter_application/core/common/extensions/base_model_list_extension.dart';
import 'package:starter_application/core/models/base_model.dart';
import 'package:starter_application/features/music/domain/entity/saved_albums_list_entity.dart';

SavedAlbumsListModel savedAlbmusListModelFromMap(String str) =>
    SavedAlbumsListModel.fromMap(json.decode(str));


class SavedAlbumsListModel extends BaseModel<SavedAlbumsListEntity> {
  SavedAlbumsListModel({
    required this.href,
    required this.items,
    required this.previous,
    required this.total,
  });

  final String? href;
  final List<SavedAlbmusItemModel> items;
  final dynamic previous;
  final int? total;

  factory SavedAlbumsListModel.fromMap(Map<String, dynamic> json) =>
      SavedAlbumsListModel(
        href: json["href"] == null ? null : json["href"],
        items: json["items"] == null
            ? []
            : List<SavedAlbmusItemModel>.from(
                json["items"].map((x) => SavedAlbmusItemModel.fromMap(x))),
        previous: json["previous"],
        total: json["total"] == null ? null : json["total"],
      );



  @override
  SavedAlbumsListEntity toEntity() {
    return SavedAlbumsListEntity(
        href: href,
        items: items.toListEntity(),
        previous: previous,
        total: total);
  }
}

class SavedAlbmusItemModel extends BaseModel<SavedAlbumsItemEntity> {
  SavedAlbmusItemModel({
    required this.album,
  });

  final AlbumModel? album;

  factory SavedAlbmusItemModel.fromMap(Map<String, dynamic> json) =>
      SavedAlbmusItemModel(
        album: json["album"] == null ? null : AlbumModel.fromMap(json["album"]),
      );

  @override
  SavedAlbumsItemEntity toEntity() {
    return SavedAlbumsItemEntity(
      album: album?.toEntity(),
    );
  }
}

class AlbumModel extends BaseModel<AlbumEntity> {
  AlbumModel({
    required this.albumType,
    required this.artists,
    required this.externalIds,
    required this.externalUrls,
    required this.genres,
    required this.href,
    required this.id,
    required this.images,
    required this.label,
    required this.name,
    required this.popularity,
    required this.releaseDate,
    required this.releaseDatePrecision,
    required this.totalTracks,
    required this.tracks,
    required this.type,
    required this.uri,
  });

  final String? albumType;
  final List<ArtistModel> artists;
  final ExternalIdsModel? externalIds;
  final ExternalUrlsModel? externalUrls;
  final List<dynamic> genres;
  final String? href;
  final String? id;
  final List<ImageModel> images;
  final String? label;
  final String? name;
  final int? popularity;
  final DateTime? releaseDate;
  final String? releaseDatePrecision;
  final int? totalTracks;
  final TracksModel? tracks;
  final String? type;
  final String? uri;

  factory AlbumModel.fromMap(Map<String, dynamic> json) => AlbumModel(
        albumType: json["album_type"] == null ? null : json["album_type"],
        artists: json["artists"] == null
            ? []
            : List<ArtistModel>.from(
                json["artists"].map((x) => ArtistModel.fromMap(x))),
        externalIds: json["external_ids"] == null
            ? null
            : ExternalIdsModel.fromMap(json["external_ids"]),
        externalUrls: json["external_urls"] == null
            ? null
            : ExternalUrlsModel.fromMap(json["external_urls"]),
        genres: json["genres"] == null
            ? []
            : List<dynamic>.from(json["genres"].map((x) => x)),
        href: json["href"] == null ? null : json["href"],
        id: json["id"] == null ? null : json["id"],
        images: json["images"] == null
            ? []
            : List<ImageModel>.from(
                json["images"].map((x) => ImageModel.fromMap(x))),
        label: json["label"] == null ? null : json["label"],
        name: json["name"] == null ? null : json["name"],
        popularity: json["popularity"] == null ? null : json["popularity"],
        releaseDate: json["release_date"] == null
            ? null
            : DateTime.parse(json["release_date"]),
        releaseDatePrecision: json["release_date_precision"] == null
            ? null
            : json["release_date_precision"],
        totalTracks: json["total_tracks"] == null ? null : json["total_tracks"],
        tracks:
            json["tracks"] == null ? null : TracksModel.fromMap(json["tracks"]),
        type: json["type"] == null ? null : json["type"],
        uri: json["uri"] == null ? null : json["uri"],
      );

  @override
  AlbumEntity toEntity() {
    return AlbumEntity(
        albumType: albumType,
        artists: artists.toListEntity(),
        externalIds: externalIds?.toEntity(),
        externalUrls: externalUrls?.toEntity(),
        genres: genres,
        href: href,
        id: id,
        images: images.toListEntity(),
        label: label,
        name: name,
        popularity: popularity,
        releaseDate: releaseDate,
        releaseDatePrecision: releaseDatePrecision,
        totalTracks: totalTracks,
        tracks: tracks?.toEntity(),
        type: type,
        uri: uri);
  }
}

class ArtistModel extends BaseModel<ArtistEntity> {
  ArtistModel({
    required this.externalUrls,
    required this.href,
    required this.id,
    required this.name,
    required this.type,
    required this.uri,
  });

  final ExternalUrlsModel? externalUrls;
  final String? href;
  final String? id;
  final String? name;
  final String? type;
  final String? uri;

  factory ArtistModel.fromMap(Map<String, dynamic> json) => ArtistModel(
        externalUrls: json["external_urls"] == null
            ? null
            : ExternalUrlsModel.fromMap(json["external_urls"]),
        href: json["href"] == null ? null : json["href"],
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
        type: json["type"] == null ? null : json["type"],
        uri: json["uri"] == null ? null : json["uri"],
      );


  @override
  ArtistEntity toEntity() {
    return ArtistEntity(
      externalUrls: externalUrls?.toEntity(),
      href: href,
      id: id,
      name: name,
      type: type,
      uri: uri,
    );
  }
}

class ExternalUrlsModel extends BaseModel<ExternalUrlsEntity> {
  ExternalUrlsModel({
    required this.spotify,
  });

  final String? spotify;

  factory ExternalUrlsModel.fromMap(Map<String, dynamic> json) =>
      ExternalUrlsModel(
        spotify: json["spotify"] == null ? null : json["spotify"],
      );

  Map<String, dynamic> toMap() => {
        "spotify": spotify == null ? null : spotify,
      };

  @override
  ExternalUrlsEntity toEntity() {
    return ExternalUrlsEntity(spotify: spotify);
  }
}

class ExternalIdsModel extends BaseModel<ExternalIdsEntity> {
  ExternalIdsModel({
    required this.upc,
  });

  final String? upc;

  factory ExternalIdsModel.fromMap(Map<String, dynamic> json) =>
      ExternalIdsModel(
        upc: json["upc"] == null ? null : json["upc"],
      );

  Map<String, dynamic> toMap() => {
        "upc": upc == null ? null : upc,
      };

  @override
  ExternalIdsEntity toEntity() {
    return ExternalIdsEntity(upc: upc);
  }
}

class ImageModel extends BaseModel<ImageEntity> {
  ImageModel({
    required this.height,
    required this.url,
    required this.width,
  });

  final int? height;
  final String? url;
  final int? width;

  factory ImageModel.fromMap(Map<String, dynamic> json) => ImageModel(
        height: json["height"] == null ? null : json["height"],
        url: json["url"] == null ? null : json["url"],
        width: json["width"] == null ? null : json["width"],
      );

  Map<String, dynamic> toMap() => {
        "height": height == null ? null : height,
        "url": url == null ? null : url,
        "width": width == null ? null : width,
      };

  @override
  ImageEntity toEntity() {
    return ImageEntity(
      height: height,
      url: url,
      width: width,
    );
  }
}

class TracksModel extends BaseModel<TracksEntity> {
  TracksModel({
    required this.href,
    required this.items,
    required this.limit,
    required this.next,
    required this.offset,
    required this.previous,
    required this.total,
  });

  final String? href;
  final List<TracksItemModel> items;
  final int? limit;
  final dynamic next;
  final int? offset;
  final dynamic previous;
  final int? total;

  factory TracksModel.fromMap(Map<String, dynamic> json) => TracksModel(
        href: json["href"] == null ? null : json["href"],
        items: json["items"] == null
            ? []
            : List<TracksItemModel>.from(
                json["items"].map((x) => TracksItemModel.fromMap(x))),
        limit: json["limit"] == null ? null : json["limit"],
        next: json["next"],
        offset: json["offset"] == null ? null : json["offset"],
        previous: json["previous"],
        total: json["total"] == null ? null : json["total"],
      );



  @override
  TracksEntity toEntity() {
    return TracksEntity(
      href: href,
      items: items.toListEntity(),
      limit: limit,
      next: next,
      offset: offset,
      previous: previous,
      total: total,
    );
  }
}

class TracksItemModel extends BaseModel<TracksItemEntity> {
  TracksItemModel({
    required this.artists,
    required this.discNumber,
    required this.durationMs,
    required this.explicit,
    required this.externalUrls,
    required this.href,
    required this.id,
    required this.isLocal,
    required this.name,
    required this.previewUrl,
    required this.trackNumber,
    required this.type,
    required this.uri,
  });

  final List<ArtistModel> artists;
  final int? discNumber;
  final int? durationMs;
  final bool? explicit;
  final ExternalUrlsModel? externalUrls;
  final String? href;
  final String? id;
  final bool? isLocal;
  final String? name;
  final dynamic previewUrl;
  final int? trackNumber;
  final String? type;
  final String? uri;

  factory TracksItemModel.fromMap(Map<String, dynamic> json) => TracksItemModel(
        artists: json["artists"] == null
            ? []
            : List<ArtistModel>.from(
                json["artists"].map((x) => ArtistModel.fromMap(x))).toList(),
        discNumber: json["disc_number"] == null ? null : json["disc_number"],
        durationMs: json["duration_ms"] == null ? null : json["duration_ms"],
        explicit: json["explicit"] == null ? null : json["explicit"],
        externalUrls: json["external_urls"] == null
            ? null
            : ExternalUrlsModel.fromMap(json["external_urls"]),
        href: json["href"] == null ? null : json["href"],
        id: json["id"] == null ? null : json["id"],
        isLocal: json["is_local"] == null ? null : json["is_local"],
        name: json["name"] == null ? null : json["name"],
        previewUrl: json["preview_url"],
        trackNumber: json["track_number"] == null ? null : json["track_number"],
        type: json["type"] == null ? null : json["type"],
        uri: json["uri"] == null ? null : json["uri"],
      );

  @override
  TracksItemEntity toEntity() {
    return TracksItemEntity(
      artists: artists.toListEntity(),
      discNumber: discNumber,
      durationMs: durationMs,
      explicit: explicit,
      externalUrls: externalUrls?.toEntity(),
      href: href,
      id: id,
      isLocal: isLocal,
      name: name,
      previewUrl: previewUrl,
      trackNumber: trackNumber,
      type: type,
      uri: uri,
    );
  }
}
