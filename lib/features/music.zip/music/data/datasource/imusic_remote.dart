import 'package:dartz/dartz.dart';
import 'package:starter_application/core/errors/app_errors.dart';
import 'package:starter_application/core/models/empty_response.dart';
import 'package:starter_application/features/music/data/model/request/music_pagination_param.dart';
import 'package:starter_application/features/music/data/model/request/update_playlist_image_param.dart';
import 'package:starter_application/features/music/data/model/request/update_playlist_param.dart';
import 'package:starter_application/features/music/data/model/response/recently_played_tracks_model.dart';
import 'package:starter_application/features/music/data/model/response/saved_albums_list_model.dart';

import '../../../../core/datasources/remote_data_source.dart';

abstract class IMusicRemoteSource extends RemoteDataSource {
  Future<Either<AppErrors, SavedAlbumsListModel>> getSavedAlbums(
      MusicPaginationParam param);

  Future<Either<AppErrors, RecentlyPlayedTracksListModel>>
      getRecentlyPlayedTracks();

  Future<Either<AppErrors, EmptyResponse>> updatePlaylistImage(
      UpdatePlaylistImageParam param);

  Future<Either<AppErrors, EmptyResponse>> updatePlaylist(UpdatePlaylistParam param);
}
