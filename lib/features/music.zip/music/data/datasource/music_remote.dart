import 'package:dartz/dartz.dart';
import 'package:injectable/injectable.dart';
import 'package:starter_application/core/constants/enums/http_client_type.dart';
import 'package:starter_application/core/constants/enums/http_method.dart';
import 'package:starter_application/core/errors/app_errors.dart';
import 'package:starter_application/core/models/empty_response.dart';
import 'package:starter_application/core/net/create_model_interceptor/all_data_create_model_inteceptor.dart';
import 'package:starter_application/core/net/spotify/spotify_api_urls.dart';
import 'package:starter_application/core/net/spotify/spotify_response_validator.dart';
import 'package:starter_application/core/params/no_params.dart';
import 'package:starter_application/features/music/data/model/request/music_pagination_param.dart';
import 'package:starter_application/features/music/data/model/request/update_playlist_image_param.dart';
import 'package:starter_application/features/music/data/model/request/update_playlist_param.dart';
import 'package:starter_application/features/music/data/model/response/recently_played_tracks_model.dart';
import 'package:starter_application/features/music/data/model/response/saved_albums_list_model.dart';

import 'imusic_remote.dart';

@Singleton(as: IMusicRemoteSource)
class MusicRemoteSource extends IMusicRemoteSource {
  @override
  Future<Either<AppErrors, SavedAlbumsListModel>> getSavedAlbums(
      MusicPaginationParam param) {
    return request<SavedAlbumsListModel>(
      converter: (json) => SavedAlbumsListModel.fromMap(json),
      method: HttpMethod.GET,
      baseUrl: SpotifyApiUrls.BASE_URL,
      url: SpotifyApiUrls.SAVED_ALBUMS,
      createModelInterceptor: const AllDataCreateModelInterceptor(),
      responseValidator: SpotifyResponseValidator(),
      queryParameters: param.toMap(),
      httpClientType: HttpClientType.SPOTIFY,
    );
  }

  @override
  Future<Either<AppErrors, RecentlyPlayedTracksListModel>>
      getRecentlyPlayedTracks() {
    return request<RecentlyPlayedTracksListModel>(
      converter: (json) => RecentlyPlayedTracksListModel.fromMap(json),
      method: HttpMethod.GET,
      baseUrl: SpotifyApiUrls.BASE_URL,
      url: SpotifyApiUrls.RECENTLY_PLAYED_TRACKS,
      createModelInterceptor: const AllDataCreateModelInterceptor(),
      responseValidator: SpotifyResponseValidator(),
      httpClientType: HttpClientType.SPOTIFY,
      queryParameters: NoParams().toMap(),
    );
  }

  @override
  Future<Either<AppErrors, EmptyResponse>> updatePlaylistImage(
      UpdatePlaylistImageParam param) {
    return request<EmptyResponse>(
      converter: (json) => EmptyResponse.fromMap(json),
      method: HttpMethod.PUT,
      baseUrl: SpotifyApiUrls.BASE_URL,
      url: SpotifyApiUrls.updatePlaylistImage(param.playlistId),
      createModelInterceptor: const AllDataCreateModelInterceptor(),
      responseValidator: SpotifyResponseValidator(),
      httpClientType: HttpClientType.SPOTIFY,
      body: param.base64Image,
    );
  }
  @override
  Future<Either<AppErrors, EmptyResponse>> updatePlaylist(
      UpdatePlaylistParam param) {
    return request<EmptyResponse>(
      converter: (json) => EmptyResponse.fromMap(json),
      method: HttpMethod.PUT,
      baseUrl: SpotifyApiUrls.BASE_URL,
      url: SpotifyApiUrls.updatePlaylistInfo(param.id),
      body: param.toMap(),
      createModelInterceptor: const AllDataCreateModelInterceptor(),
      responseValidator: SpotifyResponseValidator(),
      httpClientType: HttpClientType.SPOTIFY,
    );
  }
}
