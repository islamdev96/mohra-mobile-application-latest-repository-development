import 'package:injectable/injectable.dart';
import 'package:starter_application/core/common/extensions/either_error_model_extension.dart';
import 'package:starter_application/core/errors/app_errors.dart';
import 'package:starter_application/core/models/empty_response.dart';
import 'package:starter_application/core/results/result.dart';
import 'package:starter_application/features/music/data/model/request/music_pagination_param.dart';
import 'package:starter_application/features/music/data/model/request/update_playlist_image_param.dart';
import 'package:starter_application/features/music/data/model/request/update_playlist_param.dart';
import 'package:starter_application/features/music/domain/entity/recently_played_tracks_entity.dart';
import 'package:starter_application/features/music/domain/entity/saved_albums_list_entity.dart';

import '../datasource/../../domain/repository/imusic_repository.dart';
import '../datasource/imusic_remote.dart';

@Singleton(as: IMusicRepository)
class MusicRepository extends IMusicRepository {
  final IMusicRemoteSource iMusicRemoteSource;

  MusicRepository(this.iMusicRemoteSource);

  @override
  Future<Result<AppErrors, RecentlyPlayedTracksListEntity>>
      getRecentlyPlayedTracks() async {
    final remote = await iMusicRemoteSource.getRecentlyPlayedTracks();
    return remote.result<RecentlyPlayedTracksListEntity>();
  }

  @override
  Future<Result<AppErrors, EmptyResponse>> updatePlaylistImage(
      UpdatePlaylistImageParam param) async {
    final remote = await iMusicRemoteSource.updatePlaylistImage(param);
    return remote.result<EmptyResponse>();
  }

  @override
  Future<Result<AppErrors, EmptyResponse>> updatePlaylist(
      UpdatePlaylistParam param) async {
    final remote = await iMusicRemoteSource.updatePlaylist(param);
    return remote.result<EmptyResponse>();
  }

  @override
  Future<Result<AppErrors, SavedAlbumsListEntity>> getSavedAlbums(
      MusicPaginationParam param) async {
    final remote = await iMusicRemoteSource.getSavedAlbums(param);
    return remote.result<SavedAlbumsListEntity>();
  }
}
