import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/core/common/app_colors.dart';
import 'package:starter_application/core/params/screen_params/video_audio_chat_screen_params.dart';
import 'package:starter_application/features/messages/presentation/screen/video_audio_chat_screen_content.dart';
import 'package:starter_application/features/messages/presentation/state_m/provider/call_screen_notifier.dart';
import 'package:starter_application/features/messages/presentation/state_m/provider/video_audio_chat_screen_notifier.dart';

class VideoAudioChatScreen extends StatefulWidget {
  static const String routeName = "/VideoChatScreen";
  final VideoAudioChatScreenParams params;

  const VideoAudioChatScreen({Key? key, required this.params})
      : super(key: key);

  @override
  _VideoAudioChatScreenState createState() => _VideoAudioChatScreenState();
}

class _VideoAudioChatScreenState extends State<VideoAudioChatScreen> {
  final sn = VideoAudioChatScreenNotifier();

  @override
  void initState() {
    super.initState();
    sn.params = widget.params;
    SchedulerBinding.instance?.addPostFrameCallback((timeStamp) {
      if (Provider.of<CallScreenNotifier>(context, listen: false).engine ==
          null) {
        sn.initAgora();
      } else {
        sn.engine =
            Provider.of<CallScreenNotifier>(context, listen: false).engine!;
      }
    });
  }

  @override
  void dispose() {
    sn.closeNotifier();
    // sn.closeCall();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<VideoAudioChatScreenNotifier>.value(
      value: sn,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: AppColors.black,
        ),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: VideoAudioChatScreenContent(),
      ),
    );
  }
}
