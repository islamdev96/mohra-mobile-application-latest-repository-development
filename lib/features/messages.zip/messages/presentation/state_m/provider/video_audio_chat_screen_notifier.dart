import 'package:agora_rtc_engine/rtc_engine.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:starter_application/core/constants/app/app_constants.dart';
import 'package:starter_application/core/datasources/shared_preference.dart';
import 'package:starter_application/core/navigation/nav.dart';
import 'package:starter_application/core/params/screen_params/video_audio_chat_screen_params.dart';
import 'package:starter_application/features/messages/presentation/state_m/provider/call_screen_notifier.dart';

import '../../../../../core/common/costum_modules/screen_notifier.dart';

class VideoAudioChatScreenNotifier extends ScreenNotifier {
  /// Fields
  late BuildContext context;
  List<TempUserEntity> users = [];
  bool _localUserJoined = false;
  late RtcEngine engine;

  late VideoAudioChatScreenParams params;
  bool _withVideo = true;
  bool _withAudio = true;
  bool _idHideControlWidget = false;
  int userId = -1;

  /// Getters and Setters
  bool get localUserJoined => _localUserJoined;

  set localUserJoined(bool value) {
    _localUserJoined = value;
    notifyListeners();
  }

  bool get withVideo => _withVideo;

  set withVideo(bool value) {
    _withVideo = value;
    notifyListeners();
  }

  bool get withAudio => _withAudio;

  set withAudio(bool value) {
    _withAudio = value;
    notifyListeners();
  }

  bool get isHideControlWidget => _idHideControlWidget;

  set isHideControlWidget(bool value) {
    _idHideControlWidget = value;
    notifyListeners();
  }

  /// Methods

  flipCamera() async {
    await engine.switchCamera();
    notifyListeners();
  }

  closeCall() {
    Provider.of<CallScreenNotifier>(context, listen: false).engine = null;
    engine.destroy();
  }

  hideControl() {
    isHideControlWidget = !isHideControlWidget;
  }

  onCloseButtonTapped() {
    closeCall();
    Nav.pop();
  }

  changeVideoState() {
    withVideo = !withVideo;
    engine.enableLocalVideo(withVideo);
  }

  changeAudioState() {
    withAudio = !withAudio;
    engine.enableLocalAudio(withAudio);
  }

  addUser(TempUserEntity user) {
    users.removeWhere((element) => element.id == user.id);
    users.add(user);
    notifyListeners();
  }

  removeUser(int id) {
    users.removeWhere((element) => element.id == id);
    notifyListeners();
  }

  changeUserMicState(int id, bool enabled) {
    TempUserEntity previousUser =
        users.firstWhere((element) => element.id == id);
    int index = users.indexOf(previousUser);

    users[index] = TempUserEntity(id: id, mic: enabled, cam: previousUser.cam);

    notifyListeners();
  }

  changeUserVideoState(int id, bool enabled) {
    TempUserEntity previousUser =
        users.firstWhere((element) => element.id == id);
    int index = users.indexOf(previousUser);
    users[index] = TempUserEntity(id: id, mic: previousUser.mic, cam: enabled);
    notifyListeners();
  }

  Future<void> initAgora() async {
    // retrieve permissions
    await [Permission.microphone, Permission.camera].request();

    //create the engine
    engine = await RtcEngine.create(AppConstants.AGORA_APP_ID);
    if (params.withVideo) {
      await engine.enableVideo();
    } else {
      await engine.enableAudio();
      await engine.disableVideo();
    }
    engine.setEventHandler(
      RtcEngineEventHandler(
        joinChannelSuccess: (String channel, int uid, int elapsed) {
          print("local user $uid joined");

          localUserJoined = true;
          addUser(TempUserEntity(id: uid, mic: withAudio, cam: withVideo));
        },
        userJoined: (int uid, int elapsed) {
          print("remote user $uid joined");

          addUser(TempUserEntity(id: uid, mic: true, cam: true));
        },
        userOffline: (int uid, UserOfflineReason reason) {
          print("remote user $uid left channel");

          removeUser(uid);
        },
        userEnableLocalVideo: (uid, enabled) {
          changeUserVideoState(uid, enabled);
        },
        remoteAudioStateChanged: (uid, state, reason, elapsed) {
          bool? enabled;
          if (reason == AudioRemoteStateReason.RemoteUnmuted)
            enabled = true;
          else if (reason == AudioRemoteStateReason.RemoteMuted)
            enabled = false;
          if (enabled != null) changeUserMicState(uid, enabled);
        },
      ),
    );

    final prefs = await SpUtil.getInstance();
    userId = await prefs.getInt(AppConstants.KEY_USERID) ?? 0;

    await engine.joinChannel(
        params.token.token, params.token.channel, null, userId);

    Provider.of<CallScreenNotifier>(context, listen: false).engine = engine;
    Provider.of<CallScreenNotifier>(context, listen: false).userId = userId;
    Provider.of<CallScreenNotifier>(context, listen: false).withVideo =
        params.withVideo;
  }

  removeNotification() {
    /*if (Provider.of<CallScreenNotifier>(getIt<NavigationService>().appContext!,
                listen: false)
            .engine ==
        null) flutterLocalNotificationsPlugin.cancel(0);*/
  }

  String getMemberName(int id) {
    String name = '';
    params.clients.forEach((element) {
      if (element.id == id) name = element.fullName;
    });
    return name;
  }

  @override
  void closeNotifier() {
    removeNotification();
    this.dispose();
  }
}

class TempUserEntity {
  int id;
  bool mic;
  bool cam;

  TempUserEntity({required this.id, required this.mic, required this.cam});
}
