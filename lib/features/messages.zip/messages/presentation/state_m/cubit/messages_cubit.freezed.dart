// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'messages_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more informations: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
class _$MessagesStateTearOff {
  const _$MessagesStateTearOff();

  MessagesInitState messagesInitState() {
    return const MessagesInitState();
  }

  MessagesLoadingState messagesLoadingState() {
    return const MessagesLoadingState();
  }

  ConversationsLoadedState conversationsLoadedState(
      ConversationsEntity conversationsEntity) {
    return ConversationsLoadedState(
      conversationsEntity,
    );
  }

  MessageCreatedState messageCreatedState(EmptyResponse emptyResponse) {
    return MessageCreatedState(
      emptyResponse,
    );
  }

  MessageBroadCastCreatedState messageBroadCastCreatedState(
      EmptyResponse emptyResponse) {
    return MessageBroadCastCreatedState(
      emptyResponse,
    );
  }

  MessagesLoadedState messagesLoadedState(MessagesEntity messagesEntity) {
    return MessagesLoadedState(
      messagesEntity,
    );
  }

  TokenLoadedState tokenLoadedState(TokenEntity tokenEntity) {
    return TokenLoadedState(
      tokenEntity,
    );
  }

  TokenRtmLoadedState tokenRtmLoadedState(TokenRtmEntity tokenRtmEntity) {
    return TokenRtmLoadedState(
      tokenRtmEntity,
    );
  }

  ConversationMessagesClearedState conversationMessagesClearedState(
      EmptyResponse emptyResponse) {
    return ConversationMessagesClearedState(
      emptyResponse,
    );
  }

  GroupCreatedState groupCreatedState(GroupEntity groupEntity) {
    return GroupCreatedState(
      groupEntity,
    );
  }

  GroupsLoadedState groupsLoadedState(GroupsEntity groupsEntity) {
    return GroupsLoadedState(
      groupsEntity,
    );
  }

  GroupUpdatedState groupUpdatedState(GroupEntity groupEntity) {
    return GroupUpdatedState(
      groupEntity,
    );
  }

  GroupDeletedState groupDeletedState(EmptyResponse emptyResponse) {
    return GroupDeletedState(
      emptyResponse,
    );
  }

  FriendAddedToGroupState friendAddedToGroupState(EmptyResponse emptyResponse) {
    return FriendAddedToGroupState(
      emptyResponse,
    );
  }

  FriendDeletedFromGroupState friendDeletedFromGroupState(
      EmptyResponse emptyResponse) {
    return FriendDeletedFromGroupState(
      emptyResponse,
    );
  }

  GroupMessagesClearedState groupMessagesClearedState(
      EmptyResponse emptyResponse) {
    return GroupMessagesClearedState(
      emptyResponse,
    );
  }

  MessagesReadState messagesReadState(EmptyResponse emptyResponse) {
    return MessagesReadState(
      emptyResponse,
    );
  }

  MessagesErrorState messagesErrorState(
      AppErrors error, VoidCallback callback) {
    return MessagesErrorState(
      error,
      callback,
    );
  }

  MessagesReportState messagesReportState(EmptyResponse emptyResponse) {
    return MessagesReportState(
      emptyResponse,
    );
  }

  ChangeMuteSuccess changeMuteSuccess(EmptyResponse emptyResponse) {
    return ChangeMuteSuccess(
      emptyResponse,
    );
  }

  GetGroupStatusDone getGroupStatusDone(
      GetFrinedStatusEntity getFrinedStatusEntity) {
    return GetGroupStatusDone(
      getFrinedStatusEntity,
    );
  }
}

/// @nodoc
const $MessagesState = _$MessagesStateTearOff();

/// @nodoc
mixin _$MessagesState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MessagesStateCopyWith<$Res> {
  factory $MessagesStateCopyWith(
          MessagesState value, $Res Function(MessagesState) then) =
      _$MessagesStateCopyWithImpl<$Res>;
}

/// @nodoc
class _$MessagesStateCopyWithImpl<$Res>
    implements $MessagesStateCopyWith<$Res> {
  _$MessagesStateCopyWithImpl(this._value, this._then);

  final MessagesState _value;
  // ignore: unused_field
  final $Res Function(MessagesState) _then;
}

/// @nodoc
abstract class $MessagesInitStateCopyWith<$Res> {
  factory $MessagesInitStateCopyWith(
          MessagesInitState value, $Res Function(MessagesInitState) then) =
      _$MessagesInitStateCopyWithImpl<$Res>;
}

/// @nodoc
class _$MessagesInitStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $MessagesInitStateCopyWith<$Res> {
  _$MessagesInitStateCopyWithImpl(
      MessagesInitState _value, $Res Function(MessagesInitState) _then)
      : super(_value, (v) => _then(v as MessagesInitState));

  @override
  MessagesInitState get _value => super._value as MessagesInitState;
}

/// @nodoc

class _$MessagesInitState implements MessagesInitState {
  const _$MessagesInitState();

  @override
  String toString() {
    return 'MessagesState.messagesInitState()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is MessagesInitState);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return messagesInitState();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return messagesInitState?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messagesInitState != null) {
      return messagesInitState();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return messagesInitState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return messagesInitState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messagesInitState != null) {
      return messagesInitState(this);
    }
    return orElse();
  }
}

abstract class MessagesInitState implements MessagesState {
  const factory MessagesInitState() = _$MessagesInitState;
}

/// @nodoc
abstract class $MessagesLoadingStateCopyWith<$Res> {
  factory $MessagesLoadingStateCopyWith(MessagesLoadingState value,
          $Res Function(MessagesLoadingState) then) =
      _$MessagesLoadingStateCopyWithImpl<$Res>;
}

/// @nodoc
class _$MessagesLoadingStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $MessagesLoadingStateCopyWith<$Res> {
  _$MessagesLoadingStateCopyWithImpl(
      MessagesLoadingState _value, $Res Function(MessagesLoadingState) _then)
      : super(_value, (v) => _then(v as MessagesLoadingState));

  @override
  MessagesLoadingState get _value => super._value as MessagesLoadingState;
}

/// @nodoc

class _$MessagesLoadingState implements MessagesLoadingState {
  const _$MessagesLoadingState();

  @override
  String toString() {
    return 'MessagesState.messagesLoadingState()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is MessagesLoadingState);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return messagesLoadingState();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return messagesLoadingState?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messagesLoadingState != null) {
      return messagesLoadingState();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return messagesLoadingState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return messagesLoadingState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messagesLoadingState != null) {
      return messagesLoadingState(this);
    }
    return orElse();
  }
}

abstract class MessagesLoadingState implements MessagesState {
  const factory MessagesLoadingState() = _$MessagesLoadingState;
}

/// @nodoc
abstract class $ConversationsLoadedStateCopyWith<$Res> {
  factory $ConversationsLoadedStateCopyWith(ConversationsLoadedState value,
          $Res Function(ConversationsLoadedState) then) =
      _$ConversationsLoadedStateCopyWithImpl<$Res>;
  $Res call({ConversationsEntity conversationsEntity});
}

/// @nodoc
class _$ConversationsLoadedStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $ConversationsLoadedStateCopyWith<$Res> {
  _$ConversationsLoadedStateCopyWithImpl(ConversationsLoadedState _value,
      $Res Function(ConversationsLoadedState) _then)
      : super(_value, (v) => _then(v as ConversationsLoadedState));

  @override
  ConversationsLoadedState get _value =>
      super._value as ConversationsLoadedState;

  @override
  $Res call({
    Object? conversationsEntity = freezed,
  }) {
    return _then(ConversationsLoadedState(
      conversationsEntity == freezed
          ? _value.conversationsEntity
          : conversationsEntity // ignore: cast_nullable_to_non_nullable
              as ConversationsEntity,
    ));
  }
}

/// @nodoc

class _$ConversationsLoadedState implements ConversationsLoadedState {
  const _$ConversationsLoadedState(this.conversationsEntity);

  @override
  final ConversationsEntity conversationsEntity;

  @override
  String toString() {
    return 'MessagesState.conversationsLoadedState(conversationsEntity: $conversationsEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is ConversationsLoadedState &&
            const DeepCollectionEquality()
                .equals(other.conversationsEntity, conversationsEntity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(conversationsEntity));

  @JsonKey(ignore: true)
  @override
  $ConversationsLoadedStateCopyWith<ConversationsLoadedState> get copyWith =>
      _$ConversationsLoadedStateCopyWithImpl<ConversationsLoadedState>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return conversationsLoadedState(conversationsEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return conversationsLoadedState?.call(conversationsEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (conversationsLoadedState != null) {
      return conversationsLoadedState(conversationsEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return conversationsLoadedState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return conversationsLoadedState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (conversationsLoadedState != null) {
      return conversationsLoadedState(this);
    }
    return orElse();
  }
}

abstract class ConversationsLoadedState implements MessagesState {
  const factory ConversationsLoadedState(
      ConversationsEntity conversationsEntity) = _$ConversationsLoadedState;

  ConversationsEntity get conversationsEntity;
  @JsonKey(ignore: true)
  $ConversationsLoadedStateCopyWith<ConversationsLoadedState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MessageCreatedStateCopyWith<$Res> {
  factory $MessageCreatedStateCopyWith(
          MessageCreatedState value, $Res Function(MessageCreatedState) then) =
      _$MessageCreatedStateCopyWithImpl<$Res>;
  $Res call({EmptyResponse emptyResponse});
}

/// @nodoc
class _$MessageCreatedStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $MessageCreatedStateCopyWith<$Res> {
  _$MessageCreatedStateCopyWithImpl(
      MessageCreatedState _value, $Res Function(MessageCreatedState) _then)
      : super(_value, (v) => _then(v as MessageCreatedState));

  @override
  MessageCreatedState get _value => super._value as MessageCreatedState;

  @override
  $Res call({
    Object? emptyResponse = freezed,
  }) {
    return _then(MessageCreatedState(
      emptyResponse == freezed
          ? _value.emptyResponse
          : emptyResponse // ignore: cast_nullable_to_non_nullable
              as EmptyResponse,
    ));
  }
}

/// @nodoc

class _$MessageCreatedState implements MessageCreatedState {
  const _$MessageCreatedState(this.emptyResponse);

  @override
  final EmptyResponse emptyResponse;

  @override
  String toString() {
    return 'MessagesState.messageCreatedState(emptyResponse: $emptyResponse)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is MessageCreatedState &&
            const DeepCollectionEquality()
                .equals(other.emptyResponse, emptyResponse));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(emptyResponse));

  @JsonKey(ignore: true)
  @override
  $MessageCreatedStateCopyWith<MessageCreatedState> get copyWith =>
      _$MessageCreatedStateCopyWithImpl<MessageCreatedState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return messageCreatedState(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return messageCreatedState?.call(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messageCreatedState != null) {
      return messageCreatedState(emptyResponse);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return messageCreatedState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return messageCreatedState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messageCreatedState != null) {
      return messageCreatedState(this);
    }
    return orElse();
  }
}

abstract class MessageCreatedState implements MessagesState {
  const factory MessageCreatedState(EmptyResponse emptyResponse) =
      _$MessageCreatedState;

  EmptyResponse get emptyResponse;
  @JsonKey(ignore: true)
  $MessageCreatedStateCopyWith<MessageCreatedState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MessageBroadCastCreatedStateCopyWith<$Res> {
  factory $MessageBroadCastCreatedStateCopyWith(
          MessageBroadCastCreatedState value,
          $Res Function(MessageBroadCastCreatedState) then) =
      _$MessageBroadCastCreatedStateCopyWithImpl<$Res>;
  $Res call({EmptyResponse emptyResponse});
}

/// @nodoc
class _$MessageBroadCastCreatedStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $MessageBroadCastCreatedStateCopyWith<$Res> {
  _$MessageBroadCastCreatedStateCopyWithImpl(
      MessageBroadCastCreatedState _value,
      $Res Function(MessageBroadCastCreatedState) _then)
      : super(_value, (v) => _then(v as MessageBroadCastCreatedState));

  @override
  MessageBroadCastCreatedState get _value =>
      super._value as MessageBroadCastCreatedState;

  @override
  $Res call({
    Object? emptyResponse = freezed,
  }) {
    return _then(MessageBroadCastCreatedState(
      emptyResponse == freezed
          ? _value.emptyResponse
          : emptyResponse // ignore: cast_nullable_to_non_nullable
              as EmptyResponse,
    ));
  }
}

/// @nodoc

class _$MessageBroadCastCreatedState implements MessageBroadCastCreatedState {
  const _$MessageBroadCastCreatedState(this.emptyResponse);

  @override
  final EmptyResponse emptyResponse;

  @override
  String toString() {
    return 'MessagesState.messageBroadCastCreatedState(emptyResponse: $emptyResponse)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is MessageBroadCastCreatedState &&
            const DeepCollectionEquality()
                .equals(other.emptyResponse, emptyResponse));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(emptyResponse));

  @JsonKey(ignore: true)
  @override
  $MessageBroadCastCreatedStateCopyWith<MessageBroadCastCreatedState>
      get copyWith => _$MessageBroadCastCreatedStateCopyWithImpl<
          MessageBroadCastCreatedState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return messageBroadCastCreatedState(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return messageBroadCastCreatedState?.call(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messageBroadCastCreatedState != null) {
      return messageBroadCastCreatedState(emptyResponse);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return messageBroadCastCreatedState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return messageBroadCastCreatedState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messageBroadCastCreatedState != null) {
      return messageBroadCastCreatedState(this);
    }
    return orElse();
  }
}

abstract class MessageBroadCastCreatedState implements MessagesState {
  const factory MessageBroadCastCreatedState(EmptyResponse emptyResponse) =
      _$MessageBroadCastCreatedState;

  EmptyResponse get emptyResponse;
  @JsonKey(ignore: true)
  $MessageBroadCastCreatedStateCopyWith<MessageBroadCastCreatedState>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MessagesLoadedStateCopyWith<$Res> {
  factory $MessagesLoadedStateCopyWith(
          MessagesLoadedState value, $Res Function(MessagesLoadedState) then) =
      _$MessagesLoadedStateCopyWithImpl<$Res>;
  $Res call({MessagesEntity messagesEntity});
}

/// @nodoc
class _$MessagesLoadedStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $MessagesLoadedStateCopyWith<$Res> {
  _$MessagesLoadedStateCopyWithImpl(
      MessagesLoadedState _value, $Res Function(MessagesLoadedState) _then)
      : super(_value, (v) => _then(v as MessagesLoadedState));

  @override
  MessagesLoadedState get _value => super._value as MessagesLoadedState;

  @override
  $Res call({
    Object? messagesEntity = freezed,
  }) {
    return _then(MessagesLoadedState(
      messagesEntity == freezed
          ? _value.messagesEntity
          : messagesEntity // ignore: cast_nullable_to_non_nullable
              as MessagesEntity,
    ));
  }
}

/// @nodoc

class _$MessagesLoadedState implements MessagesLoadedState {
  const _$MessagesLoadedState(this.messagesEntity);

  @override
  final MessagesEntity messagesEntity;

  @override
  String toString() {
    return 'MessagesState.messagesLoadedState(messagesEntity: $messagesEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is MessagesLoadedState &&
            const DeepCollectionEquality()
                .equals(other.messagesEntity, messagesEntity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(messagesEntity));

  @JsonKey(ignore: true)
  @override
  $MessagesLoadedStateCopyWith<MessagesLoadedState> get copyWith =>
      _$MessagesLoadedStateCopyWithImpl<MessagesLoadedState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return messagesLoadedState(messagesEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return messagesLoadedState?.call(messagesEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messagesLoadedState != null) {
      return messagesLoadedState(messagesEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return messagesLoadedState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return messagesLoadedState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messagesLoadedState != null) {
      return messagesLoadedState(this);
    }
    return orElse();
  }
}

abstract class MessagesLoadedState implements MessagesState {
  const factory MessagesLoadedState(MessagesEntity messagesEntity) =
      _$MessagesLoadedState;

  MessagesEntity get messagesEntity;
  @JsonKey(ignore: true)
  $MessagesLoadedStateCopyWith<MessagesLoadedState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TokenLoadedStateCopyWith<$Res> {
  factory $TokenLoadedStateCopyWith(
          TokenLoadedState value, $Res Function(TokenLoadedState) then) =
      _$TokenLoadedStateCopyWithImpl<$Res>;
  $Res call({TokenEntity tokenEntity});
}

/// @nodoc
class _$TokenLoadedStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $TokenLoadedStateCopyWith<$Res> {
  _$TokenLoadedStateCopyWithImpl(
      TokenLoadedState _value, $Res Function(TokenLoadedState) _then)
      : super(_value, (v) => _then(v as TokenLoadedState));

  @override
  TokenLoadedState get _value => super._value as TokenLoadedState;

  @override
  $Res call({
    Object? tokenEntity = freezed,
  }) {
    return _then(TokenLoadedState(
      tokenEntity == freezed
          ? _value.tokenEntity
          : tokenEntity // ignore: cast_nullable_to_non_nullable
              as TokenEntity,
    ));
  }
}

/// @nodoc

class _$TokenLoadedState implements TokenLoadedState {
  const _$TokenLoadedState(this.tokenEntity);

  @override
  final TokenEntity tokenEntity;

  @override
  String toString() {
    return 'MessagesState.tokenLoadedState(tokenEntity: $tokenEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is TokenLoadedState &&
            const DeepCollectionEquality()
                .equals(other.tokenEntity, tokenEntity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(tokenEntity));

  @JsonKey(ignore: true)
  @override
  $TokenLoadedStateCopyWith<TokenLoadedState> get copyWith =>
      _$TokenLoadedStateCopyWithImpl<TokenLoadedState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return tokenLoadedState(tokenEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return tokenLoadedState?.call(tokenEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (tokenLoadedState != null) {
      return tokenLoadedState(tokenEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return tokenLoadedState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return tokenLoadedState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (tokenLoadedState != null) {
      return tokenLoadedState(this);
    }
    return orElse();
  }
}

abstract class TokenLoadedState implements MessagesState {
  const factory TokenLoadedState(TokenEntity tokenEntity) = _$TokenLoadedState;

  TokenEntity get tokenEntity;
  @JsonKey(ignore: true)
  $TokenLoadedStateCopyWith<TokenLoadedState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TokenRtmLoadedStateCopyWith<$Res> {
  factory $TokenRtmLoadedStateCopyWith(
          TokenRtmLoadedState value, $Res Function(TokenRtmLoadedState) then) =
      _$TokenRtmLoadedStateCopyWithImpl<$Res>;
  $Res call({TokenRtmEntity tokenRtmEntity});
}

/// @nodoc
class _$TokenRtmLoadedStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $TokenRtmLoadedStateCopyWith<$Res> {
  _$TokenRtmLoadedStateCopyWithImpl(
      TokenRtmLoadedState _value, $Res Function(TokenRtmLoadedState) _then)
      : super(_value, (v) => _then(v as TokenRtmLoadedState));

  @override
  TokenRtmLoadedState get _value => super._value as TokenRtmLoadedState;

  @override
  $Res call({
    Object? tokenRtmEntity = freezed,
  }) {
    return _then(TokenRtmLoadedState(
      tokenRtmEntity == freezed
          ? _value.tokenRtmEntity
          : tokenRtmEntity // ignore: cast_nullable_to_non_nullable
              as TokenRtmEntity,
    ));
  }
}

/// @nodoc

class _$TokenRtmLoadedState implements TokenRtmLoadedState {
  const _$TokenRtmLoadedState(this.tokenRtmEntity);

  @override
  final TokenRtmEntity tokenRtmEntity;

  @override
  String toString() {
    return 'MessagesState.tokenRtmLoadedState(tokenRtmEntity: $tokenRtmEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is TokenRtmLoadedState &&
            const DeepCollectionEquality()
                .equals(other.tokenRtmEntity, tokenRtmEntity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(tokenRtmEntity));

  @JsonKey(ignore: true)
  @override
  $TokenRtmLoadedStateCopyWith<TokenRtmLoadedState> get copyWith =>
      _$TokenRtmLoadedStateCopyWithImpl<TokenRtmLoadedState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return tokenRtmLoadedState(tokenRtmEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return tokenRtmLoadedState?.call(tokenRtmEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (tokenRtmLoadedState != null) {
      return tokenRtmLoadedState(tokenRtmEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return tokenRtmLoadedState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return tokenRtmLoadedState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (tokenRtmLoadedState != null) {
      return tokenRtmLoadedState(this);
    }
    return orElse();
  }
}

abstract class TokenRtmLoadedState implements MessagesState {
  const factory TokenRtmLoadedState(TokenRtmEntity tokenRtmEntity) =
      _$TokenRtmLoadedState;

  TokenRtmEntity get tokenRtmEntity;
  @JsonKey(ignore: true)
  $TokenRtmLoadedStateCopyWith<TokenRtmLoadedState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ConversationMessagesClearedStateCopyWith<$Res> {
  factory $ConversationMessagesClearedStateCopyWith(
          ConversationMessagesClearedState value,
          $Res Function(ConversationMessagesClearedState) then) =
      _$ConversationMessagesClearedStateCopyWithImpl<$Res>;
  $Res call({EmptyResponse emptyResponse});
}

/// @nodoc
class _$ConversationMessagesClearedStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $ConversationMessagesClearedStateCopyWith<$Res> {
  _$ConversationMessagesClearedStateCopyWithImpl(
      ConversationMessagesClearedState _value,
      $Res Function(ConversationMessagesClearedState) _then)
      : super(_value, (v) => _then(v as ConversationMessagesClearedState));

  @override
  ConversationMessagesClearedState get _value =>
      super._value as ConversationMessagesClearedState;

  @override
  $Res call({
    Object? emptyResponse = freezed,
  }) {
    return _then(ConversationMessagesClearedState(
      emptyResponse == freezed
          ? _value.emptyResponse
          : emptyResponse // ignore: cast_nullable_to_non_nullable
              as EmptyResponse,
    ));
  }
}

/// @nodoc

class _$ConversationMessagesClearedState
    implements ConversationMessagesClearedState {
  const _$ConversationMessagesClearedState(this.emptyResponse);

  @override
  final EmptyResponse emptyResponse;

  @override
  String toString() {
    return 'MessagesState.conversationMessagesClearedState(emptyResponse: $emptyResponse)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is ConversationMessagesClearedState &&
            const DeepCollectionEquality()
                .equals(other.emptyResponse, emptyResponse));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(emptyResponse));

  @JsonKey(ignore: true)
  @override
  $ConversationMessagesClearedStateCopyWith<ConversationMessagesClearedState>
      get copyWith => _$ConversationMessagesClearedStateCopyWithImpl<
          ConversationMessagesClearedState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return conversationMessagesClearedState(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return conversationMessagesClearedState?.call(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (conversationMessagesClearedState != null) {
      return conversationMessagesClearedState(emptyResponse);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return conversationMessagesClearedState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return conversationMessagesClearedState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (conversationMessagesClearedState != null) {
      return conversationMessagesClearedState(this);
    }
    return orElse();
  }
}

abstract class ConversationMessagesClearedState implements MessagesState {
  const factory ConversationMessagesClearedState(EmptyResponse emptyResponse) =
      _$ConversationMessagesClearedState;

  EmptyResponse get emptyResponse;
  @JsonKey(ignore: true)
  $ConversationMessagesClearedStateCopyWith<ConversationMessagesClearedState>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GroupCreatedStateCopyWith<$Res> {
  factory $GroupCreatedStateCopyWith(
          GroupCreatedState value, $Res Function(GroupCreatedState) then) =
      _$GroupCreatedStateCopyWithImpl<$Res>;
  $Res call({GroupEntity groupEntity});
}

/// @nodoc
class _$GroupCreatedStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $GroupCreatedStateCopyWith<$Res> {
  _$GroupCreatedStateCopyWithImpl(
      GroupCreatedState _value, $Res Function(GroupCreatedState) _then)
      : super(_value, (v) => _then(v as GroupCreatedState));

  @override
  GroupCreatedState get _value => super._value as GroupCreatedState;

  @override
  $Res call({
    Object? groupEntity = freezed,
  }) {
    return _then(GroupCreatedState(
      groupEntity == freezed
          ? _value.groupEntity
          : groupEntity // ignore: cast_nullable_to_non_nullable
              as GroupEntity,
    ));
  }
}

/// @nodoc

class _$GroupCreatedState implements GroupCreatedState {
  const _$GroupCreatedState(this.groupEntity);

  @override
  final GroupEntity groupEntity;

  @override
  String toString() {
    return 'MessagesState.groupCreatedState(groupEntity: $groupEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is GroupCreatedState &&
            const DeepCollectionEquality()
                .equals(other.groupEntity, groupEntity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(groupEntity));

  @JsonKey(ignore: true)
  @override
  $GroupCreatedStateCopyWith<GroupCreatedState> get copyWith =>
      _$GroupCreatedStateCopyWithImpl<GroupCreatedState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return groupCreatedState(groupEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return groupCreatedState?.call(groupEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (groupCreatedState != null) {
      return groupCreatedState(groupEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return groupCreatedState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return groupCreatedState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (groupCreatedState != null) {
      return groupCreatedState(this);
    }
    return orElse();
  }
}

abstract class GroupCreatedState implements MessagesState {
  const factory GroupCreatedState(GroupEntity groupEntity) =
      _$GroupCreatedState;

  GroupEntity get groupEntity;
  @JsonKey(ignore: true)
  $GroupCreatedStateCopyWith<GroupCreatedState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GroupsLoadedStateCopyWith<$Res> {
  factory $GroupsLoadedStateCopyWith(
          GroupsLoadedState value, $Res Function(GroupsLoadedState) then) =
      _$GroupsLoadedStateCopyWithImpl<$Res>;
  $Res call({GroupsEntity groupsEntity});
}

/// @nodoc
class _$GroupsLoadedStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $GroupsLoadedStateCopyWith<$Res> {
  _$GroupsLoadedStateCopyWithImpl(
      GroupsLoadedState _value, $Res Function(GroupsLoadedState) _then)
      : super(_value, (v) => _then(v as GroupsLoadedState));

  @override
  GroupsLoadedState get _value => super._value as GroupsLoadedState;

  @override
  $Res call({
    Object? groupsEntity = freezed,
  }) {
    return _then(GroupsLoadedState(
      groupsEntity == freezed
          ? _value.groupsEntity
          : groupsEntity // ignore: cast_nullable_to_non_nullable
              as GroupsEntity,
    ));
  }
}

/// @nodoc

class _$GroupsLoadedState implements GroupsLoadedState {
  const _$GroupsLoadedState(this.groupsEntity);

  @override
  final GroupsEntity groupsEntity;

  @override
  String toString() {
    return 'MessagesState.groupsLoadedState(groupsEntity: $groupsEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is GroupsLoadedState &&
            const DeepCollectionEquality()
                .equals(other.groupsEntity, groupsEntity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(groupsEntity));

  @JsonKey(ignore: true)
  @override
  $GroupsLoadedStateCopyWith<GroupsLoadedState> get copyWith =>
      _$GroupsLoadedStateCopyWithImpl<GroupsLoadedState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return groupsLoadedState(groupsEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return groupsLoadedState?.call(groupsEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (groupsLoadedState != null) {
      return groupsLoadedState(groupsEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return groupsLoadedState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return groupsLoadedState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (groupsLoadedState != null) {
      return groupsLoadedState(this);
    }
    return orElse();
  }
}

abstract class GroupsLoadedState implements MessagesState {
  const factory GroupsLoadedState(GroupsEntity groupsEntity) =
      _$GroupsLoadedState;

  GroupsEntity get groupsEntity;
  @JsonKey(ignore: true)
  $GroupsLoadedStateCopyWith<GroupsLoadedState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GroupUpdatedStateCopyWith<$Res> {
  factory $GroupUpdatedStateCopyWith(
          GroupUpdatedState value, $Res Function(GroupUpdatedState) then) =
      _$GroupUpdatedStateCopyWithImpl<$Res>;
  $Res call({GroupEntity groupEntity});
}

/// @nodoc
class _$GroupUpdatedStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $GroupUpdatedStateCopyWith<$Res> {
  _$GroupUpdatedStateCopyWithImpl(
      GroupUpdatedState _value, $Res Function(GroupUpdatedState) _then)
      : super(_value, (v) => _then(v as GroupUpdatedState));

  @override
  GroupUpdatedState get _value => super._value as GroupUpdatedState;

  @override
  $Res call({
    Object? groupEntity = freezed,
  }) {
    return _then(GroupUpdatedState(
      groupEntity == freezed
          ? _value.groupEntity
          : groupEntity // ignore: cast_nullable_to_non_nullable
              as GroupEntity,
    ));
  }
}

/// @nodoc

class _$GroupUpdatedState implements GroupUpdatedState {
  const _$GroupUpdatedState(this.groupEntity);

  @override
  final GroupEntity groupEntity;

  @override
  String toString() {
    return 'MessagesState.groupUpdatedState(groupEntity: $groupEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is GroupUpdatedState &&
            const DeepCollectionEquality()
                .equals(other.groupEntity, groupEntity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(groupEntity));

  @JsonKey(ignore: true)
  @override
  $GroupUpdatedStateCopyWith<GroupUpdatedState> get copyWith =>
      _$GroupUpdatedStateCopyWithImpl<GroupUpdatedState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return groupUpdatedState(groupEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return groupUpdatedState?.call(groupEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (groupUpdatedState != null) {
      return groupUpdatedState(groupEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return groupUpdatedState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return groupUpdatedState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (groupUpdatedState != null) {
      return groupUpdatedState(this);
    }
    return orElse();
  }
}

abstract class GroupUpdatedState implements MessagesState {
  const factory GroupUpdatedState(GroupEntity groupEntity) =
      _$GroupUpdatedState;

  GroupEntity get groupEntity;
  @JsonKey(ignore: true)
  $GroupUpdatedStateCopyWith<GroupUpdatedState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GroupDeletedStateCopyWith<$Res> {
  factory $GroupDeletedStateCopyWith(
          GroupDeletedState value, $Res Function(GroupDeletedState) then) =
      _$GroupDeletedStateCopyWithImpl<$Res>;
  $Res call({EmptyResponse emptyResponse});
}

/// @nodoc
class _$GroupDeletedStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $GroupDeletedStateCopyWith<$Res> {
  _$GroupDeletedStateCopyWithImpl(
      GroupDeletedState _value, $Res Function(GroupDeletedState) _then)
      : super(_value, (v) => _then(v as GroupDeletedState));

  @override
  GroupDeletedState get _value => super._value as GroupDeletedState;

  @override
  $Res call({
    Object? emptyResponse = freezed,
  }) {
    return _then(GroupDeletedState(
      emptyResponse == freezed
          ? _value.emptyResponse
          : emptyResponse // ignore: cast_nullable_to_non_nullable
              as EmptyResponse,
    ));
  }
}

/// @nodoc

class _$GroupDeletedState implements GroupDeletedState {
  const _$GroupDeletedState(this.emptyResponse);

  @override
  final EmptyResponse emptyResponse;

  @override
  String toString() {
    return 'MessagesState.groupDeletedState(emptyResponse: $emptyResponse)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is GroupDeletedState &&
            const DeepCollectionEquality()
                .equals(other.emptyResponse, emptyResponse));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(emptyResponse));

  @JsonKey(ignore: true)
  @override
  $GroupDeletedStateCopyWith<GroupDeletedState> get copyWith =>
      _$GroupDeletedStateCopyWithImpl<GroupDeletedState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return groupDeletedState(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return groupDeletedState?.call(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (groupDeletedState != null) {
      return groupDeletedState(emptyResponse);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return groupDeletedState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return groupDeletedState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (groupDeletedState != null) {
      return groupDeletedState(this);
    }
    return orElse();
  }
}

abstract class GroupDeletedState implements MessagesState {
  const factory GroupDeletedState(EmptyResponse emptyResponse) =
      _$GroupDeletedState;

  EmptyResponse get emptyResponse;
  @JsonKey(ignore: true)
  $GroupDeletedStateCopyWith<GroupDeletedState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FriendAddedToGroupStateCopyWith<$Res> {
  factory $FriendAddedToGroupStateCopyWith(FriendAddedToGroupState value,
          $Res Function(FriendAddedToGroupState) then) =
      _$FriendAddedToGroupStateCopyWithImpl<$Res>;
  $Res call({EmptyResponse emptyResponse});
}

/// @nodoc
class _$FriendAddedToGroupStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $FriendAddedToGroupStateCopyWith<$Res> {
  _$FriendAddedToGroupStateCopyWithImpl(FriendAddedToGroupState _value,
      $Res Function(FriendAddedToGroupState) _then)
      : super(_value, (v) => _then(v as FriendAddedToGroupState));

  @override
  FriendAddedToGroupState get _value => super._value as FriendAddedToGroupState;

  @override
  $Res call({
    Object? emptyResponse = freezed,
  }) {
    return _then(FriendAddedToGroupState(
      emptyResponse == freezed
          ? _value.emptyResponse
          : emptyResponse // ignore: cast_nullable_to_non_nullable
              as EmptyResponse,
    ));
  }
}

/// @nodoc

class _$FriendAddedToGroupState implements FriendAddedToGroupState {
  const _$FriendAddedToGroupState(this.emptyResponse);

  @override
  final EmptyResponse emptyResponse;

  @override
  String toString() {
    return 'MessagesState.friendAddedToGroupState(emptyResponse: $emptyResponse)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is FriendAddedToGroupState &&
            const DeepCollectionEquality()
                .equals(other.emptyResponse, emptyResponse));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(emptyResponse));

  @JsonKey(ignore: true)
  @override
  $FriendAddedToGroupStateCopyWith<FriendAddedToGroupState> get copyWith =>
      _$FriendAddedToGroupStateCopyWithImpl<FriendAddedToGroupState>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return friendAddedToGroupState(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return friendAddedToGroupState?.call(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (friendAddedToGroupState != null) {
      return friendAddedToGroupState(emptyResponse);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return friendAddedToGroupState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return friendAddedToGroupState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (friendAddedToGroupState != null) {
      return friendAddedToGroupState(this);
    }
    return orElse();
  }
}

abstract class FriendAddedToGroupState implements MessagesState {
  const factory FriendAddedToGroupState(EmptyResponse emptyResponse) =
      _$FriendAddedToGroupState;

  EmptyResponse get emptyResponse;
  @JsonKey(ignore: true)
  $FriendAddedToGroupStateCopyWith<FriendAddedToGroupState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FriendDeletedFromGroupStateCopyWith<$Res> {
  factory $FriendDeletedFromGroupStateCopyWith(
          FriendDeletedFromGroupState value,
          $Res Function(FriendDeletedFromGroupState) then) =
      _$FriendDeletedFromGroupStateCopyWithImpl<$Res>;
  $Res call({EmptyResponse emptyResponse});
}

/// @nodoc
class _$FriendDeletedFromGroupStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $FriendDeletedFromGroupStateCopyWith<$Res> {
  _$FriendDeletedFromGroupStateCopyWithImpl(FriendDeletedFromGroupState _value,
      $Res Function(FriendDeletedFromGroupState) _then)
      : super(_value, (v) => _then(v as FriendDeletedFromGroupState));

  @override
  FriendDeletedFromGroupState get _value =>
      super._value as FriendDeletedFromGroupState;

  @override
  $Res call({
    Object? emptyResponse = freezed,
  }) {
    return _then(FriendDeletedFromGroupState(
      emptyResponse == freezed
          ? _value.emptyResponse
          : emptyResponse // ignore: cast_nullable_to_non_nullable
              as EmptyResponse,
    ));
  }
}

/// @nodoc

class _$FriendDeletedFromGroupState implements FriendDeletedFromGroupState {
  const _$FriendDeletedFromGroupState(this.emptyResponse);

  @override
  final EmptyResponse emptyResponse;

  @override
  String toString() {
    return 'MessagesState.friendDeletedFromGroupState(emptyResponse: $emptyResponse)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is FriendDeletedFromGroupState &&
            const DeepCollectionEquality()
                .equals(other.emptyResponse, emptyResponse));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(emptyResponse));

  @JsonKey(ignore: true)
  @override
  $FriendDeletedFromGroupStateCopyWith<FriendDeletedFromGroupState>
      get copyWith => _$FriendDeletedFromGroupStateCopyWithImpl<
          FriendDeletedFromGroupState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return friendDeletedFromGroupState(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return friendDeletedFromGroupState?.call(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (friendDeletedFromGroupState != null) {
      return friendDeletedFromGroupState(emptyResponse);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return friendDeletedFromGroupState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return friendDeletedFromGroupState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (friendDeletedFromGroupState != null) {
      return friendDeletedFromGroupState(this);
    }
    return orElse();
  }
}

abstract class FriendDeletedFromGroupState implements MessagesState {
  const factory FriendDeletedFromGroupState(EmptyResponse emptyResponse) =
      _$FriendDeletedFromGroupState;

  EmptyResponse get emptyResponse;
  @JsonKey(ignore: true)
  $FriendDeletedFromGroupStateCopyWith<FriendDeletedFromGroupState>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GroupMessagesClearedStateCopyWith<$Res> {
  factory $GroupMessagesClearedStateCopyWith(GroupMessagesClearedState value,
          $Res Function(GroupMessagesClearedState) then) =
      _$GroupMessagesClearedStateCopyWithImpl<$Res>;
  $Res call({EmptyResponse emptyResponse});
}

/// @nodoc
class _$GroupMessagesClearedStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $GroupMessagesClearedStateCopyWith<$Res> {
  _$GroupMessagesClearedStateCopyWithImpl(GroupMessagesClearedState _value,
      $Res Function(GroupMessagesClearedState) _then)
      : super(_value, (v) => _then(v as GroupMessagesClearedState));

  @override
  GroupMessagesClearedState get _value =>
      super._value as GroupMessagesClearedState;

  @override
  $Res call({
    Object? emptyResponse = freezed,
  }) {
    return _then(GroupMessagesClearedState(
      emptyResponse == freezed
          ? _value.emptyResponse
          : emptyResponse // ignore: cast_nullable_to_non_nullable
              as EmptyResponse,
    ));
  }
}

/// @nodoc

class _$GroupMessagesClearedState implements GroupMessagesClearedState {
  const _$GroupMessagesClearedState(this.emptyResponse);

  @override
  final EmptyResponse emptyResponse;

  @override
  String toString() {
    return 'MessagesState.groupMessagesClearedState(emptyResponse: $emptyResponse)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is GroupMessagesClearedState &&
            const DeepCollectionEquality()
                .equals(other.emptyResponse, emptyResponse));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(emptyResponse));

  @JsonKey(ignore: true)
  @override
  $GroupMessagesClearedStateCopyWith<GroupMessagesClearedState> get copyWith =>
      _$GroupMessagesClearedStateCopyWithImpl<GroupMessagesClearedState>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return groupMessagesClearedState(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return groupMessagesClearedState?.call(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (groupMessagesClearedState != null) {
      return groupMessagesClearedState(emptyResponse);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return groupMessagesClearedState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return groupMessagesClearedState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (groupMessagesClearedState != null) {
      return groupMessagesClearedState(this);
    }
    return orElse();
  }
}

abstract class GroupMessagesClearedState implements MessagesState {
  const factory GroupMessagesClearedState(EmptyResponse emptyResponse) =
      _$GroupMessagesClearedState;

  EmptyResponse get emptyResponse;
  @JsonKey(ignore: true)
  $GroupMessagesClearedStateCopyWith<GroupMessagesClearedState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MessagesReadStateCopyWith<$Res> {
  factory $MessagesReadStateCopyWith(
          MessagesReadState value, $Res Function(MessagesReadState) then) =
      _$MessagesReadStateCopyWithImpl<$Res>;
  $Res call({EmptyResponse emptyResponse});
}

/// @nodoc
class _$MessagesReadStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $MessagesReadStateCopyWith<$Res> {
  _$MessagesReadStateCopyWithImpl(
      MessagesReadState _value, $Res Function(MessagesReadState) _then)
      : super(_value, (v) => _then(v as MessagesReadState));

  @override
  MessagesReadState get _value => super._value as MessagesReadState;

  @override
  $Res call({
    Object? emptyResponse = freezed,
  }) {
    return _then(MessagesReadState(
      emptyResponse == freezed
          ? _value.emptyResponse
          : emptyResponse // ignore: cast_nullable_to_non_nullable
              as EmptyResponse,
    ));
  }
}

/// @nodoc

class _$MessagesReadState implements MessagesReadState {
  const _$MessagesReadState(this.emptyResponse);

  @override
  final EmptyResponse emptyResponse;

  @override
  String toString() {
    return 'MessagesState.messagesReadState(emptyResponse: $emptyResponse)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is MessagesReadState &&
            const DeepCollectionEquality()
                .equals(other.emptyResponse, emptyResponse));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(emptyResponse));

  @JsonKey(ignore: true)
  @override
  $MessagesReadStateCopyWith<MessagesReadState> get copyWith =>
      _$MessagesReadStateCopyWithImpl<MessagesReadState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return messagesReadState(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return messagesReadState?.call(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messagesReadState != null) {
      return messagesReadState(emptyResponse);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return messagesReadState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return messagesReadState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messagesReadState != null) {
      return messagesReadState(this);
    }
    return orElse();
  }
}

abstract class MessagesReadState implements MessagesState {
  const factory MessagesReadState(EmptyResponse emptyResponse) =
      _$MessagesReadState;

  EmptyResponse get emptyResponse;
  @JsonKey(ignore: true)
  $MessagesReadStateCopyWith<MessagesReadState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MessagesErrorStateCopyWith<$Res> {
  factory $MessagesErrorStateCopyWith(
          MessagesErrorState value, $Res Function(MessagesErrorState) then) =
      _$MessagesErrorStateCopyWithImpl<$Res>;
  $Res call({AppErrors error, VoidCallback callback});

  $AppErrorsCopyWith<$Res> get error;
}

/// @nodoc
class _$MessagesErrorStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $MessagesErrorStateCopyWith<$Res> {
  _$MessagesErrorStateCopyWithImpl(
      MessagesErrorState _value, $Res Function(MessagesErrorState) _then)
      : super(_value, (v) => _then(v as MessagesErrorState));

  @override
  MessagesErrorState get _value => super._value as MessagesErrorState;

  @override
  $Res call({
    Object? error = freezed,
    Object? callback = freezed,
  }) {
    return _then(MessagesErrorState(
      error == freezed
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as AppErrors,
      callback == freezed
          ? _value.callback
          : callback // ignore: cast_nullable_to_non_nullable
              as VoidCallback,
    ));
  }

  @override
  $AppErrorsCopyWith<$Res> get error {
    return $AppErrorsCopyWith<$Res>(_value.error, (value) {
      return _then(_value.copyWith(error: value));
    });
  }
}

/// @nodoc

class _$MessagesErrorState implements MessagesErrorState {
  const _$MessagesErrorState(this.error, this.callback);

  @override
  final AppErrors error;
  @override
  final VoidCallback callback;

  @override
  String toString() {
    return 'MessagesState.messagesErrorState(error: $error, callback: $callback)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is MessagesErrorState &&
            const DeepCollectionEquality().equals(other.error, error) &&
            (identical(other.callback, callback) ||
                other.callback == callback));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(error), callback);

  @JsonKey(ignore: true)
  @override
  $MessagesErrorStateCopyWith<MessagesErrorState> get copyWith =>
      _$MessagesErrorStateCopyWithImpl<MessagesErrorState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return messagesErrorState(error, callback);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return messagesErrorState?.call(error, callback);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messagesErrorState != null) {
      return messagesErrorState(error, callback);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return messagesErrorState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return messagesErrorState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messagesErrorState != null) {
      return messagesErrorState(this);
    }
    return orElse();
  }
}

abstract class MessagesErrorState implements MessagesState {
  const factory MessagesErrorState(AppErrors error, VoidCallback callback) =
      _$MessagesErrorState;

  AppErrors get error;
  VoidCallback get callback;
  @JsonKey(ignore: true)
  $MessagesErrorStateCopyWith<MessagesErrorState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MessagesReportStateCopyWith<$Res> {
  factory $MessagesReportStateCopyWith(
          MessagesReportState value, $Res Function(MessagesReportState) then) =
      _$MessagesReportStateCopyWithImpl<$Res>;
  $Res call({EmptyResponse emptyResponse});
}

/// @nodoc
class _$MessagesReportStateCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $MessagesReportStateCopyWith<$Res> {
  _$MessagesReportStateCopyWithImpl(
      MessagesReportState _value, $Res Function(MessagesReportState) _then)
      : super(_value, (v) => _then(v as MessagesReportState));

  @override
  MessagesReportState get _value => super._value as MessagesReportState;

  @override
  $Res call({
    Object? emptyResponse = freezed,
  }) {
    return _then(MessagesReportState(
      emptyResponse == freezed
          ? _value.emptyResponse
          : emptyResponse // ignore: cast_nullable_to_non_nullable
              as EmptyResponse,
    ));
  }
}

/// @nodoc

class _$MessagesReportState implements MessagesReportState {
  const _$MessagesReportState(this.emptyResponse);

  @override
  final EmptyResponse emptyResponse;

  @override
  String toString() {
    return 'MessagesState.messagesReportState(emptyResponse: $emptyResponse)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is MessagesReportState &&
            const DeepCollectionEquality()
                .equals(other.emptyResponse, emptyResponse));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(emptyResponse));

  @JsonKey(ignore: true)
  @override
  $MessagesReportStateCopyWith<MessagesReportState> get copyWith =>
      _$MessagesReportStateCopyWithImpl<MessagesReportState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return messagesReportState(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return messagesReportState?.call(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messagesReportState != null) {
      return messagesReportState(emptyResponse);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return messagesReportState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return messagesReportState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (messagesReportState != null) {
      return messagesReportState(this);
    }
    return orElse();
  }
}

abstract class MessagesReportState implements MessagesState {
  const factory MessagesReportState(EmptyResponse emptyResponse) =
      _$MessagesReportState;

  EmptyResponse get emptyResponse;
  @JsonKey(ignore: true)
  $MessagesReportStateCopyWith<MessagesReportState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ChangeMuteSuccessCopyWith<$Res> {
  factory $ChangeMuteSuccessCopyWith(
          ChangeMuteSuccess value, $Res Function(ChangeMuteSuccess) then) =
      _$ChangeMuteSuccessCopyWithImpl<$Res>;
  $Res call({EmptyResponse emptyResponse});
}

/// @nodoc
class _$ChangeMuteSuccessCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $ChangeMuteSuccessCopyWith<$Res> {
  _$ChangeMuteSuccessCopyWithImpl(
      ChangeMuteSuccess _value, $Res Function(ChangeMuteSuccess) _then)
      : super(_value, (v) => _then(v as ChangeMuteSuccess));

  @override
  ChangeMuteSuccess get _value => super._value as ChangeMuteSuccess;

  @override
  $Res call({
    Object? emptyResponse = freezed,
  }) {
    return _then(ChangeMuteSuccess(
      emptyResponse == freezed
          ? _value.emptyResponse
          : emptyResponse // ignore: cast_nullable_to_non_nullable
              as EmptyResponse,
    ));
  }
}

/// @nodoc

class _$ChangeMuteSuccess implements ChangeMuteSuccess {
  const _$ChangeMuteSuccess(this.emptyResponse);

  @override
  final EmptyResponse emptyResponse;

  @override
  String toString() {
    return 'MessagesState.changeMuteSuccess(emptyResponse: $emptyResponse)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is ChangeMuteSuccess &&
            const DeepCollectionEquality()
                .equals(other.emptyResponse, emptyResponse));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(emptyResponse));

  @JsonKey(ignore: true)
  @override
  $ChangeMuteSuccessCopyWith<ChangeMuteSuccess> get copyWith =>
      _$ChangeMuteSuccessCopyWithImpl<ChangeMuteSuccess>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return changeMuteSuccess(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return changeMuteSuccess?.call(emptyResponse);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (changeMuteSuccess != null) {
      return changeMuteSuccess(emptyResponse);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return changeMuteSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return changeMuteSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (changeMuteSuccess != null) {
      return changeMuteSuccess(this);
    }
    return orElse();
  }
}

abstract class ChangeMuteSuccess implements MessagesState {
  const factory ChangeMuteSuccess(EmptyResponse emptyResponse) =
      _$ChangeMuteSuccess;

  EmptyResponse get emptyResponse;
  @JsonKey(ignore: true)
  $ChangeMuteSuccessCopyWith<ChangeMuteSuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetGroupStatusDoneCopyWith<$Res> {
  factory $GetGroupStatusDoneCopyWith(
          GetGroupStatusDone value, $Res Function(GetGroupStatusDone) then) =
      _$GetGroupStatusDoneCopyWithImpl<$Res>;
  $Res call({GetFrinedStatusEntity getFrinedStatusEntity});
}

/// @nodoc
class _$GetGroupStatusDoneCopyWithImpl<$Res>
    extends _$MessagesStateCopyWithImpl<$Res>
    implements $GetGroupStatusDoneCopyWith<$Res> {
  _$GetGroupStatusDoneCopyWithImpl(
      GetGroupStatusDone _value, $Res Function(GetGroupStatusDone) _then)
      : super(_value, (v) => _then(v as GetGroupStatusDone));

  @override
  GetGroupStatusDone get _value => super._value as GetGroupStatusDone;

  @override
  $Res call({
    Object? getFrinedStatusEntity = freezed,
  }) {
    return _then(GetGroupStatusDone(
      getFrinedStatusEntity == freezed
          ? _value.getFrinedStatusEntity
          : getFrinedStatusEntity // ignore: cast_nullable_to_non_nullable
              as GetFrinedStatusEntity,
    ));
  }
}

/// @nodoc

class _$GetGroupStatusDone implements GetGroupStatusDone {
  const _$GetGroupStatusDone(this.getFrinedStatusEntity);

  @override
  final GetFrinedStatusEntity getFrinedStatusEntity;

  @override
  String toString() {
    return 'MessagesState.getGroupStatusDone(getFrinedStatusEntity: $getFrinedStatusEntity)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is GetGroupStatusDone &&
            const DeepCollectionEquality()
                .equals(other.getFrinedStatusEntity, getFrinedStatusEntity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(getFrinedStatusEntity));

  @JsonKey(ignore: true)
  @override
  $GetGroupStatusDoneCopyWith<GetGroupStatusDone> get copyWith =>
      _$GetGroupStatusDoneCopyWithImpl<GetGroupStatusDone>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() messagesInitState,
    required TResult Function() messagesLoadingState,
    required TResult Function(ConversationsEntity conversationsEntity)
        conversationsLoadedState,
    required TResult Function(EmptyResponse emptyResponse) messageCreatedState,
    required TResult Function(EmptyResponse emptyResponse)
        messageBroadCastCreatedState,
    required TResult Function(MessagesEntity messagesEntity)
        messagesLoadedState,
    required TResult Function(TokenEntity tokenEntity) tokenLoadedState,
    required TResult Function(TokenRtmEntity tokenRtmEntity)
        tokenRtmLoadedState,
    required TResult Function(EmptyResponse emptyResponse)
        conversationMessagesClearedState,
    required TResult Function(GroupEntity groupEntity) groupCreatedState,
    required TResult Function(GroupsEntity groupsEntity) groupsLoadedState,
    required TResult Function(GroupEntity groupEntity) groupUpdatedState,
    required TResult Function(EmptyResponse emptyResponse) groupDeletedState,
    required TResult Function(EmptyResponse emptyResponse)
        friendAddedToGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        friendDeletedFromGroupState,
    required TResult Function(EmptyResponse emptyResponse)
        groupMessagesClearedState,
    required TResult Function(EmptyResponse emptyResponse) messagesReadState,
    required TResult Function(AppErrors error, VoidCallback callback)
        messagesErrorState,
    required TResult Function(EmptyResponse emptyResponse) messagesReportState,
    required TResult Function(EmptyResponse emptyResponse) changeMuteSuccess,
    required TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)
        getGroupStatusDone,
  }) {
    return getGroupStatusDone(getFrinedStatusEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
  }) {
    return getGroupStatusDone?.call(getFrinedStatusEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? messagesInitState,
    TResult Function()? messagesLoadingState,
    TResult Function(ConversationsEntity conversationsEntity)?
        conversationsLoadedState,
    TResult Function(EmptyResponse emptyResponse)? messageCreatedState,
    TResult Function(EmptyResponse emptyResponse)? messageBroadCastCreatedState,
    TResult Function(MessagesEntity messagesEntity)? messagesLoadedState,
    TResult Function(TokenEntity tokenEntity)? tokenLoadedState,
    TResult Function(TokenRtmEntity tokenRtmEntity)? tokenRtmLoadedState,
    TResult Function(EmptyResponse emptyResponse)?
        conversationMessagesClearedState,
    TResult Function(GroupEntity groupEntity)? groupCreatedState,
    TResult Function(GroupsEntity groupsEntity)? groupsLoadedState,
    TResult Function(GroupEntity groupEntity)? groupUpdatedState,
    TResult Function(EmptyResponse emptyResponse)? groupDeletedState,
    TResult Function(EmptyResponse emptyResponse)? friendAddedToGroupState,
    TResult Function(EmptyResponse emptyResponse)? friendDeletedFromGroupState,
    TResult Function(EmptyResponse emptyResponse)? groupMessagesClearedState,
    TResult Function(EmptyResponse emptyResponse)? messagesReadState,
    TResult Function(AppErrors error, VoidCallback callback)?
        messagesErrorState,
    TResult Function(EmptyResponse emptyResponse)? messagesReportState,
    TResult Function(EmptyResponse emptyResponse)? changeMuteSuccess,
    TResult Function(GetFrinedStatusEntity getFrinedStatusEntity)?
        getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (getGroupStatusDone != null) {
      return getGroupStatusDone(getFrinedStatusEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MessagesInitState value) messagesInitState,
    required TResult Function(MessagesLoadingState value) messagesLoadingState,
    required TResult Function(ConversationsLoadedState value)
        conversationsLoadedState,
    required TResult Function(MessageCreatedState value) messageCreatedState,
    required TResult Function(MessageBroadCastCreatedState value)
        messageBroadCastCreatedState,
    required TResult Function(MessagesLoadedState value) messagesLoadedState,
    required TResult Function(TokenLoadedState value) tokenLoadedState,
    required TResult Function(TokenRtmLoadedState value) tokenRtmLoadedState,
    required TResult Function(ConversationMessagesClearedState value)
        conversationMessagesClearedState,
    required TResult Function(GroupCreatedState value) groupCreatedState,
    required TResult Function(GroupsLoadedState value) groupsLoadedState,
    required TResult Function(GroupUpdatedState value) groupUpdatedState,
    required TResult Function(GroupDeletedState value) groupDeletedState,
    required TResult Function(FriendAddedToGroupState value)
        friendAddedToGroupState,
    required TResult Function(FriendDeletedFromGroupState value)
        friendDeletedFromGroupState,
    required TResult Function(GroupMessagesClearedState value)
        groupMessagesClearedState,
    required TResult Function(MessagesReadState value) messagesReadState,
    required TResult Function(MessagesErrorState value) messagesErrorState,
    required TResult Function(MessagesReportState value) messagesReportState,
    required TResult Function(ChangeMuteSuccess value) changeMuteSuccess,
    required TResult Function(GetGroupStatusDone value) getGroupStatusDone,
  }) {
    return getGroupStatusDone(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
  }) {
    return getGroupStatusDone?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MessagesInitState value)? messagesInitState,
    TResult Function(MessagesLoadingState value)? messagesLoadingState,
    TResult Function(ConversationsLoadedState value)? conversationsLoadedState,
    TResult Function(MessageCreatedState value)? messageCreatedState,
    TResult Function(MessageBroadCastCreatedState value)?
        messageBroadCastCreatedState,
    TResult Function(MessagesLoadedState value)? messagesLoadedState,
    TResult Function(TokenLoadedState value)? tokenLoadedState,
    TResult Function(TokenRtmLoadedState value)? tokenRtmLoadedState,
    TResult Function(ConversationMessagesClearedState value)?
        conversationMessagesClearedState,
    TResult Function(GroupCreatedState value)? groupCreatedState,
    TResult Function(GroupsLoadedState value)? groupsLoadedState,
    TResult Function(GroupUpdatedState value)? groupUpdatedState,
    TResult Function(GroupDeletedState value)? groupDeletedState,
    TResult Function(FriendAddedToGroupState value)? friendAddedToGroupState,
    TResult Function(FriendDeletedFromGroupState value)?
        friendDeletedFromGroupState,
    TResult Function(GroupMessagesClearedState value)?
        groupMessagesClearedState,
    TResult Function(MessagesReadState value)? messagesReadState,
    TResult Function(MessagesErrorState value)? messagesErrorState,
    TResult Function(MessagesReportState value)? messagesReportState,
    TResult Function(ChangeMuteSuccess value)? changeMuteSuccess,
    TResult Function(GetGroupStatusDone value)? getGroupStatusDone,
    required TResult orElse(),
  }) {
    if (getGroupStatusDone != null) {
      return getGroupStatusDone(this);
    }
    return orElse();
  }
}

abstract class GetGroupStatusDone implements MessagesState {
  const factory GetGroupStatusDone(
      GetFrinedStatusEntity getFrinedStatusEntity) = _$GetGroupStatusDone;

  GetFrinedStatusEntity get getFrinedStatusEntity;
  @JsonKey(ignore: true)
  $GetGroupStatusDoneCopyWith<GetGroupStatusDone> get copyWith =>
      throw _privateConstructorUsedError;
}
