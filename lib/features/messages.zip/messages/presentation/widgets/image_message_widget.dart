import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:starter_application/core/ui/widgets/custom_network_image_widget.dart';
import 'package:starter_application/features/messages/domain/entity/messaging_entity.dart';

class ImageMessageWidget extends StatelessWidget {
  final MessagingFileEntity messagingFileEntity;
  const ImageMessageWidget({Key? key, required this.messagingFileEntity})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints:
          BoxConstraints(maxHeight: 0.4.sh, minWidth: 0.9.sw, maxWidth: 0.9.sw),
      child: CustomNetworkImageWidget(
        imgPath: messagingFileEntity.url,
        withChild: false,
        boxFit: BoxFit.fitWidth,
      ),
    );
  }
}
